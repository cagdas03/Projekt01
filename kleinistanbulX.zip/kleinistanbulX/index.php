<?php ob_start("ob_gzhandler");session_start();
   // include ("include/cache_bas.php");
	include ("include/ayar.inc.php"); 
	include("include/ust_bolum.php");
	switch($_GET['pg'])
{
        case "fe":
              include('include/firmaekle.php');
       break;
       
        case "fk":
		 echo "<div id='content'>";
              include('include/firmakayit.php');
			   echo "</div>";
			  
       break;
	   
	    case "fl":
			   echo "<div id='content'>";
			     reklam_ana(menu_ustu);
              include('include/firmaliste.php');
			   reklam_ana(menu_alti);
			   echo "</div>";
       break;
	   
	   	    case "fg":
			   echo "<div id='content'>";
              include('include/firma-giris.php');
			   echo "</div>";
       break;
	   
	         case "fd":
			 echo "<div id='content'>";
			 reklam_ana(detay_ustu);
              include('include/firmadetay.php');
			   include('include/faceyorum.php');
			   reklam_ana(detay_alti);
			   echo "</div>";
       break;
	   
	   
	   	         case "fp":
			 echo "<div id='content'>";
              include('include/firmapanel.php');
			   echo "</div>";
       break;
	   
	   	case "sek":
			   echo "<div id='content'>";
			    reklam_ana(menu_ustu);
              include('include/sektorliste.php');
			   reklam_ana(menu_alti);
			   echo "</div>";
       break;
	   
	   
	   	   	case "sekl":
			   echo "<div id='content'>";
			   reklam_ana(menu_ustu);
              include('include/sektorfliste.php');
			   reklam_ana(menu_alti);
			   echo "</div>";
       break;
	   
	   
	   
	   	   	case "shr":
			   echo "<div id='content'>";
              include('include/harita.php');
			   echo "</div>";
       break;
      
	  
	  	   	
	  case "ltsm":
			   echo "<div id='content'>";
              include('include/iletisim.php');
			   echo "</div>";
       break;
	  
	  	 case "ul":
			   echo "<div id='content'>";
			   reklam_ana(menu_ustu);
              include('include/urunliste.php');
			  reklam_ana(menu_alti);
			  
			   echo "</div>";
       break;
	   
	   	  	 case "hl":
			   echo "<div id='content'>";
			   reklam_ana(menu_ustu);
			  include('include/manset.php');
              include('include/haberliste.php');
			  reklam_ana(menu_alti);
			  
			   echo "</div>";
       break;
	   
	   
	   	  	 case "il":
			   echo "<div id='content'>";
			   reklam_ana(menu_ustu);
              include('include/ilanliste.php');
			   reklam_ana(menu_alti);
			   echo "</div>";
       break;
	   
	   	   case "iland":
			   echo "<div id='content'>";
			   reklam_ana(detay_ustu);
              include('include/ilandetay.php');
			  reklam_ana(detay_alti);
			   echo "</div>";
       break;
	   
	   case "urund":
			   echo "<div id='content'>";
			    reklam_ana(detay_ustu);
              include('include/urundetay.php');
			  reklam_ana(detay_alti);
			   echo "</div>";
       break;
	   
	   
	   	   case "haberd":
			   echo "<div id='content'>";
			    reklam_ana(detay_ustu);
              include('include/haberdetay.php');
			  reklam_ana(detay_alti);
			   echo "</div>";
       break;
	   
	   
	   	   	   case "hkatl":
			   echo "<div id='content'>";
			 reklam_ana(menu_ustu);
              include('include/haberkatliste.php');
			 reklam_ana(menu_alti);
			   echo "</div>";
       break;
	   
	   
	  case "md":
	           
			   echo "<div id='content'>";
			    include('include/mansetdetay.php');
			     include('include/faceyorum.php');
			   echo "</div>";
       break;
	   
	   
	   	   	   	  	 case "srehber":
			   echo "<div id='content'>";
              include('include/sehirrehberi.php');
			   echo "</div>";
       break;
	   
	   
	   	   	   	   	  	 case "sehirmenul":
			   echo "<div id='content'>";
              include('include/sehirmenuliste.php');
			   echo "</div>";
       break;
	   
	   
	   	   	   	   	   	  	 case "sehirmenud":
			   echo "<div id='content'>";
			    include('include/sehirmenudetay.php');
			   echo "</div>";
       break;
      
		  case "pp":
		  echo "<div id='content'>";
		  include('include/panel_profilim.php');
		  echo "</div>";
		  break;
		  
		   case "yer":
		  echo "<div id='content'>";
		   reklam_ana(menu_ustu);
		  include('include/yerler.php');
		   reklam_ana(menu_alti);
		  echo "</div>";
		  break;
		  
		  case "ppk":
		  echo "<div id='content'>";
		  include('include/panel_profilim_kayit.php');
		  echo "</div>";
		  break;
		  
		  
		  case "pi":
		  echo "<div id='content'>";
		  include('include/panel_ilanlar.php');
		  echo "</div>";
		  break;
		  
		  case "sun":
		  echo "<div id='content'>";
		  include('include/sifre-unuttum.php');
		  echo "</div>";
		  break;
		  
		  case "pu":
		  echo "<div id='content'>";
		  include('include/panel_urunler.php');
		  echo "</div>";
		  break;
		  
		  case "ph":
		  echo "<div id='content'>";
		  include('include/panel_haberler.php');
		  echo "</div>";
		  break;
	  
	  	  case "ok":
		  echo "<div id='content'>";
		  include('include/logout.php');
		  echo "</div>";
		  break;
	  
	  
	  	  case "sbt":
		  echo "<div id='content'>";
		    reklam_ana(detay_ustu);
		  include('include/sayfadetay.php');
		    reklam_ana(detay_alti);
		  echo "</div>";
		  break;
		  
		  	  	  case "ara":
		  echo "<div id='content'>";
		    reklam_ana(detay_ustu);
		  include('include/ara.php');
		    reklam_ana(detay_alti);
		  echo "</div>";
		  break;
		  
		  	  case "knye":
			   echo "<div id='content'>";
              include('include/kunye.php');
			   echo "</div>";
		break;

         default:
		 
			 
		 
   //include("include/manset.php");
   echo "<div id='content'>";
  
		
$sorgumodul=mysql_query("SELECT id,modul_adi,onay,sira, alias from modul where konum='orta' and onay=1 order by sira asc");
while($modul=mysql_fetch_assoc($sorgumodul)) {
switch($modul['alias'])
{
	

		  case "manset":
	  include("include/manset.php");
      reklam_ana(manset_alti);
      break;
	  	
		  case "ana-map":
	  include("include/ana-map.php");
       break;


		  case "vitrin":
	  include("include/vitrin_firmalar.php");
       break;
	
	
		 case "haberkat-listesi":
	  include("include/haberliste.php");
	  break;
	  
	  
		  case "firma-haber":
	  include("include/firma_haberler.php");
      reklam_ana(fhaber_alti);
      break;
	  
	  	  case "firma-video":
	  include("include/firma_videolar.php");
      reklam_ana(fvideo_alti);
      break;
	  
	  
      case "altin-ana":
	  include("include/altin_firmalar.php");
      reklam_ana(altin_alti);
      break;
	  
	  case "gumus-ana":
	  include("include/gumus_firmalar.php");
      break;

	  case "urun-ana":
	  reklam_ana(urun_ustu);
	  include("include/altin_urunler.php");
	  reklam_ana(urun_alti); 
      break;

	  case "sonek":
	  include("include/son_eklenenler.php");
	  reklam_ana(sonek_alti);
      break;

	  case "doviz":
	  include("include/gunluk_kur.php");
      break;
	  
	  	  case "sosyal":
	  include("include/facelike_ana.php");
      break;			
 
  
	  default:
	  break;
	 
     }
	  
}
reklam_ana(ana_alt1);
reklam_ana(ana_alt2);
reklam_ana(ana_alt3);
 echo "</div>";
 break;
}

	 ?>

   
 

 
 
		 
	<?PHP  
	
	
	switch($_GET['pg'])
{
	
	case "srehber":
	case "sehirmenul":
	case "sehirmenud":
	include('include/sol_bolum_sehir.php');
	break;
	
	case "fp":
	case "pp":
	case "pi":
	case "pu":
	case "ph":
	include('include/sol_bolum_panel.php');
	break;
	
	default:
	include('include/sol_bolum.php');
	break;
	
	
}


	 
	?>
   
    <?php
	include("include/footer.php");
// include("include/cache_bit.php");
	 ?> 
