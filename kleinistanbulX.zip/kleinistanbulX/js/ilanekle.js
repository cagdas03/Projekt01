

// validation
$().ready(function() {
	// validate the comment form when it is submitted
	
	
	// validate signup form on keyup and submit
	$("#ilanForm").validate({
		rules: {
			tip: "required",
			baslik: "required",
			gkod: {	required: true, }
			    },
		messages: {
			tip:"Gerekli",
			baslik: "Gerekli",
			gkod: {
				required: "Resimdeki kodu giriniz.",
			      }
		          }
	                         });

});
