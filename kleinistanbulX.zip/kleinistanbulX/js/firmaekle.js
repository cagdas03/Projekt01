//username check
pic1 = new Image(16, 16); 
pic1.src = "images/loader.gif";
$(document).ready(function(){
$("#username2").change(function() { 
var usr = $("#username2").val();
if(usr.length >= 3)
{
$("#status").html('<img src="images/loader.gif" align="absmiddle">Kontrol ediliyor...');

    $.ajax({  
    type: "POST",  
    url: "check.php",  
    data: "username2="+ usr,  
    success: function(msg){  
   
   $("#status").ajaxComplete(function(event, request, settings){ 

	if(msg == 'Kullanıcı Ady Müsait')
	{ 
        $("#username2").removeClass('object_error'); // if necessary
		$("#username2").addClass("object_ok");
		$(this).html('<img src="images/accepted.png" align="absmiddle"> <font color="Green"> Uygun </font>  ');
	}  
	else  
	{  
		$("#username2").removeClass('object_ok'); // if necessary
		$("#username2").addClass("object_error");
		$(this).html(msg);
	}  
   
   });

 } 
   
  }); 

}
else
	{
	$("#status").html('<font color="red">Kullanıcı adı en az <strong>3</strong> karakter olmalıdır.</font>');
	$("#username2").removeClass('object_ok'); // if necessary
	$("#username2").addClass("object_error");
	}

});

});

// BU ne?
  $( function () {
  twitter.screenNameKeyUp();
  $('#user_screen_name').focus();
  });

// BU ne?
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}

// validation
$().ready(function() {
	// validate the comment form when it is submitted
	$("#commentForm").validate();
	
	// validate signup form on keyup and submit
	$("#signupForm").validate({
		rules: {
			adi: "required",
			username2: {
				required: true,
				minlength: 3
			},
			password: {
				minlength: 5
			},
			confirm_password: {
				required: true,
				minlength: 5,
				
			},
			
		
				adres: {
				required: true,
				minlength: 5
			},
			sehir: {
				required: true,
		    },
			
				ilce: {
				required: true,
		    },
			
								
										
				tel: {	    },
				
					email: {
				required: true,
				email: true
			}
			,
				
							
						fsektor: {
				required: true,
				    },
			gkod: {
				required: true,
		    },
			
				agree: "required"
			
		    },
		messages: {
			
			adi: "Lütfen Firmanızın Adını Yazınız.",
				
			username2: {
				required: "Bir kullanıcı adı yazınız.",
				minlength: "!!"
			},
			
			email: 
			{
			required: "Geçerli email yazınız.",	
			
			}
			
			,
			
				adres: {
				required: "Bir adres yazınız.",
				minlength: "Adresiniz en az 5 karakter olmalıdır."
			},
			    sehir: {
				required: "Bir şehir seçiniz.",
			},
				    ilce: {
				required: "Bir ilçe seçiniz.",
			},
			
			    tel: {
				required: "Bir iş telefonu yazınız.",
			},
			
				    kelimeler: {
				required: "Firma ile ilgili anahtar kelimeler yazınız.",
			},
			
			   fsektor: {
				required: "Bir sektör seçiniz.",
			},
			
				
	 	password: {
				required: "Lütfen bir şifre yazınız.",
				minlength: "şifreniz en az 5 karakterden oluşmalıdır."
			},
			confirm_password: {
				required: "şifreyi tekrar yazınız",
				minlength: "şifreniz en az 5 karakterden oluşmalıdır.",
				
			},
			
			email: "Geçerli bir e-mail adresi yazınız.",
			gkod: {
				required: "Resimdeki kodu giriniz.",
			},
			agree: "Kabul ediniz."
		    }
	        }
	        );
	

	// check if confirm password is still valid after password changed
	
	

});


          $(function(){
              $("#ilce").chained("#sehir"); 
          });
    
//işaretleyince açılma temsilci
function check(tableId,ctrl)
{
document.getElementById(tableId).style.display = (ctrl.checked) ? "":"none";
}

function gerial(tableId,ctrl)
{
document.getElementById(tableId).style.display = (ctrl.checked) ? "":"block";
}

/////////////
function showhide(what,obj)
 {  
   if(what.checked) {
  obj1 = document.getElementById(obj);
  obj1.style.display = 'block'; 
   } else { 
    obj1 = document.getElementById(obj);
	obj1.style.display = 'none';  
}}
	  


// Temsilci için form
function check_temsilci(){
	
	if (document.temsilci.adsoyad.value == ""){
		alert ("Lütfen Ad Soyad yazınız.");
		document.temsilci.adsoyad.focus();
		return false;  
	}
	if (document.temsilci.adres.value.length<10 || document.temsilci.adres.value.length>200){
		alert ("Adres alanı en az 10 karakter en fazla 200 karakter uzunluğunda olmalıdır!");
		document.temsilci.adres.focus();
		return false;  	
	}
	
		if (document.temsilci.telefon.value == ""){
		alert ("Lütfen size ulaşabileceðimiz bir telefon numarası yazınız.");
		document.temsilci.telefon.focus();
		return false;  
	}
		

 }


//SIfre dogrulama
function validate(form) {
var e = form.elements;
if(e['password'].value != e['confirm_password'].value) {
alert('Sifre ile sifre tekrari uyuşmuyor lütfen tekrar yaziniz.');
return false;
}
return true;
}