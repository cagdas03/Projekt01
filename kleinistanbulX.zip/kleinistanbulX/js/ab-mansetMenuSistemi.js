$(document).ready(function(){
    /**
     * Menu icerisindeki herhangi bir a taginin uzerine gelindiginde (hover  durumu gerceklestiginde).
     **/
    $('.mansetMenuSistemi ul li a').hover(function(){
        /**
         * Uzerine gelinen a taginin bir ustune cik (parent), orada img yani resim ara (find)
         * sonra resmin display degerini al (css.('display');)
         **/
        var resimGorunurlugu =  $(this).find('img').css('display');
        /**
         * Buradaki if degerimiz acik olan bir menunun uzerine gelidiginde
         * bir daha o menuye efekt vermesini engellemek.
         **/
        if (resimGorunurlugu == 'block' || resimGorunurlugu == 'inline')
        {
            /**
             * Eger resmimiz suan aktif sekilde gorukuyorsa
             * hic birsey yapma.
             **/
        }
        else
        {
            /**
             * Illkez acilacak bir resimse onceden acilan resimlerin hepsini kapat (fadeOut('fast');)
             **/
            $(this).parent().parent().find('img').fadeOut('fast');
            /**
             * Butun resimler kapandiktan sonra uzerine gelinen resmi goster (fadeIn('normal');)
             **/
            $(this).find('img').fadeIn('normal');

        }

    });
    
});



  /** ANASAYFADAKİ MANŞET SİSTEMİ            **/


$(document).ready(function(){
    /**
     * Menu icerisindeki herhangi bir a taginin uzerine gelindiginde (hover  durumu gerceklestiginde).
     **/
    $('.AmansetMenuSistemi ul li a').hover(function(){
        /**
         * Uzerine gelinen a taginin bir ustune cik (parent), orada img yani resim ara (find)
         * sonra resmin display degerini al (css.('display');)
         **/
        var resimGorunurlugu =  $(this).find('img').css('display');
        /**
         * Buradaki if degerimiz acik olan bir menunun uzerine gelidiginde
         * bir daha o menuye efekt vermesini engellemek.
         **/
        if (resimGorunurlugu == 'block' || resimGorunurlugu == 'inline')
        {
            /**
             * Eger resmimiz suan aktif sekilde gorukuyorsa
             * hic birsey yapma.
             **/
        }
        else
        {
            /**
             * Illkez acilacak bir resimse onceden acilan resimlerin hepsini kapat (fadeOut('fast');)
             **/
            $(this).parent().parent().find('img').fadeOut('fast');
            /**
             * Butun resimler kapandiktan sonra uzerine gelinen resmi goster (fadeIn('normal');)
             **/
            $(this).find('img').fadeIn('normal');

        }

    });
    
});




/** HABER DETAYLARINDAKİ SİSTEM            **/


$(document).ready(function(){
    /**
     * Menu icerisindeki herhangi bir a taginin uzerine gelindiginde (hover  durumu gerceklestiginde).
     **/
    $('.mansetdMenuSistemi ul li a').hover(function(){
        /**
         * Uzerine gelinen a taginin bir ustune cik (parent), orada img yani resim ara (find)
         * sonra resmin display degerini al (css.('display');)
         **/
        var resimGorunurlugu =  $(this).find('img').css('display');
        /**
         * Buradaki if degerimiz acik olan bir menunun uzerine gelidiginde
         * bir daha o menuye efekt vermesini engellemek.
         **/
        if (resimGorunurlugu == 'block' || resimGorunurlugu == 'inline')
        {
            /**
             * Eger resmimiz suan aktif sekilde gorukuyorsa
             * hic birsey yapma.
             **/
        }
        else
        {
            /**
             * Illkez acilacak bir resimse onceden acilan resimlerin hepsini kapat (fadeOut('fast');)
             **/
            $(this).parent().parent().find('img').fadeOut('fast');
            /**
             * Butun resimler kapandiktan sonra uzerine gelinen resmi goster (fadeIn('normal');)
             **/
            $(this).find('img').fadeIn('normal');

        }

    });
    
});