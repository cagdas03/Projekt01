// input aranacak kelime
 function inputgoster(text){
    var kelime = document.getElementById('kelime');
    if(kelime != null)
        kelime.value = text;
 }



// Kayan sektörler
$(function() {
	
		$('#kaykay-a')
		.jCarouselLite({mouseWheel:false,vertical:true,visible:18,scroll:18,auto:15000,speed:5000,btnNext:'.kaykay .crslPlus-next',btnPrev:'.kaykay .crslPlus-prev' });
		$('.kaykay').mouseover(function(){ crslPluses='kaykay-a' }).mouseout(function() { crslPluses='';});


});


//Tab menü..

$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});

// Login sayfası
        $(document).ready(function() {

            $(".signin").click(function(e) {          
				e.preventDefault();
                $("fieldset#signin_menu").toggle();
				$(".signin").toggleClass("menu-open");
            });
			
			$("fieldset#signin_menu").mouseup(function() {
				return false
			});
			$(document).mouseup(function(e) {
				if($(e.target).parent("a.signin").length==0) {
					$(".signin").removeClass("menu-open");
					$("fieldset#signin_menu").hide();
				}
			});			
			
        });
		
		
// Kaykay sektör 18 li kayma iþlemleri		
$(function() {
	
		$('#kaykay-a')
		.jCarouselLite({mouseWheel:false,vertical:true,visible:18,scroll:18,auto:10000,speed:1500,btnNext:'.kaykay .crslPlus-next',btnPrev:'.kaykay .crslPlus-prev' });
		$('.kaykay').mouseover(function(){ crslPluses='kaykay-a' }).mouseout(function() { crslPluses='';});


});


function check_iletisim(){
	
	if (document.iletForm.ad.value == ""){
		alert ("Lütfen ad ve soyadınızı yazınız");
		document.iletForm.ad.focus();
		return false;  
	}


	
		if (document.iletForm.email.value == ""){
		alert ("Lütfen e-mailinizi yazınız");
		document.iletForm.email.focus();
		return false;  
	}
	else
	{
    var pattern=/^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
    if(pattern.test(document.iletForm.email.value)){
      }else{
    alert("Hatalı email girdiniz. Lütfen kontrol ediniz");
	document.iletForm.email.focus();
	return false;
    }
	
	
	}
	
		if (document.iletForm.konu.value == ""){
		alert ("Lütfen bir konu yazınız.");
		document.iletForm.konu.focus();
		return false;  
	}
	
		if (document.iletForm.mesaj.value == ""){
		alert ("Lütfen mesaj detaylarını yazınız.");
		document.iletForm.mesaj.focus();
		return false;
	}
	
		if (document.iletForm.mesaj.value.length<10 || document.iletForm.mesaj.value.length>2000){
		alert ("Mesaj detaylarınız 10 karakteden az, 2000 karakterden fazla olmamalıdır.");
		document.iletForm.mesaj.focus();
		return false; 	
	}
	
	
			if (document.iletForm.gkod.value == ""){
		alert ("Lütfen güvenlik kodunu yazınız.");
		document.iletForm.gkod.focus();
		return false;
	}
	

	
 }
 
 // fdetay tab

  
   // fdetay galeri
  function update(url,index,isSuper) {
 	document['PhotoBig'].src=url;
}

 // Sektör  
 $(document).ready(function() {
 $("#s8").dropdownchecklist( { emptyText: "Lütfen Seçiniz...", width: 295 } );        
 });
 
 	 // jconfirmation ask silebi,lirmiyiz..
	$(document).ready(function() {
		$('.ask').jConfirmAction();
	});
	
	
 	 // pretty photo ile youtube videosu
	  $(document).ready(function(){
    $("a[rel^='prettyPhoto']").prettyPhoto();
  });
  
   // masked input
jQuery(function($){  
   
$("#ttelmask").mask("(99 99) 99999");
$("#tcepmask").mask("(99 99) 99999");
$("#tfaxmask").mask("(99 99) 99999");

});

  //lightboxes  ürün resim
   $(function() {
        $('#urunresim a').lightBox();
    });


  //Anasayfa haber manşetlerinde tüm haberler mouseover işlemleri ttyazılım.com taner macit
 function mouseOverImage() { 
            document.getElementById("img1").src = "images/mansetbg-ho.png"; 
        } 
 
        function mouseOutImage() { 
            document.getElementById("img1").src = "images/mansetbg.png"; 
        } 

 