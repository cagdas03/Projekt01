
			CKEDITOR.replace( 'detay',
				{
					
					// Remove unused plugins.
					removePlugins : 'bidi,button,dialogadvtab,div,filebrowser,flash,format,forms,horizontalrule,iframe,indent,justify,liststyle,pagebreak,showborders,stylescombo,table,tabletools,templates',
					// Width and height are not supported in the BBCode format, so object resizing is disabled.
					
					// Define font sizes in percent values.
					fontSize_sizes : "30/30%;50/50%;100/100%;120/120%;150/150%;200/200%;300/300%",
					toolbar :
					[
					    ['Bold', 'Italic','Underline'],
						['FontSize'],
						['TextColor'],
						['Link', 'Unlink', 'Image', 'SpecialChar'],
						['NumberedList','BulletedList'],
						['Find','Replace','-','SelectAll','RemoveFormat'],
						['Source', 'Undo','Redo'],
						['Maximize']
					],
				
			} );

		