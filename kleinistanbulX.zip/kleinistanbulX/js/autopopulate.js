$(document).ready(function()
{  
	var kel = $('#aranan-kelime');
	
	$('#arama_form').submit(function()
	{
		if (kel.val() == 'Aranacak Kelime')
		{
			kel.val('');
		}
		
		$('*[name]', $(this)).each(function()
		{
			var v = $(this).val();

			if ( ! v || v == '' || v == 0)
			{
				$(this).attr('disabled', 'disabled');
			}
		});

		return true;
	});
	
    kel.focus(function()
	{
        if ($(this).val() == 'Aranacak Kelime') $(this).val('');
    }).blur(function()
	{
        if ($(this).val() == '') $(this).val('Aranacak Kelime');
    });
});
