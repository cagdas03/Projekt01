<?php 
	
$sql="SELECT pollID, pollQuestion from polls  where pollStatus=1  order by rand() limit 1 ";
$sorgu=mysql_query($sql);
$yeni=mysql_fetch_row($sorgu);
$yenianket=$yeni['0'];
$cobaslik=$yeni['1'];


//VOTE START
	
	if (isset($_COOKIE["poll" . $yenianket])) {
		
		?>
      
     <div id="sol_modul">
<div id="sol_modul_tepe" >ANKET</div>        
        
        <div id="sol_modul_orta">
        
        <div id="pollWrap">
        
        
        <form name="pollForm">
         <div class="fl anket-soru">
		  
		 <?php echo $cobaslik; ?></div>
         <div style="clear:left"></div>
         <ul>
         <?php
		 $sorgu=mysql_query("SELECT pollAnswerValue, sum(pollAnswerPoints) from pollAnswers where pollID='$yenianket'") or die(mysql_error());
		 $topanket=mysql_fetch_assoc($sorgu);
		 $topanket=$topanket['sum(pollAnswerPoints)'];
		 $anssorgu=mysql_query("SELECT pollAnswerValue, pollAnswerPoints from pollAnswers where pollID='$yenianket'") or die(mysql_error());
		 $i=1;
		
		 while($ans=mysql_fetch_assoc($anssorgu))
		 {
		$yuzde=intval(($ans['pollAnswerPoints']*100)/$topanket);			 
		?>
    
         
         <li><input type="radio"  disabled=""> <?php echo $ans['pollAnswerValue'] ?><span> (<?php echo $yuzde;?> % - <?php echo $ans['pollAnswerPoints'] ?> oy)</span></li>
         <li class="pollChart ank<?php echo $i ?>" style="width:<?php echo $yuzde;?>%; display: list-item;"></li>
        <?php 
		$i++;
		} ?>
        
         </ul>
         
         <input type="image" name="pollSubmit" id="pollSubmit" disabled="" src="images/anket-sonuc.png" alt="Oyla" >
         <span id="pollMessage" style="display: none;"></span>
         <img id="pollAjaxLoader" alt="Anket" src="images/ajaxLoader.gif" style="display: none;">
         </form>
             
         
         </div>
         </div>
         
         <div id="sol_modul_alt" ></div>
</div>
         
                    
       
                
		<?
			} else {
require("include/anketfonk.php");
getPoll($yenianket);
}


 ?>
 
