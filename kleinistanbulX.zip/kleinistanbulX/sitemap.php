<?  include ("include/ayar.inc.php");
        function taner($url) 
{
	     $url = trim($url);     
		 $find = array('<b>', '</b>');     
		 $url = str_replace ($find, '', $url);     
		 $url = preg_replace('/<(\/{0,1})img(.*?)(\/{0,1})\>/', 'image', $url);     
		 $find = array(' ', '&quot;', '&amp;', '&', '\r\n', '\n', '/', '\\', '+', '<', '>');     
		 $url = str_replace ($find, '-', $url);     
		 $find = array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ë', 'Ê','ə' ,'Ə');     
		 $url = str_replace ($find, 'e', $url);     
		 $find = array('í', 'ý', 'ì', 'î', 'ï', 'I', 'Ý', 'Í', 'Ì', 'Î', 'Ï','İ','ı');     
		 $url = str_replace ($find, 'i', $url);     
		 $find = array('ó', 'ö', 'Ö', 'ò', 'ô', 'Ó', 'Ò', 'Ô');     
		 $url = str_replace ($find, 'o', $url);     
		 $find = array('á', 'ä', 'â', 'à', 'â', 'Ä', 'Â', 'Á', 'À', 'Â');     
		 $url = str_replace ($find, 'a', $url);     
		 $find = array('ú', 'ü', 'Ü', 'ù', 'û', 'Ú', 'Ù', 'Û');     
		 $url = str_replace ($find, 'u', $url);     
		 $find = array('ç', 'Ç');     
		 $url = str_replace ($find, 'c', $url);     
		 $find = array('þ', 'Þ', 'Ş', 'ş');     
		 $url = str_replace ($find, 's', $url);     
		 $find = array('ð', 'Ð', 'Ğ', 'ğ');     
		 $url = str_replace ($find, 'g', $url);     
		 $find = array('/[^A-Za-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');     
		 $repl = array('', '-', '');     
		 $url = preg_replace ($find, $repl, $url);    
		 $url = str_replace ('--', '-', $url);     
		 $url = strtolower($url);     
		  return $url; } 

function tt_tarih($tarih)
{
date_default_timezone_set('Europe/Istanbul');  
setlocale(LC_ALL, 'turkish'); 
echo strftime("%Y-%n-%j", $tarih);
}



$resultsube = mysql_query("SELECT firma.adi, firma.bastarih, firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.onay=1  order by firma.bastarih desc")  or die(mysql_error()); 
$tarih= date("Y-n-j");
echo '<?xml version="1.0" encoding="UTF-8" ?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';
echo '<url><loc>'.$rowtt['site_url'].'</loc><changefreq>daily</changefreq><priority>1.00</priority></url>';

while ($results = mysql_fetch_assoc($resultsube)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/firmalar/<? echo taner($results['adi']);?>_<? echo $results['id']; ?>.html</loc> 
  <changefreq>daily</changefreq> 
  <priority>0.95</priority>  
  </url>

<? } ?>

<?php 
$resultilan = mysql_query("SELECT ilan.ilan_baslik, ilan.ilan_bas_tarih,ilan.id from ilan inner join firma on firma.id=ilan.fid where ilan.onay=1 order by ilan.ilan_bas_tarih desc")  or die(mysql_error()); 
while ($results = mysql_fetch_assoc($resultilan)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/ilanlar/<? echo taner($results['ilan_baslik']);?>_<? echo $results['id']; ?>.html</loc> 
  <changefreq>daily</changefreq> 
  <priority>0.80</priority>  
  </url>
<? } ?>


<?php 
$resulturun = mysql_query("SELECT urun.urun_baslik, urun.urun_bas_tarih,urun.id from urun inner join firma on firma.id=urun.fid where urun.onay=1 order by urun.urun_bas_tarih desc")  or die(mysql_error()); 
while ($results = mysql_fetch_assoc($resulturun)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/urunler/<? echo taner($results['urun_baslik']);?>_<? echo $results['id']; ?>.html</loc> 
   <priority>0.80</priority>  
  </url>
<? } ?>


<?php 
$resulthaber = mysql_query("SELECT haber.haber_baslik, haber.haber_bas_tarih,haber.id from haber inner join firma on haber.fid=firma.id where haber.onay=1 order by haber.haber_bas_tarih desc")  or die(mysql_error()); 
while ($results = mysql_fetch_assoc($resulthaber)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/haberler/<?php echo taner($results['haber_baslik']);?>_<?php echo $results['id']; ?>.html</loc> 
   <changefreq>daily</changefreq> 
  <priority>0.70</priority>  
  </url>
<? } ?>


<?php 
$resultsek = mysql_query("SELECT ust_adi, ust_id from ustkat")  or die(mysql_error()); 
while ($results = mysql_fetch_assoc($resultsek)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/sektorler/<?php echo taner($results['ust_adi']);?>_<?php echo $results['id']; ?>.html</loc> 
 
  <changefreq>daily</changefreq> 
  <priority>0.90</priority>  
  </url>
<?php } ?>




</urlset> 
