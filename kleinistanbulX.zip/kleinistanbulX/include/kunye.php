﻿
<div class="orta_modul">

<dl>
<dt>Yetkili:</dt><dd>Çağdaş Külekçi</dd>
<dt>Adress:</dt><dd>Stuttgarter Str. 41 - 70469 Stuttgart</dd>
<dt>Email:</dt><dd>info@kleinistanbul.de</dd>
<dt>Tel.:</dt><dd>01522-5890002</dd>
</dl>



</div>
