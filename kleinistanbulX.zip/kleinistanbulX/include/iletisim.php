﻿     <?php if(!defined("TT_YAZILIM")){ 
	// echo "IP adresiniz banlanmıştır";
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<div class="orta_modul">
<div id="uclu">
<dl>
<dt>Yetkili</dt><dd>Çağdaş Külekçi</dd>
<dt>Email</dt><dd>info@kleinistanbul.eu</dd>
<dt>Tel</dt><dd>01522-5890002</dd>
</dl>



</div>
</div>


<div class="orta_modul">


						
					   <?php  

if($_POST['git'] ) {
	
	
	 include("securimage/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['gkod']);
  if($valid == true) 
    {
	
$konu=$site_adi. " İletişim Formu Mesajı";	
$mesaj = "
<P><b>Ad Soyad: </b>".temizle($_POST['ad'])."</p>
<p><b>Konu: </b>".temizle($_POST['konu'])."</p>
<p><b>Telefon: </b>".temizle($_POST['tel'])."</p>
<p><b>Mesaj: </b> ".temizle($_POST['mesaj'])."</p>";  
postala($mailayar,temizle($_POST['ad']),temizle($_POST['email']),$konu,$mesaj); 
 echo "<div class='tebrik'>Mesajınız başarıyla iletildi.</div>";
 echo " <meta http-equiv='refresh' content='2;URL=index.html'> "; 
	}
	else
	{
		
	 echo "<div class='hata'>Güvenlik Kodunu Yanlış Girdiniz Lütfen <a href='iletisim.html'> Geri Dönüp Tekrar Deneyiniz.</a></div>";
}


}
else
{

?>  

<form  action="iletisim.html" method="post" name="iletForm"  onSubmit="return check_iletisim()" class="cmxform" id="iletForm"  >  

   <fieldset>

							<P class="pathway">
						İletişim Formu
						 </P>

    <p>
      
         <label for="ad">Ad Soyad :</label>
      <input type="text" name="ad" id="ad" maxlength="150" />*
 </p>
 
 
 		<p>
      
         <label for="email">Emailiniz :</label>
      <input type="text" name="email" id="email" maxlength="255" />*
 </p>
 
  		<p>
      
         <label for="tel">Telefon:</label>
      <input type="text" name="tel" id="tel" maxlength="30" />
 </p>
 
 		<p>
      
         <label for="Konu">Konu:</label>
      <input type="text" name="konu" id="konu" maxlength="255" />*
 </p>
 
  		<p>
      
         <label for="mesaj">Mesajınız:</label>
      <textarea name="mesaj"></textarea>*
 </p>
 
 
 

       <p><label></label><img src="securimage/securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>"></p>
        <p><label for="gkod">Güvenlik Kodu:</label><input type="text" name="gkod" id="gkod" maxlength="5" size="30"></p>
        
 
 
        
<p>
			<input class="submit" name="git" type="submit" value="Gönder"/>
		</p>
		        
                </fieldset>

</form>  

<?php }  ?> 

</div>