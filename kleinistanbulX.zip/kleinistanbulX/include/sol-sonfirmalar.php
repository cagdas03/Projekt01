﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >SON EKLENEN FİRMALAR</div>
<div id="sol_modul_orta">
    
    <div class="solsektor kaykay" >
	<ul>
   <?php
$sql="SELECT firma.id, firma.adi, firma.etiket from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.onay='1' order by firma.bastarih desc limit 0,10";

$sorgu=mysql_query($sql);
$sirano=1;
while($alim=mysql_fetch_array($sorgu))
{
$sef=seo($alim['adi']);
?>
<li><a href="firmalar/<? echo $sef;?>_<? echo $alim['id'];?>.html" title="<? echo $alim['etiket']; ?> | <? echo $alim['urun_etiket']; ?>"><? echo mb_substr($alim['adi'],0,25,'UTF-8')  ?></a></li>
<? 
$sirano++;
} ?>      
  
</ul>
</div>


</div>
<div id="sol_modul_alt" ></div>
</div>

	
    
    
    
    
    
    



