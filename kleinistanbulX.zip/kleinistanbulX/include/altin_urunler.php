     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.php';</script>";
   exit();
    } ?> 
 
   <div class="orta_modul">
    
  <div id="anafirma-wrap"> <p>ÜRÜNLER</p>
    <?php
	
	
  $sql="SELECT urun.urunresim,urun.id, urun.urun_baslik, urun.urun_etiket FROM urun inner join firma on firma.id=urun.fid where  firma.onay=1 and firma.uyeliktur=3 and urun.onay=1 order by urun.urun_bas_tarih desc limit 0,".$rowtt['ana_liste']."";
  $sorgu=mysql_query($sql) or die (mysql_error());
  $altinsay=mysql_num_rows($sorgu);
  while($array=mysql_fetch_array($sorgu))
  {
  
  $sef=seo($array['urun_baslik']);

  
  ?>
    <div id="anafirma-dis" >
    <a href="urunler/<?php echo $sef; ?>_<?php echo $array['id'];?>.html"  title="<?php echo $array['urun_baslik'];?> | <?php echo $array['urun_etiket'];?>" >
    <?php if(empty($array['urunresim'])) {
		echo "<img src='images/resimyok_ana.png' />";
	} else {
		 ?>
    <img src="uploads/urun/<? echo $array['urunresim'];?>"  />
    <?php } ?>
    <br />
	<?php echo mb_substr($array['urun_baslik'],0,45,'UTF-8');?></a>
    
    </div>
	

	<?php
    }
	 for($i=$altinsay;$i<$rowtt['ana_liste'];$i++)
    {
		?>
        <div id="anafirma-dis" >
    <a href="altin-firma-ekle.html" title="firma ekle">
    <img src="images/altin_ol.png" width="136" /><br />
	Ürününüz burada olsun ister misiniz?.</a>
    
    </div>
    
        <?php
    }
	?>
</div>
</div>
