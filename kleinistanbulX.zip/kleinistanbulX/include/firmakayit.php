      <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
 
   <div class="orta_modul">
<?PHP 


	  $username=mysql_real_escape_string($_POST['username2']);
	  $password=mysql_real_escape_string($_POST['password']);
	  $sehir=temizle($_POST['sehir']);
	  $ilce=temizle($_POST['ilce']);
	  $adi=ucwords(strtolower(temizle($_POST['adi'])));
	  $yetkili=temizle($_POST['yetkili']);
	  $adres=temizle($_POST['adres']);
	  $etiket=temizle($_POST['etiket']);
	  $tel=mysql_real_escape_string($_POST['tel']);
	  $cep=mysql_real_escape_string($_POST['cep']);
	  $fax=mysql_real_escape_string($_POST['fax']);
	  $password=md5($password);
	  $timestamp=time();
	  $rastgele=rand(1000000,9999999);
	  // �ye Bildir I�in gerekli mscbur degil
	   $arabeni=temizle($_POST['arabeni']);
	   $uadi=temizle($_POST['uadi']);
	   $uadres=temizle($_POST['uadres']);
	   $utel=temizle($_POST['utel']);
	   $utur=temizle($_POST['utur']);
	   $email=temizle($_POST['email']);
    	  
		  
		  if( $username=="" || $_POST['password']==""  || $sehir==""  || $ilce=="" || $_POST['fsektor']=="" || $_POST['adres']==""   || $_POST['email']=="")
		  {
			  
			  echo "<div class='hata'> Form verilerinden bazılarında  eksik tespit edildi; lütfen geri dönerek zorunlu alanları doldurunuz.</div>";
		  echo "<meta http-equiv='refresh' content='3;URL=firma-ekle.html'> "; 
		
			  }
		  else
		  {
			  
  include("securimage/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['gkod']);
  if($valid == true) 
    {
			  
	  
//Kullan�c� ad� kontrol�	  
$sql="SELECT username from firma where username='$username' limit 0,1 ";
$satir=mysql_query($sql);
$say=mysql_num_rows($satir);
if($say>0)	{ echo "<div class='hata'>Bu kullanıcı adı daha önce alınmış lütfen başka bir kullanıcı adı deneyiniz.</div>";
echo "<meta http-equiv='refresh' content='5;URL=firma-ekle.html'> "; 

}
else{
	
	
  include("include/upload.php");
  $f_logo=$logoismi;
	
  
   
// mysql firma ekliyoruz  
   $ekle=mysql_query("INSERT INTO firma  
        (id, adi   ,yetkili   ,adres,   tel,    fax,  etiket,     sehir,   ilce,    bastarih,    cep,   logo,  uyeliktur, onay,   username,     password,      kod ,email   ) 										
 VALUES
        ('','$adi','$yetkili','$adres','$tel','$fax','$etiket','$sehir','$ilce', '$timestamp','$cep','$f_logo' , '$utur',     '0' , '$username', '$password', '$rastgele'  ,'$email') ")
        or die(mysql_error());    
		
			
	///////////// SEKT�R  EKLENIYOR////////////////////////////////////////
$sorgu=mysql_query("SELECT id from firma where kod='$rastgele' order by bastarih desc limit 0,1 ") or die(mysql_error());
$kodum=mysql_fetch_assoc($sorgu);
$fid=$kodum['id'];
$sektoral=$_POST['fsektor'];
$sektorekle=mysql_query("INSERT INTO sektor (s_id,s_fid,s_ustid) VALUES ('','$fid','$sektoral')") or die(mysql_error());
if($sektorekle) {  } else { echo "<div class='hata'>Sektörler Eklenemedi.</div>";}
	/////////////SEKT�R  EKLENIYOR////////////////////////////////////////



	///////////// �YE BILDIR EKLENIYOR////////////////////////////////////////
  if( $uadi=="" || $utel==""  || $uadres==""  || $utur=="" || $fid=="")
		  {  }
		  else
		  {

$uyebildirekle=mysql_query("INSERT INTO uyebildir (id,fid,uadi,utel,uadres,utur, utarih, arabeni) VALUES ('','$fid','$uadi', '$utel', '$uadres','$utur', '$timestamp', '$arabeni')") or die(mysql_error());

if($uyebildirekle) {  } else { echo "<div class='hata'>Üyelik Bildirimi Eklenemedi.</div>";}

$gonderen = $mailayar;
$alici = $mailayar;
if($utur==2) { $uyetur="Gümüs"; } elseif ($utur==3) { $uyetur="Altın"; } else { $uyetur="Normal"; }
$konu = $uyetur.' Üyelik Bildirimi';
$mesaj = '
<p><b>Ad Soyad: </b> '.temizle($_POST['uadi']).'</p>
<p><b>Adres: </b> '.temizle($_POST['uadres']).'</p>
<p><b>Telefon: </b> '.temizle($_POST['utel']).'</p>
<p><b>Ne isteniyor?: </b> '.temizle($_POST['arabeni']).' ile bilgilendirilmek isteniyor.</p>';

postala($gonderen,$site_adi,$alici,$konu,$mesaj);

	/////////////SEKT�R  EKLENIYOR////////////////////////////////////////
		  }
 		
		if($ekle) { 
		 echo "<meta http-equiv='refresh' content='5;URL=index.html'> "; 
		 echo "<div class='tebrik'>Tebrikler kaydınız başarıyla eklendi. Şimdi Anasayfaya yönlendiriliyorsunuz. Kaydınız en kısa sürede onaylanacaktır. </div>"; }
		 else {
		 echo "<meta http-equiv='refresh' content='5;URL=firma-ekle.html'> "; 
		 echo "<div class='hata'>Firma veritabanına eklenirken bir hata oluştu. Tekrar denemeniz için firma ekleme sayfasına yönlendiriliyorsunuz.</div>";}                               
                                 


// Admine email g�nderiliyor.
$subject = "Yeni Firma Kaydoldu | ".$site_adi ;  
$message_contents = "
<p><b>Firma Adı:<b> " .$adi." </p>
<p><b> Kullanıcı Adı:</b> ".$username."</p>
<p> Yönetim paneline giderek firmayı onaylamayı unutmayınız. </p>"; 
 $header= "Content-type: text/html; charset='utf-8'\r\n";  
$header.= "From:$mailayar\r\n"; 

mail($mailayar,$subject,$message_contents,$header);  

// Dosya daha �nce y�klenmemi�
// Dosya hatas� yok
 // Dosya Uzant�lar�nda Sorun Yok

}
	}
	else
	{
		 echo "<meta http-equiv='refresh' content='5;URL=firma-ekle.html'> "; 
		 echo "<div class='hata'>Güvenlik kodunu yanlış girdiniz, tekrar denemek için geri yönlendiriliyorsunuz..</div>";
		
}

		  }
// Dosya varsa yap�lacaklar.
// Shell kontrol sonu
    

?>  
					
  </div>
                 					
