<?php
 // Cache Bitiş
	 $fp = fopen($cachefile, 'w+');
	 fwrite($fp, ob_get_contents());
	 fclose($fp);
	 ob_end_flush();
// Cache Bitiş
?>