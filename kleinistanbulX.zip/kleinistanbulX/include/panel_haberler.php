<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<script type="text/javascript" src="../js/nicEdit.js"></script>
<script type="text/javascript">
   bkLib.onDomLoaded(function() {
       
        new nicEditor({fullPanel : true}).panelInstance('noise');
        new nicEditor({maxHeight : 300}).panelInstance('area5');
		
  });</script>
<?php 
if($_SESSION['giris']==1 & $_SESSION['sid']>0)
{ 
$sid=$_SESSION['sid'];

$altincek=mysql_fetch_row(mysql_query("SELECT uyeliktur FROM firma where id='$sid' and onay=1 "));

$sorgu=mysql_query("SELECT haber.id, haber.haber_baslik, haber.onay, haber.haberresim, firma.uyeliktur from haber inner join firma on firma.id=haber.fid  where firma.id='$sid' and firma.onay=1  and firma.uyeliktur=3 limit 0,$iu_limit") or die(mysql_error());
$normal=mysql_fetch_assoc($sorgu);
$sayhaber=mysql_num_rows($sorgu);
?>

<div class="orta_modul">
<div id="uclu">

<?php if($altincek['0']==3) { ?>
<div id="detay-fadi">
<div id="buton1" style="cursor:pointer"> Yeni Haber Ekle</div>
</div>
<?php if(temizle($_GET['is'])=="add" and $_POST['is']=="add" ) { ?>
<div id="ilanekle">
<?PHP 
$baslik=temizle($_POST['baslik']);
$detay=addslashes($_POST['detay']);
$etiket=area($_POST['etiket']);
$gkod=temizle($_POST['gkod']);

if($sayhaber>($iu_limit-1)) { 
echo "<script>alert('En fazla $iu_limit adet haber ekleyebilirsiniz.');</script>";

echo "<meta http-equiv='refresh' content='0;URL=panel_haberler_openlist.html'> "; }

else
{
	
 include("securimage/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['gkod']);
  if($valid == true) 
    {
   
  include("include/upload.php");
  $f_haber=$haberismi;
  $time=time();
  // mysql firma ekliyoruz  
   $ekle=mysql_query("INSERT INTO haber  
        (id, haber_baslik   ,haber_detay   ,haber_etiket, haberresim, haber_bas_tarih, fid,onay) 										
 VALUES
        ('','$baslik','$detay','$etiket','$f_haber','$time', '$sid' , '0' ) ")
        or die(mysql_error());  
		  echo "<meta http-equiv='refresh' content='0;URL=panel_haberler_openlist.html'> "; 
	
	
	}
	else
	{
echo "<div class='hata'> Güvenlik Kodunu Yanlış Girdiniz. <a href='panel_haberler_openadd.html'> Geri Git </a></div>";
   }

}
?>

</div>
<?php }


else if (temizle($_GET['is'])=='teksil' and temizle($_GET['id'])>0   )
{
$id=temizle($_GET['id']);

$sorgu=mysql_query("SELECT haberresim FROM haber where id='$id' and fid='$sid' limit 0,1 ");
while($isil=mysql_fetch_assoc($sorgu))
{
$yol=$isil['haberresim'];
@unlink("uploads/haber/$yol");
}

$sil=mysql_query("UPDATE haber SET haberresim='' where id='$id' and fid='$sid'");

echo "<meta http-equiv='refresh' content='0;URL=haber_duzenle_$id.html'>";
	
}


else if (temizle($_GET['is'])=='sil' and temizle($_GET['id'])>0   )
{
$id=temizle($_GET['id']);

$sorgu=mysql_query("SELECT haberresim FROM haber where id='$id' and fid='$sid' limit 0,1 ");
while($isil=mysql_fetch_assoc($sorgu))
{
$yol=$isil['haberresim'];
@unlink("uploads/haber/$yol");
}

$sil=mysql_query("DELETE from haber where id='$id' and fid='$sid'");

echo "<meta http-equiv='refresh' content='0;URL=panel_haberler_openlist.html'>";
	
}

else if (  temizle($_GET['is'])=="edit" and intval($_GET['id'])>0 ) 
{
$id=temizle(intval($_GET['id']));


if(temizle($_POST['is']=="aktif"))

{
//D�zenleme baslasin
$baslik=temizle($_POST['baslik']);
$detay=addslashes($_POST['detay']);
$etiket=area($_POST['etiket']);


  
  include("include/upload.php");
  if(isset($haberismi))	{   $qlogo=", haberresim='$haberismi' , ";	}	else	{   $qlogo=" , ";	}

  // mysql firma ekliyoruz  
   $ekle=mysql_query("UPDATE haber SET haber_baslik='$baslik'   ,haber_detay='$detay'  $qlogo haber_etiket='$etiket' where id='$id' and fid='$sid' ") or die(mysql_error());  
		  echo "<meta http-equiv='refresh' content='0;URL=panel_haberler_openlist.html'> "; 
	
   

//D�zenleme Bitsin
}
else
{
	
$sorgu_d=mysql_query("SELECT * from haber where id='$id' and fid='$sid' limit 0,1");
while ($haberd=mysql_fetch_assoc($sorgu_d))
{
?>
	
<div id="ilanekle" class="ilanekle"  >
<form action="haber_duzenle_<?php echo $id; ?>.html" method="post" enctype="multipart/form-data" class="cmxform" id="ilanForm" onsubmit="return validate(this);">
  <fieldset>
		
		<p>
			<label for="baslik">Haber Başlığı:</label>
			<input name="baslik" id="baslik" value="<?php echo $haberd['haber_baslik']; ?>" maxlength="200" /><br />
            (Max: 200 karakter)
		*</p>
		
		<p>
			<label for="detay">Haber Detayı:</label>
			<textarea id="noise" name="detay" ><?php echo stripslashes($haberd['haber_detay']); ?></textarea>
		</p>
        
        	        
        <p>
			<label for="etiket">Etiket:</label>
			<textarea id="etiket" name="etiket" maxlength="200"  ><?php echo $haberd['haber_etiket']; ?></textarea><br />
            Etiket aralarına virgül koyunuz. (Max: 200 karakter)
		</p>
        <p>
             <label for="haberresim">Haber Resmi:</label>
          <?php if ($haberd['haberresim']=="") { ?> 
                          <input type="file"  name="f_haber" value="" />
                           <input type="hidden" name="actionhaber" value="haber" /><br>
                           Max 200 kb, (jpg, gif ya da png formatında)
                          <?php } else { ?>
                                                   
                          <img src="uploads/haber/<?php echo $haberd['haberresim'];?>" height="100" border="0">
                           <a href="haber_resim_sil_<?php echo $id; ?>.html" title="Resmi Sil" style="margin:5px" class="ask">
                           <img src="images/delete.png" alt="Sil" /></a>
                           <?php }?>
		</p>
		
       
        
           		  <p>
                   <input type="hidden" name="is" value="aktif" />
                <input class="submit" type="submit" value="Düzenle"/>
		</p>
	</fieldset>
</form>
</div>

<?php
}
//haber d�zen bitisi
}

}


?>

<div id="ilanekle" class="ilanekle" <?php if( temizle($_GET['is'])=="openadd" ) { } else { echo "style='display:none'" ;} ?> >
<form action="panel_haberler_add.html" method="post" enctype="multipart/form-data" class="cmxform" id="ilanForm" onsubmit="return validate(this);">
  <fieldset>
		
		<p>
			<label for="baslik">Haber Başlığı:</label>
			<input name="baslik" id="baslik" maxlength="200" /><br />
            (Max: 200 karakter)
		*</p>
		
		<p>
			<label for="detay">Haber Detayı:</label>
			<textarea id="noise" name="detay"></textarea>
             <script type="text/javascript" src="js/ckayar.js"></script>
		</p>
        
        	        
        <p>
			<label for="etiket">Etiket:</label>
			<textarea id="etiket" name="etiket" maxlength="200"  ></textarea><br />
            Etiket aralarına virgül koyunuz. (Max: 200 karakter)
		</p>
        <p>
        	<label for="file">Haber Resmi:</label>
			<input type="file"  name="f_haber" value="" /> 
            <input type="hidden" name="actionhaber" value="haber" /><br>
            
            Max 200 kb, (jpg, gif ya da png formatında)
		</p>
		
          <p><label></label><img src="securimage/securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>"></p>
        <p><label for="gkod">Güvenlik Kodu:</label><input type="text" name="gkod" id="gkod" maxlength="5" size="30"></p>
        
           		  <p>
                  <input type="hidden" name="is" value="add" />
			<input class="submit" type="submit" value="Ekle!"/>
		</p>
	</fieldset>
</form>
</div>

<script>
$("#buton1").click(function () {
$("#ilanekle").toggle();
}); 
</script>



<div id="detay-fadi">
<div id="buton2" style="cursor:pointer"> <a href="panel_haberler_openlist.html">Haberlerim (<?php echo $sayhaber; ?>)</a></div>
</div>

<script>   
$("#buton2").click(function () {
$("#fdtek").toggle();
});    
</script>

<div id="fdtek"  <?php if( temizle($_GET['is'])=="openlist" ) { } else { echo "style='display:none'" ;} ?> >


<?php
$sorgu_haber=mysql_query("SELECT haber.id, haber.haber_baslik, haber.onay, haber.haberresim, firma.uyeliktur from haber inner join firma on firma.id=haber.fid  where firma.id='$sid' and firma.onay=1  and firma.uyeliktur=3 limit 0,$iu_limit") or die(mysql_error());

 while ($haber=mysql_fetch_assoc($sorgu_haber)) { ?>

<div id="pilankutu">


<div id="pilankutu2">
<a title="Bu haberi düzenle" href="haber_duzenle_<?php echo $haber['id']; ?>.html"> <?php if (empty($haber['haberresim'])) { echo "<img src='images/resimyok.png'>";} else {?><img src="uploads/haber/<?php echo $haber['haberresim'] ;?>" /><?php }?>
<br><?php echo $haber['haber_baslik'] ;?>(<?php echo $haber['haber_fiyat']; ?>)</a>
</div>


<div  style=" float:left; margin-top:2px; width:133px; color:#900">
<?php if ($haber['onay']==1) { } else { echo "Onay Bekliyor.."; } ?>

<span style="float:right"><a  title="Haberi Sil" href="haber_sil_<?php echo $haber['id']; ?>.html" class="ask"><img src="images/delete.png" /></a></span>
</div>


</div>


<?php }?>
</div>

<?php } else
{
echo "<div class='hata'>Haber ekleyebilmek için ALTIN ÜYE olmalısınız. Bilgi Almak için <a href='iletisim.html'>tıklayınız.</a></div>";	
}
?>

</div>
</div>




           <?php } else { 
			  echo "<meta http-equiv='refresh' content='0;URL=index.html'> "; 
			}?>				
            