<?php
unset($_SESSION["giris"]);
unset($_SESSION["sid"]);
unset($_SESSION["username"]);
@session_destroy();
echo "<script>window.top.location.href = 'firma-giris.html';</script>";
echo "Oturumunuz kapatıldı; Anasayfaya yönlendiriliyorsunuz tarayıcınız otomatik yönlendirmiyorsa lütfen <a href='firma-giris.html'>buraya </a> tıklayınız.";
?>
