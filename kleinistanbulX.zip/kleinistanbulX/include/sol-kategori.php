﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >SEKTÖRLER</div>
<div id="sol_modul_orta">
    
    <div class="solsektor kaykay" >
	<ul>
                   	
	<?php
	$sorgu=mysql_query("SELECT ust_adi, ust_id from ustkat order by ust_ana desc, ust_adi asc limit 0,16");
	while($yaz=mysql_fetch_assoc($sorgu)) {
	$sef=seo($yaz['ust_adi']);
	
	$yeni=mysql_query("SELECT * FROM sektor inner join firma on firma.id=sektor.s_fid where sektor.s_ustid='$yaz[ust_id]' and firma.onay=1 ");
	$icsay=mysql_num_rows($yeni);
	
	?>
    
   <li><a href="sektorler/<?php echo $sef; ?>_<?php echo $yaz['ust_id']; ?>.html" title="<?php echo $yaz['ust_adi']; ?>" ><?php echo $yaz['ust_adi']; ?> (<?php echo $icsay; ?>)</a></li>


 
    <?php 
	}
?>
    <li><A style="color:#ff0000" href="/sektorler" title="Tüm Sektörler"><b>TÜM SEKTÖRLER</b></A></li>  
</ul>
</div>


</div>
<div id="sol_modul_alt" ></div>
</div>

	