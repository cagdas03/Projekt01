     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
     <?php     
function title($pg)
{


switch($pg)
{
      case "fe":
             $title="Firma Ekle";
      break;
	   
	  case "fg":
             $title="Firma Giriş | Firma Ekleme";
      break;
       
      case "fl":
             $title="Firma Listesi";
      break;
	  
	        case "hl":
             $title="Haberler, Haber Listesi";
      break;

	  case "fd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT adi from firma where id='$id' and onay=1 limit 0,1"));
			 $title=$baslik['0'];
      break;
	  
	  
	  	  case "md":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT manset_baslik from manset where id='$id' and onay=1 limit 0,1"));
			 $title=$baslik['0'];
      break;
	  
	  
	  	  case "urund":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT urun_baslik from urun where id='$id' and onay=1 limit 0,1"));
			 $title=$baslik['0'];
      break;
	  
	  	  case "iland":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT ilan_baslik from  ilan where id='$id' and onay=1 limit 0,1"));
			 $title=$baslik['0'];
      break;
	  
	  	  	  case "haberd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT haber_baslik from  haber where id='$id' and onay=1 limit 0,1"));
			 $title=$baslik['0'];
      break;
 
      case "sek":
             $title="Sektör Listesi";
      break;
	  
	   case "sekl":
	         $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT ust_adi from ustkat where ust_id='$id' limit 0,1"));
			  $title=$baslik['0'];
      break;
	  
      case "ul":
             $title="Ürün Listesi";
      break;
	  	  	  
      case "il":
             $title="İlan Listesi";
      break;
	  
	  case "shr":
             $title="Şehir Listesi";
      break;
	  
	  case "ltsm":
             $title="İletişim | Bize Ulaşın ";
      break;
	  

      default:
             $baslik=mysql_fetch_row(mysql_query("SELECT title from ayar where id=1 limit 0,1"));
			 $title=$baslik['0'];
         }

echo $title;

}



function description($pg)
{


switch($pg)
{
      case "fe":
             $description="Firmanızı rehberimize ekleyebileceğinzi sayfadır.";
      break;
	   
	  case "fg":
             $description="Bu alandan üye girişi yapabilirsiniz.";
      break;
       
      case "fl":
             $description="Firmalarımızın listelendiği ve süzüldüğü sayfadır.";
      break;
	  
	  case "hl":
             $description="Haber listesini içeren sayfadır.";
      break;
	  
	  case "fd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT adi from firma where id='$id' and onay=1 limit 0,1"));
			 $description=$baslik['0']." firmasının detaylarını içerir.";
      break;
	  
	  	  case "md":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT manset_baslik from manset where id='$id' and onay=1 limit 0,1"));
			 $description=$baslik['0']." haberinin detayını içerir.";
      break;
	  
	  	  case "urund":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT urun.urun_baslik,firma.adi from urun inner join firma on firma.id=urun.fid where urun.id='$id' and urun.onay=1 limit 0,1"));
			 $description=$baslik['1']." firmasına ait ".$baslik['0']." ürün bilgileri yer alır.";
      break;
	  
	  	  case "iland":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT ilan.ilan_baslik, firma.adi from  ilan inner join firma on firma.id=ilan.fid where ilan.id='$id' and ilan.onay=1 limit 0,1"));
			 $description=$baslik['1']." firmasına ait ".$baslik['0']." ilan bilgileri yer alır.";
      break;
	  
	  	  	  case "haberd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT haber_etiket from  haber where id='$id' and onay=1 limit 0,1"));
			 $description=$baslik['0']." haberi";
      break;
 
      case "sek":
             $description="Rehberimizdeki tüm sektörlerin listesi.";
      break;
	  
	   case "sekl":
	         $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT ust_adi from ustkat where ust_id='$id' limit 0,1"));
			  $description=$baslik['0']." sektöründeki firmalar";
      break;
	  
      case "ul":
             $description="Rehberimizdeki ürünlerin listesi.";
      break;
	  	  	  
      case "il":
             $description="Rehberimizdeki ilanların listesi yer alır.";
      break;
	  
	  case "shr":
             $description="Şehir listesi";
      break;
	  
	  case "ltsm":
             $description="Bize bu sayfadan ulaşabilirsiniz.";
      break;
	  

      default:
             $baslik=mysql_fetch_row(mysql_query("SELECT aciklama from ayar where id=1 limit 0,1"));
			 $description=$baslik['0'];
         }

echo $description;

}




function keywords($pg)
{


switch($pg)
{
      case "fe":
             $keywords="Firma, Ekle";
      break;
	   
	  case "fg":
             $keywords="Firma , Giriş";
      break;
       
      case "fl":
             $keywords="Firma , firmalar, Listesi";
      break;
	  
	  case "hl":
             $keywords="Haberler, firma haberleri";
      break;
	  
	  case "fd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT etiket from firma where id='$id' and onay=1 limit 0,1"));
			 $keywords=$baslik['0'];
      break;
	  
	  	  case "md":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT manset_etiket from manset where id='$id' and onay=1 limit 0,1"));
			 $keywords=$baslik['0'];
      break;
	  
	  	  case "urund":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT urun_etiket from urun where id='$id' and onay=1 limit 0,1"));
			 $keywords=$baslik['0'];
      break;
	  
	  	  case "iland":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT ilan_etiket from  ilan where id='$id' and onay=1 limit 0,1"));
			 $keywords=$baslik['0'];
      break;
	  
	  	  	  case "haberd":
             $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT haber_etiket from  haber where id='$id' and onay=1 limit 0,1"));
			 $keywords=$baslik['0'];
      break;
 
      case "sek":
             $keywords="Sektör, sektörler, kategoriler, firma, Listesi";
      break;
	  
	   case "sekl":
	         $id=intval(mysql_real_escape_string(($_GET['id'])));
			 $baslik=mysql_fetch_row(mysql_query("SELECT etiket from ustkat where ust_id='$id' limit 0,1"));
			  $keywords=$baslik['0'];
      break;
	  
      case "ul":
             $keywords="Ürün , Ürünler, rehber, Listesi";
      break;
	  	  	  
      case "il":
             $keywords="İlan ,ilanlar, firma, rehber, Listesi";
      break;
	  
	  case "shr":
             $keywords="Şehir, Listesi";
      break;
	  
	  case "ltsm":
             $keywords="İletişim , Bize Ulaşın ";
      break;
	  

      default:
             $baslik=mysql_fetch_row(mysql_query("SELECT keywords from ayar where id=1 limit 0,1"));
			 $keywords=$baslik['0'];
         }

echo $keywords;

}




function seo($url) 
{
	     $url = trim($url);     
		 $find = array('<b>', '</b>');     
		
		 $url = str_replace ($find, '', $url);     
		 $url = preg_replace('/<(\/{0,1})img(.*?)(\/{0,1})\>/', 'image', $url);     
		 
		 $find = array(' ', '&quot;', '&amp;', '&', '\r\n', '\n', '/', '\\', '+', '<', '>');     
		 $url = str_replace ($find, '-', $url);     
		 
		 $find = array('€', '£', '@');     
		 $url = str_replace ($find, 'e', $url);     
		
		 $find = array('İ',  'ı' ,'I' );     
		 $url = str_replace ($find, 'i', $url);     
		 
		 $find = array('Ö', 'ö' );     
		 $url = str_replace ($find, 'o', $url);  
		    
		 $find = array('A','a');     
		 $url = str_replace ($find, 'a', $url);     
		 $find = array('Ü', 'ü');     
		 $url = str_replace ($find, 'u', $url);     
		 $find = array('Ç', 'ç');     
		 $url = str_replace ($find, 'c', $url);     
		 $find = array('ş', 'Ş' ,'$');     
		 $url = str_replace ($find, 's', $url);     
		 $find = array('Ğ', 'ğ');     
		 $url = str_replace ($find, 'g', $url);     
		 $find = array('/[^A-Za-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');     
		 $repl = array('', '-', '');     
		 $url = preg_replace ($find, $repl, $url);    
		 $url = str_replace ('--', '-', $url);     
		 $url = strtolower($url);     
		  return $url; } 
 
 





		//veri temizleme
 function temizle ($veri) {
  

 $veri=str_replace("&","",$veri);
 $veri=str_replace("=","",$veri);
 $veri=str_replace("'"," ",$veri);
 $veri=str_replace("<","",$veri);
 $veri=str_replace(">","",$veri);
 $veri=str_replace("$","Dolar",$veri);
 $veri=str_replace("!","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
 $veri=trim(strip_tags($veri));
 $veri=mysql_real_escape_string($veri);
return $veri;         
} 


 function temizle_adres($veri) {
  

 $veri=str_replace("&","",$veri);
 $veri=str_replace("=","",$veri);
 $veri=str_replace("'"," ",$veri);
 $veri=str_replace("<","",$veri);
 $veri=str_replace(","," ",$veri);
 $veri=str_replace(">","",$veri);
 $veri=str_replace("$","Dolar",$veri);
 $veri=str_replace("!","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
 $veri=trim(strip_tags($veri));
 $veri=mysql_real_escape_string($veri);
return $veri;         
} 

 function area ($veri) {

 $veri=str_replace("'"," ",$veri);
  $veri=str_replace("\""," ",$veri);
 $veri=str_replace("\\","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
return $veri;         
} 


function tt_tarih($tarih)
{
date_default_timezone_set('Europe/Istanbul');  
setlocale(LC_ALL, 'turkish'); 
echo strftime("%d/%m/%Y", $tarih);
}



  
function reklam_ana($tip)
{
$sqlk=mysql_query("SELECT id,url, dosya, tip, script from reklam where konum='".$tip."' and onay='1' limit 0,1"); 
 while( $adv=mysql_fetch_assoc($sqlk))
{

$bolum=explode( '.', $adv['dosya']);
if($bolum[1]=="png" || $bolum[1]=="jpg" || $bolum[1]=="jpeg" || $bolum[1]=="gif" || $bolum[1]=="JPG" || $bolum[1]=="GIF" || $bolum[1]=="JPEG" and $adv['tip']==1)
{
echo " <div class='orta_modul'>";
echo "<div  style='width:728px; margin:0px auto; margin-top:5px; margin-bottom:5px'>";
echo "<a href='".$adv['url']."' target='_blank' >";
echo "<img src='uploads/reklam/".$adv['dosya']."' /></a></div></div>";
} 
else if( $bolum[1]=="swf" and $adv['tip']==2){
?>
<div class="orta_modul">
<div  style='width:728px; height:90px; margin:0px auto; margin-top:5px; margin-bottom:5px'>

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="728" height="90">
  <param name="movie" value="uploads/reklam/<? echo $adv['dosya']; ?>" />
  <param name="quality" value="high" />
  <embed src="uploads/reklam/<? echo $adv['dosya']; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="728" height="90"></embed>
</object>
</div>
</div>

<?php	
}
else if($adv['tip']==3)
{ 
echo "<div class='orta_modul' >";
echo "<div  style='width:728px; margin:0px auto; margin-top:5px; margin-bottom:5px'>";
echo stripslashes($adv['script']);
echo "</div></div>";
 }

else {}} // adv while
} 


// 336 lık Manşet sağı reklam fonksiyonu 
function reklam_336($tip)
{
$sqlk=mysql_query("SELECT id,url, dosya, tip, script from reklam where konum='".$tip."' and onay='1' limit 0,1"); 
 while( $adv=mysql_fetch_assoc($sqlk))
{
$bolum=explode( '.', $adv['dosya']);
if($bolum[1]=="png" || $bolum[1]=="jpg" || $bolum[1]=="jpeg" || $bolum[1]=="gif" || $bolum[1]=="JPG" || $bolum[1]=="GIF" || $bolum[1]=="JPEG" and $adv['tip']==1)
{
echo " <div id='rek336'>";
echo "<a href='".$adv['url']."' target='_blank' >";
echo "<img src='uploads/reklam/".$adv['dosya']."' alt='' /></a></div>";
} 
else if( $bolum[1]=="swf" and $adv['tip']==2){
?>
<div id="rek336">
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="336" height="280">
  <param name="movie" value="uploads/reklam/<? echo $adv['dosya']; ?>" />
  <param name="quality" value="high" />
  <embed src="uploads/reklam/<? echo $adv['dosya']; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="336" height="280"></embed>
</object>
</div>
<?php	
} else if($adv['tip']==3) {
	  echo "<div id='rek336'>";
	 echo stripslashes($adv['script']);
	 echo "</div>";
	  } else {} } // adv while
} // function



// 336 lık Manşet sağı reklam fonksiyonu 
function reklam_300($tip)
{
$sqlk=mysql_query("SELECT id,url, dosya, tip, script from reklam where konum='".$tip."' and onay='1' limit 0,1"); 
 while( $adv=mysql_fetch_assoc($sqlk))
{
$bolum=explode( '.', $adv['dosya']);
if($bolum[1]=="png" || $bolum[1]=="jpg" || $bolum[1]=="jpeg" || $bolum[1]=="gif" || $bolum[1]=="JPG" || $bolum[1]=="GIF" || $bolum[1]=="JPEG" and $adv['tip']==1)
{

echo "<a href='".$adv['url']."' target='_blank' >";
echo "<img src='uploads/reklam/".$adv['dosya']."' width='300' height='250' alt='' /></a>";
} 
else if( $bolum[1]=="swf" and $adv['tip']==2){
?>

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="300" height="250">
  <param name="movie" value="uploads/reklam/<? echo $adv['dosya']; ?>" />
  <param name="quality" value="high" />
  <embed src="uploads/reklam/<? echo $adv['dosya']; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="300" height="250"></embed>
</object>

<?php	
} else if($adv['tip']==3) {
	  echo stripslashes($adv['script']);
	 
	  } else {} } // adv while
} // function


// SOl taraftaki reklamlar 
function reklam_sol($tip)
{
$sqlk=mysql_query("SELECT id,url, dosya, tip, script from reklam where konum='".$tip."' and onay='1' limit 0,1"); 
 while( $adv=mysql_fetch_assoc($sqlk))
{
$bolum=explode( '.', $adv['dosya']);
if($bolum[1]=="png" || $bolum[1]=="jpg" || $bolum[1]=="PNG" || $bolum[1]=="jpeg" || $bolum[1]=="gif" || $bolum[1]=="JPG" || $bolum[1]=="GIF" || $bolum[1]=="JPEG" and $adv['tip']==1)
{
echo "<div id='sol_reklam' >";
echo "<a href='".$adv['url']."' target='_blank' >";
echo "<img src='uploads/reklam/".$adv['dosya']."' width='217'  alt='' /></a>";
echo "</div>";
} 
else if( $bolum[1]=="swf" and $adv['tip']==2){
?>

<div id="sol_reklam">

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="217" >
  <param name="movie" value="uploads/reklam/<? echo $adv['dosya']; ?>" />
  <param name="quality" value="high" />
  <embed src="uploads/reklam/<? echo $adv['dosya']; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="217" ></embed>
</object> 
</div>

<?php	
} else if($adv['tip']==3) {
	
	echo "<div id='sol_reklam'>";
	  echo stripslashes($adv['script']);
	  echo "</div>";
	 
	  } else {} } // adv while
} // function




// SOl enl ala reklamlar
function reklam_solalt($tip)
{
$sqlk=mysql_query("SELECT id,url, dosya, tip, script from reklam where konum='".$tip."' and onay='1' limit 0,1"); 
 while( $adv=mysql_fetch_assoc($sqlk))
{
$bolum=explode( '.', $adv['dosya']);
if($bolum[1]=="png" || $bolum[1]=="jpg" || $bolum[1]=="jpeg" || $bolum[1]=="gif" || $bolum[1]=="JPG" || $bolum[1]=="GIF" || $bolum[1]=="JPEG" and $adv['tip']==1)
{
echo "<div id='sol_reklam'>";
echo "<a href='".$adv['url']."' target='_blank' >";
echo "<img src='uploads/reklam/".$adv['dosya']."' width='217' alt=''  /></a></div>";

} 
else if( $bolum[1]=="swf" and $adv['tip']==2){
?>
<div id="sol_reklam">
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="217" >
  <param name="movie" value="uploads/reklam/<? echo $adv['dosya']; ?>" />
  <param name="quality" value="high" />
  <embed src="uploads/reklam/<? echo $adv['dosya']; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="217" ></embed>
</object> 
</div>

<?php	
} else if($adv['tip']==3) {
	
      echo "<div id='sol_reklam'>";
	  echo stripslashes($adv['script']);
      echo "</div>";
	  } else {} } // adv while
} // function


?>




<?php
function para($rakam) {
    $rakam = sprintf('%.2f', $rakam);
    $rakam = str_replace(".",",",$rakam);
    while (true) {
        $temp = preg_replace('/(-?d+)(ddd)/', '$1.$2', $rakam);
        if ($temp != $rakam) {
            $rakam = $temp;
        } else {
            break;
        }
    }
    return $rakam;
}


?>