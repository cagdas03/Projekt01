﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >REHBERİMİZDE</div>
<div id="sol_modul_orta">
    
    <div class="solsektor kaykay" >
	<ul>
                   	
	<?php
	   $sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=1  and firma.onay=1 ");
	$nsay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=2  and firma.onay=1 ");
	$gsay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=3  and firma.onay=1 ");
	$asay=@mysql_num_rows($sorgu);
	 	$sorgu=mysql_query("SELECT ilan.id from ilan inner join firma on firma.id=ilan.fid where firma.uyeliktur=3 and firma.onay=1 and ilan.onay=1 ");
	$isay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT urun.id from urun inner join firma on firma.id=urun.fid where firma.uyeliktur=3 and firma.onay=1 and urun.onay=1 ");
	$usay=@mysql_num_rows($sorgu);
  
		
	?>
    <li><b><?php echo $asay; ?></b> Altın Firma</li>
    <li><b><?php echo $gsay; ?></b> Gümüş Firma</li>
    <li><b><?php echo $nsay; ?></b> Normal Firma</li>
    <li><b><?php echo $isay; ?></b> İlan </li>
    <li><b><?php echo $usay; ?></b> Ürün bulunmaktadır. </li>
      
  
</ul>
</div>


</div>
<div id="sol_modul_alt" ></div>
</div>

	