<?php
$dbhost = "localhost";
$dbuser = "d0197f47";
$dbpass = "93NaZHGEsGpTzpNq";
$dbname = "d0197f47";

// Mysql bağlantım
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Verbindung prüfen
if ($mysqli->connect_errno) {
    die("Veritabanına bağlanılamadı...<br>HATA: " . $mysqli->connect_error);
}

// Veritabanı karakter setini ayarla
$mysqli->set_charset("utf8");

// yarım kesilen substrt li kodları engeller
mb_internal_encoding("UTF-8");

$sql = "SELECT * FROM ayar WHERE id=1 LIMIT 0,1";
$sorgu = $mysqli->query($sql);

// Überprüfen, ob die Abfrage erfolgreich war
if (!$sorgu) {
    die("Sorgu hatası: " . $mysqli->error);
}

// Ergebnisse abrufen
$rowtt = $sorgu->fetch_assoc() or die("Veritabanı hatası: " . $mysqli->error);
$mailayar = $rowtt['email'];
$site_adi = $rowtt['site_adi'];
$iu_limit = $rowtt['iu_limit'];

// include açıkları için
define("TT_YAZILIM", true);

// Verbindung schließen
$mysqli->close();
?>