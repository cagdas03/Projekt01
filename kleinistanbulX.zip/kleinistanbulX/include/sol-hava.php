<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >HAVA DURUMU (Stuttgart)</div>
<div id="sol_modul_orta">

<?php

function DosyaAl($url){
$oturum = curl_init();
curl_setopt($oturum, CURLOPT_URL, $url);
$h4 = $_SERVER['HTTP_USER_AGENT'];
curl_setopt($oturum, CURLOPT_USERAGENT, $h4);
curl_setopt($oturum, CURLOPT_HEADER, 0);
curl_setopt($oturum, CURLOPT_RETURNTRANSFER, true);
$source=curl_exec($oturum);
curl_close($oturum);
return $source;
}
function havasil($q){
$ara   = array("ü","ş","ı","ğ","Ç","�","İ","Ş","ö","ç","<br />");
$degis = array("u","s","i","g","c"," ","i","s","o","c","");
$q = str_replace($ara ,$degis ,$q);
return $q;
}
$tarih = date("d.m.Y");
$aa = date("d");
$sor = mysql_fetch_array(mysql_query("select count(id) as toplam from havadurumu"));
if($sor["toplam"]){
$al = mysql_fetch_array(mysql_query("select * from havadurumu"));
$parca = explode(",",$al["ilk"]);
$sonun = explode(",",$al["son"]);
$dizi3[0] = $parca[0];
$dizi[0] = $parca[1];
$dizi2[0] = $parca[2];

$dizi30[0] = $sonun[0];
$dizix[0] = $sonun[1];
$dizi2[0] = $sonun[2];

}else{
$site =  DosyaAl("http://havadurumu.mynet.com/avrupa/gm/38334"); 
$dizi = explode("<span class=\"hvDate\">", $site); 
$dizi = explode("</span>", $dizi[1]);  
$dizi2 = explode("<img src=\"http://img3.mynet.com/havadurumu/durumlar/", $site); 
$dizi2 = explode("alt=", $dizi2[1]);  
$dizi3 = explode("<span class=\"hvMood\">", $site); 
$dizi3 = explode("</span>", $dizi3[1]);  
$dizi4 = explode("<span class=\"hvDeg1\">", $site); 
$dizi4 = explode("</span>", $dizi4[1]);  
$dizi5 = explode("<span class=\"hvDeg2\">", $site); 
$dizi5 = explode("</span>", $dizi5[1]);  
preg_match("'<td bgcolor=\"#fdfeeb\" height=\"25\">(.*?)</td>'si",$site,$xxxxxxx);
$dizix = explode("<tr><td bgcolor=\"#FFF4D2\" height=\"25\" width=\"60\">Adres :</td><td height=\"25\" bgcolor=\"#FDFEEB\">", $site); 
$dizix = explode("</td></tr>", $dizix[2]);  
$dizi20 = explode("<tr><td bgcolor=\"#FFF4D2\" height=\"25\" width=\"60\">Tel :</td><td height=\"25\" bgcolor=\"#FDFEEB\">", $site); 
$dizi20 = explode("</td></tr>", $dizi20[2]); 
 
$dizi30 = explode("<tr><td colspan=\"2\" bgcolor=\"#FBCE9D\" align=\"center\" height=\"10\">", $site); 
$dizi30 = explode("</td></tr>", $dizi30[2]);

$eczane1[] = $dizi3[0];
$eczane1[] = $dizi4[0]; 
$eczane1[] = $dizi[0];
$eczane1[] = $dizi2[0];

$eczane2[] = $dizi30[0];
$eczane2[] = $dizix[0];
$eczane2[] = $dizi2[0];


$ilk = implode(",",$eczane1);
$son = implode(",",$eczane2);
mysql_query("TRUNCATE TABLE eczane");
mysql_query("insert into eczane (ilk,son,gun) values('$ilk','$son','$aa')");
}

?>
<div style="float:left">
<img src="images/havadurumu/<?=$dizi2[0];?>" />
</div>
<div style="float:left; padding:5px; width:110px; font-size:13px;">
<br />
En Yüksek:<b><?=havasil($dizi4[0]);?></b> <br />              
En Düşük: <b><?=havasil($dizi5[0]);?></b>
</div>

</div>
<div id="sol_modul_alt" ></div>
</div>
