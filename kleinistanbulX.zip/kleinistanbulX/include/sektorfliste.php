<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">

<div id="ucluliste">

<?php 
$id=intval(temizle($_GET['id'])); 
$sektorsql=mysql_query("SELECT ustkat.ust_adi FROM firma inner join sektor on sektor.s_fid=firma.id inner join ustkat on ustkat.ust_id=sektor.s_ustid where firma.onay=1 and sektor.s_ustid=$id  ");
$sekadi=mysql_fetch_row($sektorsql);

?>
<div class="nerdeyim"><?php echo $sekadi['0']; ?> Sektöründeki Firmalar </div>

 <?php
 
 require_once 'lib/sayfalama.class.php';
 $sql="SELECT firma.id FROM firma inner join sektor on sektor.s_fid=firma.id inner join ustkat on ustkat.ust_id=sektor.s_ustid where firma.onay=1 and sektor.s_ustid=$id ";
 $sorgu=mysql_query($sql) or die(mysql_error());
 $db_count=mysql_num_rows($sorgu);
 
 	 if($db_count<1)
	 {
		 
	echo "<div class='hata' > Bu sektöre kayıtlı firma bulunmamaktadır. Eklemek için <a href='firma-ekle.html'> tıklayınız!</a></div>
	</div></div>
	";
	}
	else
	{

 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 4;
$pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
  $sql=mysql_query("SELECT firma.id, firma.adi, firma.logo, firma.uyeliktur FROM firma inner join sektor on sektor.s_fid=firma.id inner join ustkat on ustkat.ust_id=sektor.s_ustid  where firma.onay=1 and sektor.s_ustid=$id order by firma.uyeliktur desc, bastarih desc $pages->limit") or die(mysql_error());
 while($sorgu=mysql_fetch_assoc($sql))
 {
	 

	 
	 ?>


<div id="listekutu">
<p>

<a href="firmalar/<?php echo seo($sorgu['adi']); ?>_<?php echo $sorgu['id']; ?>.html" title="<?php echo $sorgu['adi']; ?>" />
<img src="images/paket<?php echo $sorgu['uyeliktur'];?>.png" />

    <?php if(empty($sorgu['logo'])) {
		echo "<img src='images/logoyok_liste.png' width='136' />";
	} else {
		 ?>
    <img src="uploads/logo/<?php echo $sorgu['logo']; ?>" width="136" height="94"  />
    <?php } ?>
   
    
<?php echo mb_substr( $sorgu['adi'],0,30,'UTF-8'); ?></a>





</p>
</div>

<?php
}

?>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
}
?>