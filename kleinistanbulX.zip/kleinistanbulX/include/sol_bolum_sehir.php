     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
    
    
    
    
<div id="sidebar">





<div id="sol_modul">
<div id="sol_modul_tepe" >ŞEHİR REHBERİ MENÜSÜ</div>

<div id="sol_modul_orta">
<?php include("include/sol-sehirmenu.php"); ?>

</div>
<div id="sol_modul_alt" ></div>
</div>




<div id="sol_modul">

 <?
 $sqlk=mysql_query("SELECT id,url, dosya from advert where tip='sol-ust' and onay='1' limit 0,1"); 
   while( $adv=mysql_fetch_assoc($sqlk))
{
					
include("rek-sol.php");

}
?>

</div>


<div id="sol_modul">
<div id="sol_modul_tepe" >ÜYELİK</div>

<div id="sol_modul_orta">
<A href="firma-ekle.html">
Üyelik türleri ve avantajlarını görmek için tıklayınız.</A>

</div>
<div id="sol_modul_alt" ></div>
</div>



<div id="sol_modul">
<div id="sol_modul_tepe" >REKLAMLAR</div>

<div id="sol_modul_orta">
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>
<A href="firma-ekle.html"><img src="uploads/reklam/rek200.png" class="rek200" /></A>


</div>
<div id="sol_modul_alt" ></div>
</div>


   </div>




