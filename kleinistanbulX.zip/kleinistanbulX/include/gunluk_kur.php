     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<div class="orta_modul">
<?php
$link = "http://www.mynet.com/include/finans/ticker/asp/smalldata.asp";



 if( ($satir = file($link)) ) {

  $piyasa = array();

  foreach( $satir AS $value ) {
	  
  	
   if( strpos($value, ";") ) {

    $value = explode(";", $value);

   $piyasa[ mb_substr($value[0],0,3,'UTF8') ] = array($value[1], $value[2]);

   }

  }



  $content = "	<div id=\"gunluk_kur\"><ul>\n";



 if( $piyasa['USD'][0] ) {

  
   if($piyasa['USD'][1] == "0" ) { $img =""; } elseif(substr($piyasa['USD'][1], 0, 1) == "-" ) { $img ="down"; } else { $img ="up"; }

   $content .= "<li class=\"dolar ".$img."\">Dolar<BR><span>".$piyasa['USD'][0]."</span></li>\n";

  }



  if ( $piyasa['EUR'][0] ) {

   if($piyasa['EUR'][1] == "0" ) { $img =""; } elseif(substr($piyasa['EUR'][1],0,1) == "-" ) { $img ="down"; } else { $img ="up"; }

   $content .= "<li class=\"euro ".$img."\">Euro<BR><span>".$piyasa['EUR'][0]."</span></li>\n";

  }



  if ( $piyasa['Alt'][0] ) {

   if($piyasa['Alt'][1] == "0" ) { $img =""; } elseif(substr($piyasa['Alt'][1],0,1) == "-" ) { $img ="down"; } else { $img ="up"; }

   $content .= "<li class=\"altin ".$img."\">Altın<BR><span>".$piyasa['Alt'][0]."</span></li>\n";

  }



 



  $content .= "	</ul></div>\n";





   echo $content;



   mysql_query("UPDATE gunluk_kur SET content='".addslashes($content)."', date='".time()."' WHERE name = 'piyasalar'");



 }

?>


</div>
