      <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
    
    <?php 
if($_SESSION['giris']==1 & $_SESSION['sid']>0)
{ 
 $sid=$_SESSION['sid'];

?>


   <div class="orta_modul">
<?PHP 
	  $sehir=temizle($_POST['sehir']);
	  $ilce=temizle($_POST['ilce']);
	  $adi=temizle($_POST['adi']);
	  $yetkili=temizle($_POST['yetkili']);
	  $adres=temizle($_POST['adres']);
	  $etiket=temizle($_POST['etiket']);
	  $tel=temizle($_POST['tel']);
	  $cep=temizle($_POST['cep']);
	  $fax=temizle($_POST['fax']);
	  $video=area($_POST['video']);
	  $web=temizle($_POST['web']);
	  $face=temizle($_POST['face']);
	  $email=temizle($_POST['email']);
	  $detay=addslashes($_POST['detay']);
	  $koordinat=area($_POST['koordinat']);
	  $zoom=intval($_POST['zoom']);
	  $uyeliktur=temizle($_POST['uyeliktur']);
	  $rastgele=rand(1000000,999999999);
	  // �ye Bildir I�in gerekli mscbur degil
	 
  include("securimage/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['gkod']);
  if($valid == true) 
    {
		  
		  
		  
		  
		  if( $sehir==""  || $ilce==""  )
		  {
			  
		echo "<div class='hata'> Form verilerinden bazılarında eksik tespit edildi; lütfen geri dönerek zorunlu alanları doldurunuz.</div>";
		echo "<meta http-equiv='refresh' content='4;URL=firma-ekle.html'> "; 
		
			  }
		  else
		  {
			  
	  	include("include/upload.php");
		
				
		if(isset($logoismi))	{   $qlogo=", logo='$logoismi' , ";	}	else	{   $qlogo=" , ";	}
		
		if($uyeliktur==1)
		{
			
			// mysql firma ekliyoruz  
   $ekle=mysql_query("UPDATE firma  SET adi='$adi'   ,yetkili='$yetkili'   ,adres='$adres',   tel='$tel',    fax='$fax',  etiket='$etiket',     sehir='$sehir',   
   cep='$cep' $qlogo ilce='$ilce' where id='$sid' and onay=1 ") or die(mysql_error());   
   
   
			}
			else
			{
	     
// mysql firma ekliyoruz  
   $ekle=mysql_query("UPDATE firma  SET adi='$adi'   ,yetkili='$yetkili'   ,adres='$adres',   tel='$tel',    fax='$fax',  etiket='$etiket',     sehir='$sehir',   ilce='$ilce',
   cep='$cep' $qlogo detay='$detay', web='$web', email='$email', face='$face', video='$video', koordinat='$koordinat', zoom='$zoom' where id='$sid' and onay=1 ") or die(mysql_error());    
			}
		
		
/////////////FIRMA RESIMLERI  D�ZENLENIYOR////////////////////////////////////////

					
					
					

 if($_FILES["userfile0"]["name"]=="" & $_FILES["userfile1"]["name"]=="" & $_FILES["userfile2"]["name"]=="" & $_FILES["userfile3"]["name"]=="" & $_FILES["userfile4"]["name"]=="" & $_FILES["userfile5"]["name"]=="" & $_FILES["userfile6"]["name"]=="" & $_FILES["userfile7"]["name"]=="" & $_FILES["userfile8"]["name"]=="" & $_FILES["userfile9"]["name"]=="")
   {
 
   }
   else
   {
//resim var ise sunlari yap//////////////////////////////////////////////////////////////////////////////////////////////////
 

///dosya0 islemleri///dosya0 islemleri///dosya0 islemleri///dosya0 islemleri///dosya0 islemleri
for($i=1;$i<=10;$i++)
{
if($_FILES["userfile$i"]["name"]=="")
{}else{
 ////  asagida kontrol yapiliyor
if ((($_FILES["userfile$i"]["type"] == "image/gif") || ($_FILES["userfile$i"]["type"] == "image/jpeg") || ($_FILES["userfile$i"]["type"] == "image/png")  || ($_FILES["userfile$i"]["type"] == "image/pjpeg")) && ($_FILES["userfile$i"]["size"] < 200000))
{
$rasgele=rand(100000,999999);
$uzanti = end(explode(".",$_FILES["userfile$i"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=oturumu-kapat.html'> ";
exit();
}
else
{
$dosya=$rasgele.'.'.$uzanti;
$resimekle="INSERT INTO firmaresim (firmaresim,fid,onay) VALUES ('$dosya','$sid', '1')"; 
$value = mysql_query($resimekle) or die("Bir hata oldu.:<br /> Error: (" . mysql_errno() . ") " . mysql_error()); 
move_uploaded_file($_FILES["userfile$i"]["tmp_name"],
"uploads/firmaresim/" . $dosya);

}
}
else
{
?>
Resim uzantısı sadece png,gif,jpg ya da jpeg olabilir.<br> 
Resimleriniz 200 KB den fazla olmamalıdır.<br>
<?
}

}
///dosya0 islemleri///dosya0 islemleri///dosya0 islemleri///dosya0 islemleri
}
//for d�ng�s� bitis
//resim uygulama alani bitisi//////////////////////////////////////////////////////////////////////////////////////////////////
}
	



/////////////SEKT�RLER  EKLENIYOR////////////////////////////////////////

switch ( $uyeliktur ) {
case 1:
    
	$sek_adet=1;
	$turadi="Normal";
    break;
	
case 2:
    $sek_adet=3;
	$turadi="Gümüs";
    break;
	
case 3:
    $sek_adet=5;
	$turadi="Altın";
    break;
	
default:
  $sek_adet=1;
  $turadi="Normal";
  break;
   
}


$sektoral=$_POST['fsektor'];
$gelensektor=count($sektoral);


if($gelensektor>$sek_adet)
{
	
	
	echo "<script>alert(' $turadi üyeliklerde firmanızı aynı anda en fazla $sek_adet adet sektöre ekleyebilirsiniz. Üyelik türünüzü yükselterek daha fazla sektöre firmanızı ekleyebilirsiniz. ');</script>";
	
	




}
else
{
	
	
$sektorsilold=mysql_query("DELETE from sektor where s_fid='$sid'");
if ($sektoral){foreach ($sektoral as $ustid){
// �nce eskileri silelim
// Yeni eskt�rleri ekleyelim.
$sektorekle=mysql_query("INSERT INTO sektor (s_id,s_fid,s_ustid) VALUES ('','$sid','$ustid')");
}}

}

 		
		if($ekle) { 
		 echo "<meta http-equiv='refresh' content='0;URL=panel_profilim.html'> "; 
		 echo "<div class='tebrik'>Tebrikler firmanız başarıyla düzenlendi. Şimdi yönlendiriliyorsunuz. </div>"; }
		 else {
		 echo "<meta http-equiv='refresh' content='1;URL=panel_profilim.html'> "; 
		 echo "<div class='hata'>Firma Veritabanına Eklenirken bir hata oluştu. Tekrar denemeniz için firma düzenleme sayfasına yönlendiriliyorsunuz.</div>";}                               
                                 


// Admine email g�nderiliyor.
$subject = "Firma Düzenlendi | ".$adi ;  
$message_contents = "
<p><b>Firma Adı:<b> " .$adi." </p>
<p><b> Kullanıcı Adı:</b> ".$username."</p>
<p> Yönetim paneline giderek firmayı denetlemeyi unutmayınız. </p>"; 
 $header= "Content-type: text/html; charset='utf-8'\r\n";  
$header.= "From:$mailayar\r\n"; 

mail($mailayar,$subject,$message_contents,$header);  

// Dosya daha �nce y�klenmemi�
// Dosya hatas� yok
 // Dosya Uzant�lar�nda Sorun Yok



		  }
// Dosya varsa yap�lacaklar.
// Shell kontrol sonu
    
	}
	else
	{
		echo "<meta http-equiv='refresh' content='4;URL=panel_profilim.html'> "; 
		 echo "<div class='hata'>Güvenlik kodunu yanlış girdiniz, tekrar denemek için geri <a href='panel_profilim.html' > yönlendiriliyorsunuz..</a></div>";
	
	}
?>  
					
  </div>
                  	
                    
                         <?php } else { 
			echo "<script>window.top.location.href = 'index.html';</script>";
			}?>				
            				
