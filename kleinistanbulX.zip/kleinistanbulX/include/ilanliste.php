     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
    <div class="orta_modul">

<div id="uclu">
 <?php
 
 $tip=intval(temizle($_GET['tip']));
 
 if(!empty($tip))
 {
 $sorgula="SELECT id FROM  ilantip where id='$tip' limit 0,1";
 $quer=mysql_query($sorgula) or die (mysql_error());
 $tipsay=@mysql_num_rows($quer);
 if($tipsay<1)
 {
echo "<script>window.top.location.href = '../index.html';</script>";	 
echo "Böyle bir ilan tipi bulunmamaktadır.";
 }
 }
 
  
 $sql=mysql_query("SELECT id,itip_adi FROM  ilantip order by id asc ");
 while($sorgu=mysql_fetch_assoc($sql))
 {
	
$saysql=mysql_query("SELECT ilan.id from ilan inner join firma on firma.id=ilan.fid  inner join ilantip on ilan.tip=ilantip.id  where ilan.onay=1 and ilantip.id=$sorgu[id]"); 
$say=mysql_num_rows($saysql);
?>


<div id="sektorkutu">
<p><a href="ilanlar/<?php echo seo($sorgu['itip_adi']); ?>_ilantip<?php echo $sorgu['id']; ?>.html" title="<?php echo $sorgu['itip_adi']; ?>" />
<?php 
if($tip==$sorgu['id']) { echo "<b class='red'>".$sorgu['itip_adi']."</b>" ; } else { echo $sorgu['itip_adi']; }  ?></a><span> <b>(<?php echo $say;?>)</b>
</span>
</p>
</div>

<?php
}
?>

</div>
</div>


<div class="orta_modul">
<div id="ucluliste">


<table class="tablox">
<tbody>
<tr>
<th>İlan Başlığı</th>
<th width="32%">Firma Adı</th>
<th width="16%">İlan Tipi</th>
<th width="12%">Tarih</th>
</tr>

 <?php
 require_once 'lib/sayfalama.class.php';
 
 
  $kosul = ' ';
 if($tip>'' and $tip!=0){ $kosul = $kosul . ' and ilan.tip='.$tip.''; }
 
 
 $db_count=@mysql_num_rows(mysql_query("SELECT ilan.id FROM ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilan.tip=ilantip.id  where 1 ".$kosul." and  firma.onay=1 and ilan.onay=1 and firma.uyeliktur=3 "));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
 $pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
 
 $sql=mysql_query("SELECT ilan.id, ilan.ilan_baslik, ilan.ilan_etiket, ilan.ilan_detay,  firma.adi, sehir.ad, ilce.ilce_adi , ilantip.itip_adi, ilan.ilan_bas_tarih FROM ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilan.tip=ilantip.id   inner join sehir on firma.sehir=sehir.id inner join ilce on firma.ilce=ilce.ilceid where 1 ".$kosul."     and firma.onay=1 and ilan.onay=1 and firma.uyeliktur=3 order by ilan.ilan_bas_tarih desc $pages->limit") or die(mysql_error());
 while($ilan=mysql_fetch_assoc($sql))
 {?>
 
<tr>
<td> <a title="<?php echo $ilan['ilan_baslik']; ?>" href="ilanlar/<?php echo seo($ilan['ilan_baslik']) ;?>_<?php echo $ilan['id']; ?>.html" ><?php echo $ilan['ilan_baslik']; ?></a></td>
<td> <a title="<?php echo $ilan['ilan_baslik']; ?>" href="ilanlar/<?php echo seo($ilan['ilan_baslik']) ;?>_<?php echo $ilan['id']; ?>.html" ><?php echo $ilan['adi']; ?> </a></td>
<td><?php echo $ilan['itip_adi']; ?></td>
<td><?php echo tt_tarih($ilan['ilan_bas_tarih']); ?></td>

</tr>



<?php
}

?>
</tbody>
</table>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>