﻿     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
              <div class="navigation"> 
                        <ul style="font-weight:bold;">
<li><a href="<?php echo $rowtt['site_url'];  ?>" title="Firma rehberi" <?php if( empty($_GET['pg']) ) { echo "class='homenav'";} else { ?> class="homecurrent" <?php }?> >Ana Sayfa</a></li><li class="navsep"></li>
<li><a href="/sektorler" title="Sektörler" <?php if(  $_GET['pg']=="sek" || $_GET['pg']=="sekl" ) { echo "class='current'";} else { ?> class="ttnav" <?php }?>>Sektörler</a></li><li class="navsep"></li>
<li><a href="/firmalar" title="Firmalar" <?php if ($_GET['pg']=="fe" || $_GET['pg']=="fk" ||  $_GET['pg']=="fd" ||  $_GET['pg']=="fl" ) { echo "class='current'";} else { ?> class="ttnav" <?php }?>>Firmalar</a></li><li class="navsep"></li>
<li><a href="/urunler" title="ürünler" <?php if(  $_GET['pg']=="ul" || $_GET['pg']=="urund" ) { echo "class='current'";} else { ?> class="ttnav" <?php }?>>Ürünler</a></li><li class="navsep"></li>
<li><a href="/ilanlar" title="ilanlar" <?php if($_GET['pg']=="il" || $_GET['pg']=="iland") { echo "class='current'";} else { ?> class="ttnav" <?php }?>>İlanlar</a></li><li class="navsep"></li>

<li><a href="/haberler" title="haberler" <?php if($_GET['pg']=="hl" || $_GET['pg']=="haberd") { echo "class='current'";} else { ?> class="ttnav" <?php }?>>Haberler</a></li><li class="navsep"></li>


<li><a href="iletisim.html" title="iletişim" <?php if( $_GET['pg']=="ltsm" ) { echo "class='current'";} else { ?> class="ttnav" <?php }?>>İletişim</a></li><li class="navsep"></li>
<li class="welcome"></li>
<?php  if ($_SESSION['giris']==1) {?>

<li><a href="firma-panel.html" title="" class="fgiris">Hesabım</a></li>
<li><a href="oturumu-kapat.html" title="" class="logoutbtn">Çıkış Yap</a></li></ul>

<?php } else {?>
<li><a href="firma-giris.html" title="" class="fgiris">Giriş Yap</a></li>
<li><a href="firma-ekle.html" title="" class="logoutbtn">Firma Ekle</a></li></ul> 

<?php }?>


                    </div>
                    <div class="navialt">
                      <ul style="font-weight:bold;">
                      <?php
					  $navipg=temizle($_GET['pg']);
					  if(empty($navipg))
					  
					  {
						  
					      $sorgu=mysql_query("SELECT id, adi ,url from sayfa  where pg='ana'and onay=1 order by sira asc") or die(mysql_error());
						  while($navialt=mysql_fetch_assoc($sorgu))
				          {
							
							if(empty($navialt['url']))
							{						  
							  	echo "<li><a class='altlink' href='sayfa/".seo($navialt['adi'])."_".$navialt['id'].".html'>".$navialt['adi']."</a>
						  </li><li class='navsep'></li>";
						     
							}
							else
								
							{
							    echo "<li><a class='altlink' href='".$navialt['url']."' >".$navialt['adi']."</a>
						  </li><li class='navsep'></li>";
								
							}
						  
						   }
						  
					  }
					  else
					  {					  
						  $sorgu=mysql_query("SELECT * from sayfa where pg='$navipg' and onay=1 ");
						  $saypg=mysql_num_rows($sorgu);
						 
						  if($saypg==0)
						  {  $navyeni="ana"; }
						  else
						  {	 $navyeni=$navipg; }
						  
						  $ysorgu=mysql_query("SELECT id, adi ,url from sayfa where pg='$navyeni' and onay=1  order by sira asc");
						  while($navialt=mysql_fetch_assoc($ysorgu))
				          {	
						  
						  if(empty($navialt['url']))
						  {
						  
						  echo "<li><a class='altlink' href='sayfa/".seo($navialt['adi'])."_".$navialt['id'].".html'>".$navialt['adi']."</a> </li>
						  <li class='navsep'></li>"; 
						  }
						  else 
						   
						   {
									    echo "<li><a class='altlink' href='".$navialt['url']."' >".$navialt['adi']."</a>
						  </li><li class='navsep'></li>";  
							  
						   }
						  
						  
					  
					  }
					  			  
					  }
					  
					   ?>
                      
                     
                   
                      
                      </ul>
                    
                    </div>
		
			