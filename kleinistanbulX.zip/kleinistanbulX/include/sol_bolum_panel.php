     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
     
    
    
<div id="sidebar">

<div id="sol_modul">
<div id="sol_modul_tepe" >ÜYE MENÜSÜ</div>

<div id="sol_modul_orta">
<?php include("include/sol-panelmenu.php"); ?>

</div>
<div id="sol_modul_alt" ></div>
</div>

<?php include("include/sol-sonfirmalar.php"); ?>


   </div>




