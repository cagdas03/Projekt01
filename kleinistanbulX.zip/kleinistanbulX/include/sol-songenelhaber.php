﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >SON EKLENEN HABERLER</div>
<div id="sol_modul_orta">
    
    <div class="solsektor kaykay" >
	<ul>
   <?php
$sql="SELECT manset.id, manset.manset_baslik, manset.manset_etiket from manset inner join mansetkat on mansetkat.mid=manset.kat  where manset.onay='1' order by manset.bastarih desc limit 0,10";

$sorgu=mysql_query($sql);
$sirano=1;
while($alim=mysql_fetch_array($sorgu))
{
$sef=seo($alim['manset_baslik']);
?>
<li><a href="manset/<? echo $sef;?>_<? echo $alim['id'];?>.html" title="<? echo $alim['manset_etiket']; ?> | <? echo $alim['manset_baslik']; ?>"><? echo mb_substr($alim['manset_baslik'],0,25,'UTF-8')  ?></a></li>
<? 
$sirano++;
} ?>      
  
</ul>
</div>


</div>
<div id="sol_modul_alt" ></div>
</div>

	
    
    
    
    
    
    



