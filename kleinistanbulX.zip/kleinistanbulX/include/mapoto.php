     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
	<?php
$adres = ereg_replace(" ","+",$firma['adres']);
$adresyaz=$firma['ilce_adi'];
$yeniadres=$adres.'+'.$adresyaz;
$geocode=file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.$yeniadres.'&sensor=false');//haritada göstereceðiniz adres boþluklar yerine + iþareti girmelisiniz
$output= json_decode($geocode);
$lat = $output->results[0]->geometry->location->lat;
$lon = $output->results[0]->geometry->location->lng;
$lat=str_replace(",",".",$lat);
$lon=str_replace(",",".",$lon);
?>
<style type="text/css"> 
  #map_canvas { height: 450px;width: 725px }
</style>

<script type="text/javascript"> 
  function initialize() {
    var myLatlng = new google.maps.LatLng(<?php echo $lat; ?>, <?php echo $lon; ?>);
    var myOptions = {
      zoom: 15,
      center: myLatlng,
	       mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	var marker = new google.maps.Marker({map: map, position:map.getCenter()});
	
  }
  
  function loadScript() {
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "http://maps.google.com/maps/api/js?sensor=false&callback=initialize";
    document.body.appendChild(script);
  }
  
  
  window.onload = loadScript;
</script>

</head>
<body>
  <div id="map_canvas"></div>
</body>
</html>
