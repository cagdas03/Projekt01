<?php //Cache Sistemi-- Başlangıç
 $filename = "%%-".md5($_SERVER['REQUEST_URI'])."-%%.html";
 $cachefile = "cache/".$filename;
 $cachetime = 3 * 60 * 60;
 if (file_exists($cachefile))
 { if(time() - $cachetime < filemtime($cachefile))
 { readfile($cachefile); exit; }
 else { unlink($cachefile); } } 
//Cache Sistemi -- Başlangıç
?>