     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<div class="orta_modul">
<div id="uclu">
<script type="text/javascript">
function login_validator(theForm)
{	
if(document.getElementById('username').value == "Kullanıcı Adınız" || document.getElementById('username').value == "" || document.getElementById('password').value == "") {
 alert("Kullanıcı Adı ya da Şifre Giriniz");
 document.getElementById('username').focus();
 return(false);
}

return (true);
}
</script>


<div id="giris-sol">
<form action="index.html" method="post" onSubmit="return login_validator()" >
<input type="hidden" name="action" value="do_login" />
<br />
<br />
<br />
<br />
<dl>
<dt>Kullanıcı Adı</dt><dd><input type="text" name="username" id="username" /></dd>
<dt>Şifre</dt><dd><input type="password" name="password" id="password" /></dd>
<dt><a href="sifre-unuttum.html">Şifre Unuttum</a></dt><dd><input type="image" src="images/giris_b.png" name="log_in"  style="border:none" /><br />

</dd>

</dl>

</form>



</div>

<a href="firma-ekle.html">
<div id="giris-sag">

</div>
</a>




</div>



</div>