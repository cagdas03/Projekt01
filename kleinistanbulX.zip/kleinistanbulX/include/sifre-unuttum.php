
<script type="text/javascript" >

$().ready(function() {
	
	$("#cmxform").validate({
		rules: {
			
			email: {required: true,	email: true	},
			
		},
		
		messages: {
			email: "Geçerli email adresi giriniz",
			}
	});
	
	});

</script> 


<div class="orta_modul">


<form class="cmxform" id="signupForm" name="lostpass" action="sifre-unuttum.html" method="POST">
	<fieldset>
    <p>
	<dl>
    <dt>Email Adresiniz:</dt><dd> <input type="text" name="email" id="email"  style="width:290px;"></dd>
    </dl>
    
    	<dl>
    <dt>Kullanıcı Adınız:</dt><dd> <input type="text" name="user" id="user"  style="width:290px;"></dd>
    </dl>
    </p>
    
    	<dl>
    <dt></dt><dd>  <input type="submit"  class="tt-btn tt-btn-red" name="submit" value="Gönder" >  </dd>
    </dl>
               
               
                                 

     </fieldset>                   
	

	</form>







    
<?php
if(isset($_POST['email']))
{
$email=temizle(trim($_POST['email']));
$user=temizle(trim($_POST['user'])); 
$sorgu=mysql_query("SELECT username,password from firma where email='$email' and username='$user' order by bastarih desc limit 0,1");
$sonuc=mysql_fetch_row($sorgu);
$say=@mysql_num_rows($sorgu);
if($say<1){echo "<div class='hata'>Bu e-maile kayıtlı kullanıcı bulunamadı.</div>"; }
else
{
$yenisifre=rand(1000000,9999999);
$yenimd=md5($yenisifre);
$update=mysql_query("UPDATE firma SET password='$yenimd' where email='$email' and username='$user' order by bastarih desc") or die(mysql_error());

echo "<div class='tebrik'>Yeni şifreniz e-mail adresinize gönderildi.</div>";

//email gönderiliyor

// Ziyaretçiye gönderilen mail bilgileri
$subject = $rowtt['site_adi']."-Şifre Hatırlatma";  
$message_contents2 = "<p>Yeni bir şifre isteğinde bulundunuz</p>
<p>Kullanıcı Adınız:<b>".$sonuc['0']." </b></p>
<p>Yeni Şifreniz:<b>".$yenisifre." </b></p>";
$header2= "Content-type: text/html; charset='UTF-8'\r\n"; 
$header2.="From:".$rowtt['email']."\r\n";    

@mail($email,$subject,$message_contents2,$header2);  

}
 
}?>

</div>
 

           
                