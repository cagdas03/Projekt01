     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
     <div class="orta_modul">
     
               <div class="AmansetMenuSistemi" >
                    <ul>
                <li>
                    <div class="AresimlerGosterilecek"> &nbsp;</div>
                </li>
     

<?php 

$sql="SELECT mansetresim, manset_baslik, id, manset_url, sabit from manset where  onay=1 order by sabit desc, bastarih desc limit 0,13";
$sorgu=mysql_query($sql) or die(mysql_error());
$sirano=1;
while($slide=mysql_fetch_array($sorgu))
{
	
if($sirano==1)
{$sinif="AaktifResim";}
else
{ $sinif="aktifResim";}
	
	?>
<li>

<?php 
if($slide['manset_url']==""){echo "<a href='manset/".seo($slide['manset_baslik'])."_".$slide['id'].".html'>";}
else {echo "<a target='_blank' href='http://".$slide['manset_url']."'>"; }
echo $sirano;
?>
<img src="uploads/manset/<?php echo $slide['mansetresim'] ;?>" width="427" height="225" alt="<?php echo $slide['manset_baslik'] ;?>" class="<?php echo $sinif;?>"/>

</a>
</li>

<?php
$sirano++;
}
?>

</ul>
            
<div class="tumhaber">
<a HREF="/haberler" > <img id="img1"   src="images/mansetbg.png"    alt="Tüm haberler"   onmouseover="mouseOverImage()" onmouseout="mouseOutImage()" /></A>
</div>

</div>
   

<?php 
reklam_300(manset_sagi);

?>
</div>


