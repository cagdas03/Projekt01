     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="740" height="330" id="harita" align="middle">

	<param name="allowScriptAccess" value="sameDomain" />

	<param name="allowFullScreen" value="false" />

	<param name="movie" value="harita.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#D1DFE7" />	<embed src="harita.swf" quality="high" bgcolor="#D1DFE7" width="740" height="330" name="harita" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />

  </object>
	
		
