       <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.php';</script>";
   exit();
    } ?>
    
   <div  class="orta_modul" >
  <div class="slideshow" id="multiple_slides_visible"></div>
  </div>
      
  <script>
    $.getJSON("include/vitrin_data.php", function(data) {
        $(document).ready(function(){
            $("#multiple_slides_visible").agile_carousel({
                carousel_data: data,
                carousel_outer_height: 210,
                carousel_height: 130,
                slide_height: 180,
                carousel_outer_width: 760,
                slide_width: 190,
                number_slides_visible:4,
                timer: 8000,
                transition_time: 3300,
                control_set_1: "previous_button,next_button",
                control_set_2: "group_numbered_buttons",
                persistent_content: "<p class='persistent_content'>Vitrin Firmalar</p>"       
            });
        });
    });
</script>
  


