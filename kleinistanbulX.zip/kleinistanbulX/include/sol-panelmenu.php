<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?>    
    <div class="solsektor kaykay" >
	<ul>
                   	
    
   <li><a href="panel_profilim.html" ><b class="red">Profilim</b></a></li>
   <li><a href="panel_ilanlar.html" ><b class="red">İlanlarım</b></a></li>
   <li><a href="panel_urunler.html" ><b class="red">Ürünlerim</b></a></li>
   <li><a href="panel_haberler.html" ><b class="red">Haberlerim</b></a></li>
   
      
</ul>
</div>


	