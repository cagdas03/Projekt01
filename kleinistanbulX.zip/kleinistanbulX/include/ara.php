
     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
    
				<div class="orta_modul">
				<?php
					$ustkat=intval(temizle($_GET['ustkat']));
					$sehir=intval(temizle($_GET['sehir2']));
					$ilce=intval(temizle($_GET['ilce2']));
					$tur=temizle($_GET['tur']);
	   			   $kelime=temizle($_GET['kelime']);
				 
							
					?>
					<?php
					
					//Eger se�ilen tablo firma ise asagidakileri yapacak
				switch($tur) 
				{
	case firma:
	include("include/arafirma.php");
	break;
	case ilan:
	include("include/arailan.php");
	break;
	case urun:
	default:
	include("include/araurun.php");
	}
			?>	
					
					
		</div>