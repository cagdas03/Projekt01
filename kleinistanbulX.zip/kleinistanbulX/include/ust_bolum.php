     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
 <?php 
  include("include/fonksiyon.php");
  include("include/fonksiyon-ek.php");
  include("include/kontrol.php");
  include ("include/header.php");
  include("include/mailing.php"); 

 ?>

<body>
<div id="wrapper">

<div id="tepe">
<div id="logo">
<a href="index.html" title="Firma Rehberi">
<img src="images/logo.jpg" width="190" height="98" />
</a>
</div>
<?php reklam_ana(logosag);?>
</div>


<!-- end #wrapper -->
<div id="yenimenu">
<?php  include('include/menu.php');?>

</div>

<div id="arabox" >

<form action="index.php" method="get" id="arama_form">
	  <script type="text/javascript" charset="utf-8">
          $(function(){
              $("#ilce2").chained("#sehir2"); 
          });
          </script>
	
    <div class="cerceve">
<select name="tur" id="tur" <?php if($_GET["tur"]!='') { echo "class='arasecili'"; } ?> >  
  <option <?php if($_GET["tur"]=="firma") echo "selected='selected' class='arasecili' "; ?> value="firma">Firmalar</option>  
  <option <?php if($_GET["tur"]=="ilan") echo "selected='selected' class='arasecili'"; ?> value="ilan">İlanlar</option>  
  <option <?php if($_GET["tur"]=="urun") echo "selected='selected' class='arasecili'"; ?> value="urun">Ürünler</option>  
</select>
</div>


 <div class="cerceve">
 <select name="ustkat" id="ustkat"  <?php if($_GET["ustkat"]!='') { echo "class='arasecili'"; } ?> >   
  <option value="">Tüm Sektörler</option>  
<?php  
$sql="SELECT ust_id,ust_adi from ustkat order by ust_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{ ?>  
<option <?php if($_GET["ustkat"]==$array['ust_id']) echo "selected='selected'"; ?> value="<?php echo $array['ust_id'] ;?>"> <?php echo $array['ust_adi']; ?> </option>  
<?  }  ?>  

</select>
</div>

 <div class="cerceve">
<select name="sehir2" id="sehir2"  <?php if($_GET["sehir2"]!='') { echo "class='arasecili'"; } ?> >    
  <option value="">Tüm Eyaletler </option>  

<?php  
$sql="SELECT id,ad from sehir order by id asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  
?>  
<option <?php if($_GET["sehir2"]==$array['id']) echo "selected='selected'"; ?> value="<?php echo $array['id'] ;?>"> <?php echo $array['ad']; ?> </option>  

<? }  ?>  
</select>
</div>

 <div class="cerceve">

  <select name="ilce2" id="ilce2" <?php if($_GET["ilce2"]!='') { echo "class='arasecili'"; } ?> >  
  <option value="" class="">Tüm İlçeler</option> 
<?php  
$sql="SELECT ilce.ilce_adi, ilce.ilceid, sehir.ad , sehir.id from ilce inner join  sehir on sehir.id=ilce.sehir order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  ?>  
<option <?php if($_GET["ilce2"]==$array['ilceid']) echo "selected='selected' "; ?> value="<?php echo $array['ilceid'] ;?>" class="<?php echo $array['id'];?>"> <?php echo $array['ilce_adi']; ?> </option>  

<?php } ?>  
</select>
</div>
 <div class="cerceve">
<input type="text" <?php if($_GET["kelime"]!='') { echo "class='arasecili'"; } ?> name="kelime" id="aranan-kelime" value="<?php if(!empty($_GET['kelime'])) {  echo temizle($_GET['kelime']); } else { echo "Aranacak Kelime" ; }?>"  >


</div>
<input type="hidden" name="pg" value="ara" />
<input type="submit"  value="ARA" class="tt-btn tt-btn-red"/> 

</form>
</div>










