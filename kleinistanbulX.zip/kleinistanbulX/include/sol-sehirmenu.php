<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

    
    <div class="solsektor kaykay" >
	<ul>
                   	
	<?php
	$sorgu=mysql_query("SELECT menu, id from sehirmenu where onay=1 order by menu asc limit 0,100");
	$count=@mysql_num_rows($sorgu);	
	while($yaz=mysql_fetch_assoc($sorgu)) {
	$sef=seo($yaz['menu']);
	?>
    
   <li><a href="kahramanmaras/<?php echo $sef; ?>_<?php echo $yaz['id']; ?>.html" title="<?php echo $yaz['menu']; ?>" ><?php echo $yaz['menu']; ?></a></li>


 
    <?php 
	}
  
?>
      
</ul>
</div>


	