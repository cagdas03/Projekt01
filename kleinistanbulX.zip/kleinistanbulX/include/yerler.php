<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">




<div id="uclu">

<div id="fdtek">
Aşağıdaki firmalar Gümüş ve Altın Üye olarak firmalarını google map üzerinde işaretleyen firmalarımızdır. Siz de bu haritada yer almak istiyorsanız <a href="firma-ekle.html"> tıklayınız.</a> <span style="color:#F00"> Kırmızı işaretler </span> üzerine tıklayarak firma detaylarına ulaşabilirsiniz.

</div>




  

 
  <div id="map" style="width: 725px; height: 600px;"></div> 

  <script type="text/javascript"> 
    var locations = [ 
	
	
		<?php
$sql="SELECT firma.adi, firma.id, firma.koordinat, firma.logo, firma.adres from firma inner join sehir on sehir.id=firma.sehir  where firma.uyeliktur>1 and firma.onay=1 and firma.zoom>0 and firma.koordinat>0 ";
$sorgu=mysql_query($sql) or die(mysql_error());
$max = mysql_num_rows($sorgu);

$i=0;
while($array=mysql_fetch_row($sorgu)) 
{ 



$seokat=seo($array['0']);
echo "['<img src=uploads/logo/".$array[3]." width=200 height=138 ><br><a href=firmalar/".$seokat."_".$array['1'].".html>".$array[0]."</a><br>".str_replace(","," ",$array[4])."',".$array['2']." ,".$i."]";
$i++;
if($i!=$max) echo " , ";

}
?>
    
	  
	  
    ]; 

    var map = new google.maps.Map(document.getElementById('map'), { 
      zoom: <?php echo $rowtt['tt_zoom'] ?>, 
      center: new google.maps.LatLng(<?php echo $rowtt['tt_koordinat'] ?>, <?php echo $rowtt['tt_zoom'] ?>), 
      mapTypeId: google.maps.MapTypeId.ROADMAP 
    }); 

    var infowindow = new google.maps.InfoWindow(); 

    var marker, i; 

    for (i = 0; i < locations.length; i++) {   
      marker = new google.maps.Marker({ 
        position: new google.maps.LatLng(locations[i][1], locations[i][2]), 
        map: map 
      }); 

      google.maps.event.addListener(marker, 'click', (function(marker, i) { 
        return function() { 
          infowindow.setContent(locations[i][0]); 
          infowindow.open(map, marker); 
        } 
      })(marker, i)); 
    } 
  </script> 

</div>
</div>