<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">


<div id="uclu">
<div id="uclu-sol">
<p id="uclu-bas">Son Eklenen İlanlar</p>
<ul>

<?php
$sql="SELECT ilan.id,ilan.ilan_baslik, ilan.ilan_etiket, firma.uyeliktur from ilan inner join firma on firma.id=ilan.fid where  ilan.onay='1' and firma.onay=1 and firma.uyeliktur=3 order by ilan.ilan_bas_tarih desc limit 0,10";
$sorgu=mysql_query($sql);
$sirano=1;
while($alim=mysql_fetch_array($sorgu))
{
$sef=seo($alim['ilan_baslik']);
?>
<li id="uclu-li" >
<? echo $sirano;?>. <a href="ilanlar/<? echo $sef;?>_<? echo $alim['id'];?>.html" title="<? echo $alim['ilan_baslik']; ?> | <? echo $alim['ilan_etiket']; ?>">
<?php echo mb_substr($alim['ilan_baslik'],0,30,'UTF-8'); ?>
</a></li>
<? 
$sirano++;
} ?>
</ul>
</div>

<div id="uclu-orta">

<ul class="tabs" style="border-bottom: 2px solid #DED8D8; padding-bottom:7px;">
     <li><a href="#tab1"><b class="coktik">Çok Tıklananlar:</b></a></li>
    <li><a href="#tab1" class="active">BUGÜN</a></li>
    <li><a href="#tab2">BU AY</a></li>
    <li><a href="#tab3">BU YIL</a></li>
  
   
</ul>


<?php include("include/sol-bugunbuay.php");  ?>

</div>


<div id="uclu-sag">
<p id="uclu-bas">Son Eklenen Ürünler</p>
<ul>

<?php
$sql="SELECT urun.id,urun.urun_baslik,urun.urun_etiket, firma.uyeliktur from urun inner join firma on firma.id=urun.fid where  urun.onay='1' and firma.onay='1' and firma.uyeliktur=3 order by urun.urun_bas_tarih desc limit 0,10";
$sorgu=mysql_query($sql);
$sirano=1;
while($alim=mysql_fetch_array($sorgu))
{
$sef=seo($alim['urun_baslik']);
?>
<li id="uclu-li" ><? echo $sirano;?>. <a href="urunler/<? echo $sef;?>_<? echo $alim['id'];?>.html" title="<? echo $alim['urun_baslik']; ?> | <? echo $alim['urun_etiket']; ?>"><? echo mb_substr($alim['urun_baslik'],0,30,'UTF-8')  ?></a></li>
<? 
$sirano++;
} ?>
</ul>

</div>


</div>

</div>