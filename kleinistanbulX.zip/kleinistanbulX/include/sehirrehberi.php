<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">

<div id="uclu">

 <?php
 require_once 'lib/sayfalama.class.php';
 $db_count=mysql_num_rows(mysql_query("SELECT id FROM  sehirmenu where onay=1 "));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
  $pages->default_ipp = 30;
 $pages->paginate();
 
 $sql=mysql_query("SELECT id,menu,etiket FROM  sehirmenu order by menu asc $pages->limit") or die(mysql_error());
 while($sorgu=mysql_fetch_assoc($sql))
 {
	
$sqlm="SELECT sehirmenu_detay.id from sehirmenu_detay  inner join sehirmenu on sehirmenu.id=sehirmenu_detay.kat where sehirmenu_detay.onay=1 and sehirmenu_detay.kat=".$sorgu['id']."";
$saysql=mysql_query($sqlm) or die(mysql_error()); 
$say=mysql_num_rows($saysql);
?>


<div id="sektorkutu">
<p><a href="kahramanmaras/<?php echo seo($sorgu['menu']); ?>_<?php echo $sorgu['id']; ?>.html" title="<?php echo $sorgu['etiket']; ?>" /><?php echo $sorgu['menu']; ?></a><span> <b>(<?php echo $say;?>)</b></span>
</p>
</div>

<?php
}

?>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>