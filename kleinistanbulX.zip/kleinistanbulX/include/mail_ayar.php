<?php
require_once('../lib/phpmailer/class.phpmailer.php');
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$yourmail="tanermacit@gmail.com";
$yourpass="7121471??";
$yoursub=$siteadi;

$mail             = new PHPMailer();
$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "mail.yourdomain.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
$mail->CharSet = 'UTF-8';
$mail->SetLanguage("tr", "phpmailer/language"); //default olarak  "en" dir. Biz türkçe kullanacağız dedik 
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
$mail->Port       = 465;                   // set the SMTP port for the GMAIL server
$mail->Username   = $yourmail;  // GMAIL username
$mail->Password   = $yourpass;            // GMAIL password
$mail->SetFrom($yourmail, $yoursub);
$mail->AddReplyTo($yourmail, $yoursub);
$mail->Subject    =$konu;
$mail->MsgHTML($mesaj);
$mail->AddAddress($kime, $yoursub);
if(!$mail->Send()) { echo "Hata: " . $mail->ErrorInfo;} else { echo "<br><div class='tebrik'>Tebrikler mail gönderildi.</div>"; }
?>