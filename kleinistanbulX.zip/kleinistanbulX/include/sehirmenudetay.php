<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<?php $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT sehirmenu_detay.id FROM sehirmenu_detay where id='$id' limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
$sorgu=mysql_query("SELECT * FROM sehirmenu_detay where id='$id' limit 0,1");
while($sayfa=mysql_fetch_assoc($sorgu)){?>


<div class="orta_modul">
<div id="uclu">
<div id="detay-hadi">
<?php echo $sayfa['baslik']; ?>
</div>
   

<div id="fdtek">
<div class="haberdetay mt5" >
<p ><b><?php echo $sayfa['baslik']; ?></b></p>
<p><?php echo $sayfa['detay']; ?></p>
</div>
<div class="haberdetay">
<?php include("include/facelike.php"); ?>

</div>


</div>
</div>
</div>

 
 <?php }}?>