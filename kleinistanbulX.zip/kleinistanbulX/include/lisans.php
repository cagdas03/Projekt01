<?php
$lisans_anahtar='D82E-F463-B64E-C81A-D034-47E4-7CD2-3FF0';

?> 