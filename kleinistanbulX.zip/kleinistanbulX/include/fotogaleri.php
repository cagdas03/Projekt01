     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>   
    <!-- Ativando o jQuery lightBox plugin -->
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>

    <?php 
         // Aşağısı onmouseover çalıştırmak için
    /* "<img src='<?php echo $ffoto; ?>' name='PhotoBig' style=' float:left;' > <br><br>";  */
	
	?>
    <img src='images/buyuk.png'  style=' float:left;' > 
    
	<span id="gallery">

    <ul>
	
	<?php 	
	$sql="SELECT firmaresim from firmaresim where fid='$id'";
	$sorgu=mysql_query($sql) or die(mysql_error());
	
	while($array=mysql_fetch_array($sorgu))
	{
	$i=0;
	?>



        <li>
            	 <a  href="<?php if(!empty($array['firmaresim'])) { ?>uploads/firmaresim/<?php echo $array['firmaresim'];  ?> <?php } else { echo "/firmalar";}?>">
                <img src="uploads/firmaresim/<?php echo $array['firmaresim'];  ?>" width="140" height="100" alt="" />
            </a>
        </li>
<?php 
$i++;
}
?>    
		
    </ul>
</span>