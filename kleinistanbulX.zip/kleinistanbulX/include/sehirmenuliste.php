<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">
<div id="uclu">

 <?php
$id=temizle($_GET['id']);
 
 $sql=mysql_query("SELECT  sehirmenu_detay.baslik, sehirmenu_detay.id, sehirmenu.menu FROM sehirmenu_detay inner join sehirmenu on sehirmenu.id=sehirmenu_detay.kat where sehirmenu_detay.onay=1 and sehirmenu_detay.kat='$id' order by sehirmenu_detay.tarih desc ");
 while($sorgu=mysql_fetch_assoc($sql))
 {?>


<div id="listekutu">
<p>
<a href="kahramanmaras/<?php echo seo($sorgu['menu']); ?>/<?php echo seo($sorgu['baslik']); ?>_<?php echo $sorgu['id']; ?>.html" title="<?php echo $sorgu['baslik']; ?>" />
<?php echo $sorgu['baslik']; ?>
</a>
</p>
</div>

<?php
}

?>
</div>			
</div>
