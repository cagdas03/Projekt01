﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<div id="sol_modul">
<div id="sol_modul_tepe" >NÖBETÇİ ECZANELER </div>
<div id="sol_modul_orta">
    
    <table border="0" >
  <tr>
    <td><?php 

//session_start();

//ob_start();
function DosyaAlneczaneff($url){
$oturum = curl_init();
curl_setopt($oturum, CURLOPT_URL, $url);
$h4 = $_SERVER['HTTP_USER_AGENT'];
curl_setopt($oturum, CURLOPT_USERAGENT, $h4);
curl_setopt($oturum, CURLOPT_HEADER, 0);
curl_setopt($oturum, CURLOPT_RETURNTRANSFER, true);
$source=curl_exec($oturum);
curl_close($oturum);
return $source;
}

function ecsillaaxx($q){
$ara   = array("","http://www.11818.com.tr/Service/Services.aspx?pageurl=Nobetci_eczaneler.aspx&CityId=","/Assets/image/ico_adres.png","/Assets/image/ico_tel.png","/assets/image/ico_info.png","Ã¼","ÅŸ","Ä±","ÄŸ","Ã‡","Â","Ä°","Åž","Ã¶","Ã§","<br />","Ä°","Äž","Ã–","Ãœ");
$degis = array("","nobetci-sayfa-","images/ico_adres.png","images/ico_tel.png","images/ico_info.png","ü","þ","ý","ð","Ç"," ","Ý","Þ","ö","ç","","Ý","Ð","Ö","Ü");
$q = str_replace($ara ,$degis ,$q);
return $q;
}


$tarih = date("Y-m-d");
$aa = date("d");
$site =  DosyaAlneczaneff("http://www.11818.com.tr/Nobetci_eczaneler.aspx?CityId=46&TownId=643"); 
$dizi = explode("<div class=\"clear\"></div>", $site); 
$dizi = explode("<div class=\"guncelpager\">", $dizi[1]);  
$dizi2 = explode("<tr><td bgcolor=\"#FFF4D2\" height=\"25\" width=\"60\">Tel :</td><td height=\"25\" bgcolor=\"#FDFEEB\">", $site); 
$dizi2 = explode("</td></tr>", $dizi2[1]);  
$dizi3 = explode("<tr><td colspan=\"2\" bgcolor=\"#FBCE9D\" align=\"center\" height=\"10\">", $site); 
$dizi3 = explode("</td></tr>", $dizi3[1]);  
preg_match("'<td bgcolor=\"#fdfeeb\" height=\"25\">(.*?)</td>'si",$site,$xxxxxxx);
$dizix = explode("<tr><td bgcolor=\"#FFF4D2\" height=\"25\" width=\"60\">Adres :</td><td height=\"25\" bgcolor=\"#FDFEEB\">", $site); 
$dizix = explode("</td></tr>", $dizix[2]);  
$dizi20 = explode("<tr><td bgcolor=\"#FFF4D2\" height=\"25\" width=\"60\">Tel :</td><td height=\"25\" bgcolor=\"#FDFEEB\">", $site); 
$dizi20 = explode("</td></tr>", $dizi20[2]); 
 
$dizi30 = explode("<tr><td colspan=\"2\" bgcolor=\"#FBCE9D\" align=\"center\" height=\"10\">", $site); 
$dizi30 = explode("</td></tr>", $dizi30[2]);

$eczane1[] = $dizi3[0];
$eczane1[] = $dizi[0];
$eczane1[] = $dizi2[0];

$eczane2[] = $dizi30[0];
$eczane2[] = $dizix[0];
$eczane2[] = $dizi2[0];
?>
<?=ecsillaaxx($dizi[0]);?></td>
  </tr>
</table>



</div>
<div id="sol_modul_alt" ></div>
</div>

	