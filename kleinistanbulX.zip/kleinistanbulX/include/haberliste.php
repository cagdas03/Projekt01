<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 



<div class="orta_modul">

 <?php
 $db_count=@mysql_num_rows(mysql_query("SELECT manset.id FROM manset inner join mansetkat on mansetkat.mid=manset.kat where manset.onay=1 "));
 
 $sql=mysql_query("SELECT mansetkat.mid, mansetkat.mkatadi FROM mansetkat inner join manset on mansetkat.mid=manset.kat where manset.onay=1 group by mansetkat.mid order by manset.bastarih desc ") or die(mysql_error());
 while($sorgu=mysql_fetch_assoc($sql))
 {?>

<div class="mansetMenuSistemi" style="float: left;">
        <div class="manset_liste_baslik"><?php echo $sorgu['mkatadi']; ?>
        <A class="tumlistehaber" title="Tüm <?php echo $sorgu['mkatadi']; ?> kategorisi haberleri " href="haberler/<?php echo seo($sorgu['mkatadi']); ?>_kategorisi_haberleri<?php echo intval($sorgu['mid']); ?>.html">Tümü</A>
        </div>
            <ul>
                <li>
                    <div class="resimlerGosterilecek"> &nbsp;</div>
                </li>
                
     <?php
	 
	 $icsql=mysql_query("SELECT manset.id, manset.manset_baslik, manset.manset_etiket, manset.mansetresim, manset.manset_detay,mansetkat.mkatadi FROM manset inner join mansetkat on mansetkat.mid=manset.kat where manset.onay=1 and manset.kat=".$sorgu['mid']." order by manset.bastarih desc ");
	 $sirano=1;
	 while($icsorgu=mysql_fetch_assoc($icsql))
	 { 
	 if($sirano==1)
	 { $sinif="aktifResim";}
	 else 
	 { $sinif=""; }
	  ?>           
                <li>
                    <a  href="manset/<?php echo seo($icsorgu['manset_baslik']); ?>_<?php echo $icsorgu['id']; ?>.html" title="<?php echo $icsorgu['manset_etiket']; ?>"  ><?php echo mb_substr($icsorgu['manset_baslik'],0,32); ?>..
                    <img src="uploads/manset/<?php echo $icsorgu['mansetresim']; ?>" width="230" class="<?php echo $sinif; ?>" alt="<?php echo $icsorgu['manset_baslik']; ?>"/>
                    </a>
                </li>
     
     <?php $sirano++; } ?>       
                
            </ul>
        </div>
        
       




<?php
}

?>


</div>			

