<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<script type="text/javascript" src="../js/nicEdit.js"></script>
<script type="text/javascript">
   bkLib.onDomLoaded(function() {
       
        new nicEditor({fullPanel : true}).panelInstance('noise');
        new nicEditor({maxHeight : 300}).panelInstance('area5');
		
  });</script>
<?php 
if($_SESSION['giris']==1 & $_SESSION['sid']>0)
{ 
$sid=$_SESSION['sid'];
$altincek=mysql_fetch_row(mysql_query("SELECT uyeliktur FROM firma where id='$sid' and onay=1 "));
$sorgu=mysql_query("SELECT ilan.id, ilan.ilan_baslik, ilan.onay, ilan.ilan_bas_tarih, ilantip.itip_adi, firma.uyeliktur from ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilantip.id=ilan.tip  where firma.id='$sid' and firma.onay=1 order by ilan.ilan_bas_tarih desc limit 0,".($iu_limit+1)."") or die(mysql_error());
$normal=mysql_fetch_assoc($sorgu);
$sayilan=mysql_num_rows($sorgu);
?>

<div class="orta_modul">
<div id="uclu">

<?php

if($altincek['0']==3) { ?>
<div id="detay-fadi">
<div id="buton1" style="cursor:pointer">Yeni Kampanya Ekle</div>
</div>


<?php if(temizle($_GET['is'])=="add" and $_POST['is']=="add" ) { ?>
<div id="ilanekle">
<?PHP 
$baslik=temizle($_POST['baslik']);
$detay=addslashes($_POST['detay']);
$etiket=area($_POST['etiket']);
$gkod=temizle($_POST['gkod']);
$tip=area($_POST['tip']);

if($sayilan>($iu_limit-1)) { 
echo "<script>alert('En fazla $iu_limit adet ilan ekleyebilirsiniz.');</script>";

echo "<meta http-equiv='refresh' content='0;URL=panel_ilanlar_openlist.html'> "; }

else
{
	
 include("securimage/securimage.php");
  $img = new Securimage();
  $valid = $img->check($_POST['gkod']);
  if($valid == true) 
    {

  $time=time();
  // mysql firma ekliyoruz  
   $ekle=mysql_query("INSERT INTO ilan  
        (id, ilan_baslik   ,ilan_detay   ,ilan_etiket,  ilan_bas_tarih, fid,onay, tip) 										
 VALUES
        ('','$baslik','$detay','$etiket','$time','$sid' , '0' ,'$tip' ) ")
        or die(mysql_error());  
		  echo "<meta http-equiv='refresh' content='0;URL=panel_ilanlar_openlist.html'> "; 
	
	
	}
	else
	{
echo "<div class='hata'> Güvenlik Kodunu Yanlış Girdiniz. <a href='panel_ilanlar_openadd.html'> Geri Git </a></div>";
   }

}
?>

</div>
<?php }




else if (temizle($_GET['is'])=='sil' and temizle($_GET['id'])>0   )
{
$id=temizle($_GET['id']);


$sil=mysql_query("DELETE from ilan where id='$id' and fid='$sid'");

echo "<meta http-equiv='refresh' content='0;URL=panel_ilanlar_openlist.html'>";
	
}

else if (  temizle($_GET['is'])=="edit" and intval($_GET['id'])>0 ) 
{
$id=temizle(intval($_GET['id']));


if(temizle($_POST['is']=="aktif"))

{
//D�zenleme baslasin
$baslik=temizle($_POST['baslik']);
$detay=addslashes($_POST['detay']);
$etiket=area($_POST['etiket']);
$tip=area($_POST['tip']);



  // mysql firma ekliyoruz  
   $ekle=mysql_query("UPDATE ilan SET ilan_baslik='$baslik'   ,ilan_detay='$detay' , ilan_etiket='$etiket', tip='$tip' where id='$id' and fid='$sid' ") or die(mysql_error());  
		  echo "<meta http-equiv='refresh' content='0;URL=panel_ilanlar_openlist.html'> "; 
	
   

//D�zenleme Bitsin
}
else
{
	
$sorgu=mysql_query("SELECT ilan.ilan_baslik, ilan.ilan_detay, ilan.ilan_etiket, ilan.onay, ilan.ilan_bas_tarih, ilan.hit, ilan.tip, ilantip.itip_adi from ilan inner join ilantip on ilantip.id=ilan.tip where ilan.id='$id' and ilan.fid='$sid' limit 0,1") or die(mysql_error());
while ($iland=mysql_fetch_assoc($sorgu))
{
?>
	
<div id="ilanekle" class="ilanekle"  >
<form action="ilan_duzenle_<?php echo $id; ?>.html" method="post" enctype="multipart/form-data" class="cmxform" id="ilanForm" onsubmit="return validate(this);">
  <fieldset>
		
        <p>
			<label for="tip">Kampanya Tipi:</label>
			<select name="tip" >
            <option value="">Kampanya Tipi Seç</option>
            <?php 
			$sorguTip=mysql_query("SELECT id, itip_adi FROM ilantip order by itip_adi asc");
			while ($cek=mysql_fetch_assoc($sorguTip))
			{
				?>
			<option value="<?php echo $cek['id'] ?>" <?php if($cek['id']==$iland['tip']) { echo "selected='selected'"; } ?>  ><?php  echo $cek['itip_adi']; ?></option>
			
            <?php 
			  }
			 ?>
            </select>
            (Max: 200 karakter)
		*</p>
        
        
		<p>
			<label for="baslik">Kampanya Başlık:</label>
			<input name="baslik" id="baslik" value="<?php echo $iland['ilan_baslik']; ?>" maxlength="200" /><br />
            (Max: 200 karakter)
		*</p>
		
		<p>
			<label for="detay">Kampanya Detayı:</label>
			<textarea id="noise" name="detay" ><?php echo stripslashes($iland['ilan_detay']); ?></textarea>
          
		</p>
        <p>
			<label for="etiket">Etiket:</label>
			<textarea id="etiket" name="etiket" maxlength="200"  ><?php echo $iland['ilan_etiket']; ?></textarea><br />
            Etiket aralarına virgül koyunuz. (Max: 200 karakter)
		</p>
   	
       
        
           		  <p>
                   <input type="hidden" name="is" value="aktif" />
                <input class="submit" type="submit" value="Düzenle"/>
		</p>
	</fieldset>
</form>
</div>

<?php
}
//Ilan d�zen bitisi
}

}


?>

<div id="ilanekle" class="ilanekle" <?php if( temizle($_GET['is'])=="openadd" ) { } else { echo "style='display:none'" ;} ?> >
<form action="panel_ilanlar_add.html" method="post" enctype="multipart/form-data" class="cmxform" id="ilanForm" onsubmit="return validate(this);">
  <fieldset>
		
                <p>
			<label for="baslik">Kampanya Tipi:</label>
			<select name="tip" >
            <option value="">Kampanya Tipi Seç</option>
            <?php 
			$sorgu2=mysql_query("SELECT id, itip_adi FROM ilantip order by id asc");
			while ($cek=mysql_fetch_assoc($sorgu2))
			{
			echo "<option value=".$cek['id'].">".$cek['itip_adi']."</option>";
			}
			 ?>
            </select>
            (Max: 200 karakter)
		*</p>
        
        
        
		<p>
			<label for="baslik">Kampanya Başlık:</label>
			<input name="baslik" id="baslik" maxlength="200" /><br />
            (Max: 200 karakter)
		*</p>
        
        
		
		<p>
			<label for="detay">Kampanya Detayı:</label>
			<textarea id="noise" name="detay" ></textarea>
            <script type="text/javascript" src="js/ckayar.js"></script>
		</p>
        <p>
			<label for="etiket">Etiket:</label>
			<textarea id="etiket" name="etiket" maxlength="200"  ></textarea><br />
            Etiket aralarına virgül koyunuz. (Max: 200 karakter)
		</p>
        		
          <p><label></label><img src="securimage/securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>"></p>
        <p><label for="gkod">Güvenlik Kodu:</label><input type="text" name="gkod" id="gkod" maxlength="5" size="30"></p>
        
           		  <p>
                  <input type="hidden" name="is" value="add" />
			<input class="submit" type="submit" value="Ekle!"/>
		</p>
	</fieldset>
</form>
</div>

<script>
$("#buton1").click(function () {
$("#ilanekle").toggle();
}); 
</script>



<div id="detay-fadi">
<div id="buton2" style="cursor:pointer"> <a href="panel_ilanlar_openlist.html"> Kampanyalarım (<?php echo $sayilan; ?>) </a></div>
</div>

<script>   
$("#buton2").click(function () {
$("#fdtek").toggle();
});    
</script>

<div id="fdtek"  <?php if( temizle($_GET['is'])=="openlist" ) { } else { echo "style='display:none'" ;} ?> >

<table class="tablox">
<tbody>
<tr>
<th>İlan Başlığı</th>
<th width="16%">İlan Tipi</th>
<th width="12%">Tarih</th>
<th width="25%">İşlemler</th>
</tr>

<?php
$sorguilan=mysql_query("SELECT ilan.id, ilan.ilan_baslik, ilan.onay, ilan.ilan_bas_tarih, ilantip.itip_adi, firma.uyeliktur from ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilantip.id=ilan.tip  where firma.id='$sid' and firma.onay=1 order by ilan.ilan_bas_tarih desc limit 0,$iu_limit") or die(mysql_error());

while ($ilan=mysql_fetch_assoc($sorguilan)) { ?>


<tr>
<td> <?php echo $ilan['ilan_baslik']; ?></td>
<td><?php echo $ilan['itip_adi']; ?></td>
<td><?php echo tt_tarih($ilan['ilan_bas_tarih']); ?></td>
<td>
<a title="Bu kampanyayı düzenle" href="ilan_duzenle_<?php echo $ilan['id']; ?>.html">Düzenle</a>
<?php if ($ilan['onay']==1) { } else { echo "Onay Bekliyor.."; } ?>
<a  title="İlani Sil" href="ilan_sil_<?php echo $ilan['id']; ?>.html" class="ask"><img src="images/delete.png" /></a></td>

</tr>









<?php }?>

</tbody>
</table>

</div>

<?php } else
{
echo "<div class='hata'>İlan ekleyebilmek için ALTIN ÜYE olmalısınız. Bilgi Almak için <a href='iletisim.html'>tıklayınız.</a></div>";	
}
?>
</div>
</div>




           <?php } else { 
			  echo "<meta http-equiv='refresh' content='0;URL=index.html'> "; 
			}?>				
            