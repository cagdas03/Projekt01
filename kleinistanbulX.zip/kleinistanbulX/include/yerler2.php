
<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8" />
<meta name="author" content="Wolfgang Pichler" />
<link rel="canonical" href="http://www.wolfpil.de" />

<title>Marker and Sidebar Toggling (v3)</title>

<style type="text/css">

body { height: 600px; font-family: Verdana; }
.normal { background-color:#FFF; }
.focus { background-color:#FFC; }

.sprite { display:inline-block;
 height: 32px;
 width: 32px;
 background: url('http://sites.google.com/site/mxamples/icons-dot.png') no-repeat;
}

</style>

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyB1Wwh21ce7jnB6yDbjVGN3LC5ns7OoOL4&amp;sensor=false">
</script>

<script type="text/javascript">
//<![CDATA[

 var map, actual, iw;
 var gmarkers = [];

 var icons = { img: "http://sites.google.com/site/mxamples/icons-dot.png",
  bar: [0, 0], // red
  cafe: [128, 32], // brown
  hotel: [32, 32], // salmon
  disco: [96, 0], // ltblue
  white: [192, 0] // white
 };


// Shifts background position of the sprite image
function shifter(arr) {

 var g = google.maps;
 var image = new g.MarkerImage(icons.img,
  new g.Size(32, 32),
  new g.Point(arr[0], arr[1]),
  new g.Point(15, 32));
 return image;
}


function createMarker(point, name, addr, category, id) {

  var g = google.maps;
  var image = shifter(icons[category]);
  var shadow = new g.MarkerImage(icons.img,
    new g.Size(59, 32),
    new g.Point(192, 32),
    new g.Point(15, 32));

  var marker = new g.Marker({ position: point, map: map,
    title: name, clickable: true, draggable: false,
    icon: image, shadow: shadow
  });

  // Store category, name, and id as marker properties
  marker.category = category;
  marker.name = name;
  marker.id = id;
  gmarkers.push(marker);

  var html = "<b>"+name+"<\/b><p style='font-size:smaller'>" + addr + "<\/p>";

  g.event.addListener(marker, "click", function() {
   iw.setContent(html);
   iw.open(map, this);
  });

  // Hovering over the markers
  g.event.addListener(marker, "mouseover", function() {
   marker.setIcon(shifter(icons.white));
   var hovered = document.getElementById(id);
   if (hovered) {
    hovered.className = "focus";
    actual = hovered; // Store this element
   }
  });

  g.event.addListener(marker, "mouseout", function() {
   marker.setIcon(shifter(icons[category]));
   if (actual) { actual.className= "normal"; }
  });
}


var hover = { // Hovering over the links
 over: function(i) {
  var marker = gmarkers[i];
  // Set another background color for the link
  var hovered = document.getElementById(marker.id);
  hovered.className = "focus";

  // Set another marker icon
  marker.setIcon(shifter(icons.white));
 },

 out: function(i) {
  var marker = gmarkers[i];
  // Set the default link background
  var hovered = document.getElementById(marker.id);
  hovered.className = "normal";

  // Set the default marker icon
  marker.setIcon(shifter(icons[marker.category]));
 }
};

var visible= { // Make a category (un)visible
 show: function(category) {
  // Show all markers of one category
  for(var i= 0, m; m = gmarkers[i]; i++) {
   if (m.category == category) {
    m.setVisible(true);
   }
  }
   // Set the checkbox to true
   document.getElementById(category).checked = true;
 },

 hide: function(category) {
  // Hide all markers of one category
  for(var i= 0, m; m = gmarkers[i]; i++) {
   if (m.category == category) {
    m.setVisible(false);
   }
  }
  // Clear the checkbox of a hidden category
  document.getElementById(category).checked = false;
  iw.close();
 }
};

 function boxclick(box, category) {

  // Hide or show the category of the clicked checkbox
  if (box.checked) { visible.show(category); }
  else { visible.hide(category); }

  // Rebuild the sidebar
  makeSidebar();
 }

 // Trigger the clicks from the sidebar to open the appropriate infowindow
 function triggerClick(i) {
  google.maps.event.trigger(gmarkers[i],"click");
 }


 // Rebuild the sidebar to match currently displayed markers
 function makeSidebar() {

  var oldheader;
  var html = "";
  for (var i= 0, m; m = gmarkers[i]; i++) {
   if (m.getVisible()) {

   var header = gmarkers[i].category;
   header = header.replace(/^./, header.charAt(0).toUpperCase());
    if (oldheader != header) html += "<b>"+ header+"s<\/b><br \/>";
    html += '<a id="'+ gmarkers[i].id+'" href="javascript:triggerClick('+i+')" onmouseover="hover.over('+i+')" onmouseout="hover.out('+i+')">' + gmarkers[i].name + '<\/a><br \/>';
    oldheader = header;
   }
  }
  document.getElementById("sidebar").innerHTML = html;
 }


 function loadMap() {  // Create the map

  var g = google.maps;
  var opts_map = {
    center: new g.LatLng(48.14086, 11.568775),
    zoom: 14,
    mapTypeId: g.MapTypeId.ROADMAP,
    mapTypeControlOptions: {
     mapTypeIds: [ g.MapTypeId.ROADMAP, g.MapTypeId.SATELLITE, g.MapTypeId.HYBRID]
    },
    panControl: true,
    zoomControl: true,
    zoomControlOptions: {
     style: g.ZoomControlStyle.LARGE
    }
  };

  map = new g.Map(document.getElementById("map"), opts_map);
  iw = new g.InfoWindow();

  // v2 behaviour
  g.event.addListener(map, "click", function() {
   if (iw) iw.close();
  });
  readData();
 }


function readData() { // Create Ajax request for XML

 var request;
 try {
   if (typeof ActiveXObject != "undefined") {
     request = new ActiveXObject("Microsoft.XMLHTTP");
   } else if (window["XMLHttpRequest"]) {
     request = new XMLHttpRequest();
   }
 } catch (e) {}

  request.open("GET", "../markers-muenchen.xml", true);
  request.onreadystatechange = function() {
  if (request.readyState == 4) {

   var xml = request.responseXML;
   var markers = xml.documentElement.getElementsByTagName("marker");
   for(var i = 0, m; m = markers[i]; i++) {
    // Obtain the attribues of each marker
    var lat = parseFloat(m.getAttribute("lat"));
    var lng = parseFloat(m.getAttribute("lng"));
    var point = new google.maps.LatLng(lat,lng);
    var address = m.getAttribute("address");
    var id = m.getAttribute("nr");
    var name = m.getAttribute("name");
    var category = m.getAttribute("category");
    // Create the markers
    createMarker(point, name, address, category, id);
   }

  if(gmarkers) {

   // Sort categories and names to display
   // both in alphabetic order
   gmarkers.sort(compareCats);
  }
   // Show or hide a category initially
   visible.show("bar");
   visible.show("cafe");
   visible.hide("hotel");
   visible.hide("disco");
   makeSidebar();
  }
 }; request.send(null);
}


var compareCats = function(a, b) {

 var n1 = a.name;
 // Treat German umlauts like non-umlauts
 n1 = n1.toLowerCase();
 n1 = n1.replace(/ä/g,"a");
 n1 = n1.replace(/ö/g,"o");
 n1 = n1.replace(/ü/g,"u");
 n1 = n1.replace(/ß/g,"s");

 var n2 = b.name;

 n2 = n2.toLowerCase();
 n2 = n2.replace(/ä/g,"a");
 n2 = n2.replace(/ö/g,"o");
 n2 = n2.replace(/ü/g,"u");
 n2 = n2.replace(/ß/g,"s");

 var c1 = a.category;
 var c2 = b.category;

 // Sort categories and names
 if(a.category == b.category){
  if(a.name == b.name){
   return 0;
  }
   return (a.name < b.name) ? -1 : 1;
 }

 return (a.category < b.category) ? -1 : 1;
}

window.onload = loadMap;

//]]>
</script>

</head>

<body>
  
<h2>Marker and Sidebar Toggling (v3)</h2>

<table border="0" style="position:absolute; top:19px; left:576px; white-space:nowrap;"><tr><td>
<span class="sprite" style="background-position:0 0;"></span><input type="checkbox" id="bar" onclick="boxclick(this,'bar')" /> Bars
&nbsp;
<span class="sprite" style="background-position:-128px -32px;"></span><input type="checkbox" id="cafe" onclick="boxclick(this,'cafe')" /> Cafes
</td></tr>

<tr><td>

<span class="sprite" style="background-position:-96px 0;"></span><input type="checkbox" id="disco" onclick="boxclick(this,'disco')" /> Discos
&nbsp;

<span class="sprite" style="background-position:-32px -32px;"></span><input type="checkbox" id="hotel" onclick="boxclick(this,'hotel')" /> Hotels

</td></tr></table>

<div id="map" style="position:absolute; top:60px; left:10px; width:550px; height:400px"></div>

<div id="sidebar" style="position:absolute; top:120px; left: 590px; width:280px; height:340px; font-size:smaller; overflow:auto;"><b>Cafes</b><br><a id="m9" href="javascript:triggerClick(3)" onmouseover="hover.over(3)" onmouseout="hover.out(3)" class="normal">Blues Cafe</a><br><a id="m13" href="javascript:triggerClick(4)" onmouseover="hover.over(4)" onmouseout="hover.out(4)" class="normal">Cafe Lotterleben</a><br><a id="m10" href="javascript:triggerClick(5)" onmouseover="hover.over(5)" onmouseout="hover.out(5)" class="normal">Cafe Mozart</a><br><a id="m8" href="javascript:triggerClick(6)" onmouseover="hover.over(6)" onmouseout="hover.out(6)" class="normal">Cafe Restaurant im Parkhaus</a><br><a id="m7" href="javascript:triggerClick(7)" onmouseover="hover.over(7)" onmouseout="hover.out(7)" class="normal">Cafe Schiller</a><br></div>


</body>
</html>
