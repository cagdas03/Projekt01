<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
<head>
<meta name="robots" content="index, follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico">  
        
   </head>
   <body>
   
   <?php
   include("../include/ayar.inc.php");
   include("../include/fonksiyon-ek.php");
   $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT * FROM firma where id='$id' and onay='1' limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
	
	$sorgu=mysql_query("SELECT firma.adi,  firma.logo, firma.uyeliktur, firma.yetkili,firma.tel, firma.fax, firma.web, firma.koordinat, firma.zoom, firma.face, firma.detay, firma.etiket, firma.email, firma.adres, firma.hit, sehir.ad, ilce.ilce_adi, uyeliktur.tip_adi  from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join uyeliktur on uyeliktur.id=firma.uyeliktur where firma.onay=1 and firma.id='$id' limit 0,1") or die(mysql_error() );
	while ( $firma=mysql_fetch_assoc($sorgu) ) {
 //Hit ekleyelim
 ?>
      

	<script language="JavaScript">
	
	
function check_popmail(){
	
	if (document.mailform.ad.value == ""){
		alert ("Ad yazınız");
		document.mailform.ad.focus();
		return false;  
	}
	
		   if (document.mailform.email.value == ""){
		alert ("Sizin Email adresinizi yazınız");
		document.mailform.email.focus();
		return false;
	}
		   if (document.mailform.detay.value == ""){
		alert ("Detay yazınız");
		document.mailform.detay.focus();
		return false;
	}
	

if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mailform.email.value)){
return (true)
}
alert("Hatalı Email adresi yazdınız.");
return (false)

	
		

 }



</script>

 <style>
/* D��ar�dan a��l�d�� i�in bilerek style i�ine al�nmad�  */
 .maildetay{background:#FAF8ED; font-size:12px; font-family:Tahoma; } 
 #stylized{ background-color:#EBF8A4; border:1px solid #FECD6D; padding:5px;}
.valid_box{clear:both;background:url(../images/valid.png) no-repeat left #edfce9;
border:1px #cceac4 solid;background-position:15px 10px;padding:20px 20px 15px 60px;margin:0 0 10px 0;}
#stylized p{font-size:10px;color:#666666;margin-bottom:2px;}
#stylized label{display:block;font-weight:bold;text-align:right;width:60px;font-size:11px;float:left;}
#stylized .small{color:#666666;display:block;font-size:10px;font-weight:normal;text-align:right;width:100px;}
#stylized input{float:left;font-size:10px;padding:4px 2px;border:solid 1px #C4B06D;width:140px;margin:2px 0 5px 10px;}
#stylized textarea{float:left;font-size:10px;padding:4px 2px;border:solid 1px #C4B06D;width:360px;height:60px;margin:2px 0 20px 10px;}
</style>



<div  class="maildetay">
<?php  
if( empty ($_POST['gondermail'] ) ) 
{
?>

<div id="stylized">
<form id="form" name="mailform" method="post" action="" onSubmit="return check_popmail()" >
<table>
<tr><td><label>Ad Soyad</label><input type="text" name="ad" id="ad" /></td><td><label>Emailiniz</label><input type="text" name="email" id="email" /></td></tr>

<tr><td colspan="2"><label>Detay</label><textarea name="detay" id="detay"/></textarea></td></tr>
<tr><td colspan="2"><label></label><input type="submit" name="gondermail" style="float:right" value="Gönder"> </td></tr>
</table>

</form>
</div>

<?php } else {
// firmaya mail g�nderiliyor
$femail=$firma['email'];
$fheader= "Content-type: text/html; charset='UTF-8'\r\n";  
$fheader.= "From: ".mysql_real_escape_string($_POST['email'])."\r\n"; 
$fsubject =$site_adi." Sitesinden Yeni Bir Mesaj Aldınız.";  
$fmessage_contents = "
<p><b>Maili Gönderenin Adı: </b>".mysql_real_escape_string($_POST['ad'])."</p>
<p style='color:#ff0000'><b>Mail Detayı: </b>".mysql_real_escape_string($_POST['detay'])."</p>
<p><b>Firmaya Git: </b><a href='".$rowtt['site_url']."/firmalar/".seo($firma['adi'])."_".$fid.".html' target='_blank' > Firmaya Git </a></p>
";

mail($femail,$fsubject,$fmessage_contents,$fheader);  

// admine bilgi maili g�nderiliyor.

$header= "Content-type: text/html; charset='UTF-8'\r\n";  
$header.= "From: ".$_POST['email']."\r\n"; 
$subject = $site_adi." | Firmaya mail gonderildi.";  
$message_contents = "
<p><b>Maili Gönderenin Adı: </b>".mysql_real_escape_string($_POST['ad'])."</p>
<p><b>Maili Gönderenin E-maili: </b>".mysql_real_escape_string($_POST['email'])."</p>
<p style='color:#ff0000'><b>Mail Detayı: </b>".mysql_real_escape_string($_POST['detay'])."</p>
<p><b>Mail Gonderilen Firma: </b>".$firma['adi']."</p>
<p><b>Firmanin Mail Adresi: </b>".$firma['email']."</p>
<p><b>Firmaya Git: </b><a href='".$rowtt['site_url']."/firmalar/".seo($firma['adi'])."_".$fid.".html' target='_blank' > Firmaya Git </a></p>
";

mail($mailayar,$subject,$message_contents,$header);  
?>  
 </div>
<div class="valid_box">Tebrikler mailiniz gönderildi</div>
<?php }?>

<?php } }?>

</body>
</html>
