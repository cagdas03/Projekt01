     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
 <?php include("include/nedengold.php"); ?>

<form action="ara.php" method="get">
 <h2>HIZLI ARAMA</h2>

<script src="../js/jquery.chained.mini.js" type="text/javascript" charset="utf-8"></script>

		  
		  <script type="text/javascript" charset="utf-8">
          $(function(){
              $("#ilce").chained("#sehir"); 
          });
          </script>
<table style="background:#eee; width:200px; font-weight:bold; border:1PX dotted #C1DAD7;padding:5px;" >

<tr><td>Arama T�r�:</td></tr>

<tr><td><select name="tur" id="tur">  
  <option <?php if($_GET["tur"]=="firma") echo "selected='selected'"; ?> value="firma">Firmalar</option>  
   <option <?php if($_GET["tur"]=="ilan") echo "selected='selected'"; ?> value="ilan">&#304;lanlar</option>  
      <option <?php if($_GET["tur"]=="urun") echo "selected='selected'"; ?> value="urun">�r�nler</option>  

</select></td></tr>




<tr><td>Sekt�r Se�iniz:</td></tr>

<tr><td><select name="ustkat" id="ustkat"  <?php if($_GET["ustkat"]!='') echo "style='background:#FEB75A;font-weight:bold;width:130px'"; ?>>  
  <option value="">Hepsi</option>  

<?php  
$sql="SELECT ust_id,ust_adi from ustkat order by ust_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option <?php if($_GET["ustkat"]==$array['ust_id']) echo "selected='selected'"; ?> value="<?php echo $array['ust_id'] ;?>"> <?php echo $array['ust_adi']; ?> </option>  

<?  
}  
?>  

</select></td></tr>


<tr>
  <td>&#350;ehir:</td>
</tr>

<tr><td><select name="sehir" id="sehir"  <?php if($_GET["sehir"]!='') echo "style='background:#FEB75A;font-weight:bold;width:130px'"; ?>>  
  <option value="">Hepsi</option>  

<?php  
$sql="SELECT plaka,ad from sehir order by plaka asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option <?php if($_GET["sehir"]==$array['ad']) echo "selected='selected'"; ?> value="<?php echo $array['ad'] ;?>"> <?php echo $array['ad']; ?> </option>  

<?  
}  
?>  

</select></td></tr>

<tr>
  <td>&#304;l�e:</td>
</tr>


<tr><td> 
  <select name="ilce" id="ilce" <?php if($_GET["ilce"]!='') echo "style='background:#FEB75A;font-weight:bold;width:130px'"; ?>>  
  <option value="" class="">Hepsi</option> 

<?php  
$sql="SELECT ilce.ilce_adi,sehir.ad from ilce inner join  sehir on sehir.plaka=ilce.sehir order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option <?php if($_GET["ilce"]==$array['ilce_adi']) echo "selected='selected' "; ?> value="<?php echo $array['ilce_adi'] ;?>" class="<?php echo $array['ad'];?>"> <?php echo $array['ilce_adi']; ?> </option>  

<?  
}  
?>  

</select>
</td>
</tr>






<tr>
<td>
Anahtar Kelime :
</td>
</tr>

<tr>
<td>
<input type="text" name="kelime" value="<?php echo $_GET['kelime'];?>" />
</td>
</tr>



<tr> <td> <p align="center"><input style="background:#287EBB; color:#FFFFFF; font-weight:bold; text-align:center; height:25px;width:100px;" type="submit"  value="Arama Yap"/> </p> </td></tr> 

 
</table>

</form>


<h2>EN �OK TIKLANANLAR</h2>

<ul class="tabs">
    <li><a href="#tab1">Firmalar</a></li>
    <li><a href="#tab2">�r�nler</a></li>
    <li><a href="#tab3">&#304;lanlar</a></li>
</ul>

<div class="tab_container">
    <div id="tab1" class="tab_content">
    <ul>
    <? 
	$sql=mysql_query("SELECT adi,uyeid,hit from firma order by hit desc limit 0, 5");
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['0']);
	echo "<li><a href='$sefle-firmadetay".$tabcek['1'].".html' >".$tabcek['0']." (".$tabcek['2'].")</a></li>";}
	?>
    </ul>
    </div>
    <div id="tab2" class="tab_content">
        <ul>
    <? 
	$sql=mysql_query("SELECT urun_baslik,id,hit from urun order by hit desc limit 0, 5");
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['0']);
	echo "<li><a href='$sefle-urundetay".$tabcek['1'].".html' >".$tabcek['0']." (".$tabcek['2'].")</a></li>";}
	?>
    </ul>
    </div>
        <div id="tab3" class="tab_content">
       <ul>
    <? 
	$sql=mysql_query("SELECT ilan_baslik,id,hit from ilan order by hit desc limit 0, 5");
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['0']);
	echo "<li><a href='$sefle-ilandetay".$tabcek['1'].".html' >".$tabcek['0']." (".$tabcek['2'].")</a></li>";}
	?>
    </ul>
    </div>
</div>


<style>
input,select{
color: #666666;
width:100px;
background:#FCF8AD;
border:1px solid #FEB75A;
width:160px;
}
</style>

<div style="margin-bottom:10px"></div>

 <?
 $sqlk=mysql_query("SELECT id,url, dosya from advert where tip='sol-ust' and onay='1' limit 0,1"); 
   while( $adv=mysql_fetch_assoc($sqlk))
{
					
include("rek-sol.php");

}
?>

