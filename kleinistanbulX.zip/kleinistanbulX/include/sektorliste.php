<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">

<div id="uclu">



 <?php
 require_once 'lib/sayfalama.class.php';
 $db_count=mysql_num_rows(mysql_query("SELECT ust_id FROM  ustkat "));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
  $pages->default_ipp = 100;
 $pages->paginate();
 
 $sql=mysql_query("SELECT ust_id,ust_adi,etiket FROM  ustkat order by ust_adi asc $pages->limit");
 while($sorgu=mysql_fetch_assoc($sql))
 {
	
$saysql=mysql_query("SELECT id from firma inner join sektor on sektor.s_fid=firma.id  inner join ustkat on ustkat.ust_id=sektor.s_ustid where firma.onay=1 and ustkat.ust_id=$sorgu[ust_id]"); 
$say=mysql_num_rows($saysql);
?>


<div id="sektorkutu">
<p><a href="sektorler/<?php echo seo($sorgu['ust_adi']); ?>_<?php echo $sorgu['ust_id']; ?>.html" title="<?php echo $sorgu['etiket']; ?>" /><?php echo $sorgu['ust_adi']; ?></a><span> <b>(<?php echo $say;?>)</b></span>
</p>
</div>

<?php
}

?>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>