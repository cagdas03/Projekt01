     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<?php $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT * FROM ilan inner join firma on firma.id=ilan.fid where ilan.id='$id' and ilan.onay='1' and firma.onay=1 and firma.uyeliktur=3 limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
	
 $sql="SELECT firma.id, firma.adi,  firma.logo, firma.uyeliktur, firma.yetkili,firma.tel, firma.fax, firma.web, firma.koordinat, firma.zoom, firma.face, firma.detay, firma.etiket, firma.email, firma.adres, ilan.hit, sehir.ad, ilce.ilce_adi, uyeliktur.tip_adi, ilan.ilan_baslik, ilan.ilan_detay,  ilan.ilan_bas_tarih ,ilantip.itip_adi from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join uyeliktur on uyeliktur.id=firma.uyeliktur inner join ilan on ilan.fid=firma.id  inner join ilantip on ilantip.id=ilan.tip where firma.onay=1 and ilan.onay=1 and ilan.id='$id' and firma.uyeliktur=3 limit 0,1";
	$sorgu=mysql_query("$sql") or die(mysql_error() );
	while ( $firma=mysql_fetch_assoc($sorgu) ) {
 //Hit ekleyelim
$yenihit=$firma['hit']+1;
$hitle=mysql_query("UPDATE ilan SET hit='$yenihit' where id='$id' ") or die(mysql_error());
 ?>
      
<a name="firmagit"></a>
<div class="orta_modul">

<?php // include("include/fdetay_tepe.php"); ?>

     
    

<div id="uclu">
<div  id="fdtek">
<?php include("include/facelike.php"); ?>
<div class="face w200"> Bu ilan <b style="font-size:14px; color:#F00; font-weight:bold"><?php echo $firma['hit'] ;?></b> kez ziyaret edildi.</div>

</div>
</div>



</div>




<a name="ilangit"></a>
<div class="orta_modul">
<div id="uclu">

<div id="detay-fadi">
<?php echo $firma['ilan_baslik']; ?>
<span class="fr">    <?php  if($firma['email']=="") { echo "";} else { ?>
   
<a class="red" href="include/pop-mail-gonder.php?id=<?php echo $firma['id']; ?>&iframe=true&width=450&height=230" rel="prettyPhoto[iframes]" title="<?php echo $firma['adi']; ?> mail gönder. ">Firmaya Mail Gönder |</a>
<?php } ?>  <a href="firmalar/<?php echo seo($firma['adi']); ?>_<?php echo $firma['id']; ?>.html">Firma Detayına Git</a></span>
</div>

    <script type="text/javascript">
    $(function() {
        $('#urunresim a').lightBox();
    });
    </script>
    

<div id="fdurun" style="padding:5px;">

<dl> <dt>İlan Adı</dt>  <dd>: <?php echo $firma['ilan_baslik']; ?></dd> </dl>

<dl> <dt>İlan Tipi</dt>  <dd>: <?php echo $firma['itip_adi']; ?></dd> </dl>
   
<dl>  <dt>Açıklama:</dt>    <dd><?php echo stripslashes($firma['ilan_detay']); ?> </dd>  </dl>

<p>Bu ilan <b style="color:#F00"> <?php echo $firma['hit']; ?></b> kez ziyaret edildi.</p>
</div>
</div>
</div>









<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firmanin Diğer İlanları
</div>
<div id="fdtek">


<table class="tablox">
<tbody>
<tr>
<th>İlan Başlığı</th>
<th width="16%">İlan Tipi</th>
<th width="12%">Tarih</th>
</tr>

<?php
$sql="SELECT ilan.id, ilan.ilan_baslik,  ilan.ilan_etiket, ilan.ilan_bas_tarih, ilantip.itip_adi  FROM ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilantip.id=ilan.tip where firma.onay=1 and ilan.onay=1 and firma.uyeliktur=3 and ilan.fid='".$firma['id']."' limit 0,10";
$sorgu=mysql_query($sql) or die(mysql_error());
while($ilan=mysql_fetch_assoc($sorgu))
{
	
$sef=seo($ilan['ilan_baslik']);	
// 133x84 resim
 ?>

<tr>
<td> <a title="<?php echo $ilan['ilan_baslik']; ?>" href="ilanlar/<?php echo seo($ilan['ilan_baslik']) ;?>_<?php echo $ilan['id']; ?>.html" ><?php echo $ilan['ilan_baslik']; ?></a></td>
<td><?php echo $ilan['itip_adi']; ?></td>
<td><?php echo tt_tarih($ilan['ilan_bas_tarih']); ?></td>

</tr>


<?php }?>

</tbody>
</table>

</div>
</div>
</div>

 
 
 <?php } // while bitis ?>
 
 
 <?php  } // ilan id bitis?>
 