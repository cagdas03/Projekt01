     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<?php $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT manset.id FROM manset where id='$id' and onay='1' limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
$sorgum=mysql_query("SELECT * FROM manset where id='$id' and onay=1 limit 0,1");
while($manset=mysql_fetch_assoc($sorgum)){?>


<div class="orta_modul">
<div id="uclu">

<div id="detay-habernew">
<?php echo $manset['manset_baslik']; ?>
<span  class="fr pr55 tarih"><?php echo tt_tarih($manset['bastarih']); ?></span>
</div>
   

<div style="width:430px; float:left">

<div class="haberresimnew"><a href="uploads/manset/<?php echo $manset['mansetresim']; ?>" ><img src="uploads/manset/<?php echo $manset['mansetresim']; ?>" width="427" height="225"  /></a>
</div>


<div class="haberdetaynew">
<p><b><?php echo $manset['manset_ozet']; ?></b></p>
<p><?php echo stripslashes($manset['manset_detay']); ?></p>
</div>
<div class="haberdetaynew">
<?php include("include/facelike.php"); ?>
</div>

</div>


<div class="sagozet">



 <?php
 $sql=mysql_query("SELECT mansetkat.mid, mansetkat.mkatadi FROM mansetkat inner join manset on mansetkat.mid=manset.kat where manset.onay=1 and manset.id=".$id." group by mansetkat.mid order by manset.bastarih desc limit 0,1 ") or die(mysql_error());
 while($sorgu=mysql_fetch_assoc($sql))
 {?>

<div class="mansetdMenuSistemi" style="float: left; overflow:auto">
        <div class="mansetd_liste_baslik"><?php echo $sorgu['mkatadi']; ?> Kategorisindeki Haberler
        <A class="tumlistehaber" title="Tüm <?php echo $sorgu['mkatadi']; ?> kategorisi haberleri " href="haberler/<?php echo seo($sorgu['mkatadi']); ?>_kategorisi_haberleri<?php echo intval($sorgu['mid']); ?>.html">Tümü</A>
        </div>
            <ul>
                <li>
                    <div class="resimlerGosterilecek"> &nbsp;</div>
                </li>
                
     <?php
	 
	 $icsql=mysql_query("SELECT manset.id, manset.manset_baslik, manset.manset_etiket, manset.mansetresim, manset.manset_detay,mansetkat.mkatadi FROM manset inner join mansetkat on mansetkat.mid=manset.kat where manset.onay=1 and manset.kat=".$sorgu['mid']." order by manset.bastarih limit 0, 20");
	 $sirano=1;
	 while($icsorgu=mysql_fetch_assoc($icsql))
	 { 
	 if($sirano==1)
	 { $sinif="aktifResim";}
	 else 
	 { $sinif=""; }
	  ?>           
                <li>
                    <a  href="manset/<?php echo seo($icsorgu['manset_baslik']); ?>_<?php echo $icsorgu['id']; ?>.html" title="<?php echo $icsorgu['manset_etiket']; ?>" ><?php echo $icsorgu['manset_baslik']; ?>
                    <img src="uploads/manset/<?php echo $icsorgu['mansetresim']; ?>" width="280" class="<?php echo $sinif; ?>" alt="<?php echo $icsorgu['manset_baslik']; ?>"/>
                    </a>
                </li>
     
     <?php $sirano++; } ?>       
                
            </ul>
      
       




<?php
}

?>


</div>
</div>



</div>
</div>

 
 <?php }}?>