<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div class="orta_modul">




<div id="uclu">


 
  <div id="map" style="width: 732px; height: 300px;"></div> 

  <script type="text/javascript"> 
 
    var locations = [ 
	
	
		<?php
$sql="SELECT firma.adi, firma.id, firma.koordinat, firma.logo, firma.adres, firma.tel, sehir.ad, ilce.ilce_adi,firma.uyeliktur from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce  where firma.uyeliktur>1 and firma.onay=1 and firma.zoom>0 and firma.koordinat>0 ";
$sorgu=mysql_query($sql) or die(mysql_error());
$max = mysql_num_rows($sorgu);

$i=0;
while($array=mysql_fetch_row($sorgu)) 
{ 



$seokat=seo($array['0']);
echo "['<div class=anamap><div class=sollogo><img src=images/paket".$array[8].".png width=136 height=20 ><br/><a href=firmalar/".$seokat."_".$array['1'].".html><img src=uploads/logo/".$array[3]." width=136 height=94 ><br/>Detayları Gör</a></div><div class=sagmap><a href=firmalar/".$seokat."_".$array['1'].".html>".$array[0]."</a><br/><br/>".str_replace(","," ",$array[4])."<br/>".$array[6]."/".$array[7]."<br/><br/>".$array[5]."</div></div>',".$array['2']." ,".$i."]";
$i++;
if($i!=$max) echo " , ";

}
?>
    
  
	  
    ]; 
	
	

    var map = new google.maps.Map(document.getElementById('map'), { 
      zoom: <?php echo $rowtt['tt_zoom'] ?>,	
	  scrollwheel: false,  
      center: new google.maps.LatLng(<?php echo $rowtt['tt_koordinat'] ?>, <?php echo $rowtt['tt_zoom'] ?>), 
      mapTypeId: google.maps.MapTypeId.ROADMAP 
    }); 

    var infowindow = new google.maps.InfoWindow(); 

    var marker, i; 

    for (i = 0; i < locations.length; i++) {   
      marker = new google.maps.Marker({ 
        position: new google.maps.LatLng(locations[i][1], locations[i][2]), 
		disableAutoPan: true,
        map: map 
      }); 

      google.maps.event.addListener(marker, 'click', (function(marker, i) { 
        return function() { 
          infowindow.setContent(locations[i][0]); 
          infowindow.open(map, marker); 
        } 
      })(marker, i)); 
    } 
  </script> 

</div>
</div>