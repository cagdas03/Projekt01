﻿     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
<div id="uclu">
<div id="detay-fadi">
<?php echo $firma['adi']; ?>
</div>

<div id="detay-sol">

<?php if($firma['uyeliktur']>1) { ?>
<div id="logodetay">
<?php if($firma['logo']==""){ echo "<img src='images/logoyok_detay.png'>";} else { ?>
<img src="uploads/logo/<?php echo $firma['logo']; ?>" width="280" height="195"> <?php }?>
<br>
<span style="float:left;  width:240px;padding:5px 5px 4px 5px;  font-weight:bold; font-size:13px"><?php echo $firma['tip_adi']; ?> Üye  </span> <span style="float:right;">

<img src="images/uye<?php echo $firma['uyeliktur']; ?>.png"></span>
</div>
<?php } else {

reklam_300(detay300);
 }?>

</div>

<div id="detay-sag">
<dl> 
   <dt>Firma Adı</dt>  <dd>: <?php echo $firma['adi']; ?></dd>
   <dt>Yetkili Adı</dt>    <dd>: <?php echo $firma['yetkili']; ?></dd> 
   <dt>Adres</dt>    <dd>: <?php echo $firma['adres']; ?> </dd> 
   <dt>Şehir/İlçe</dt>    <dd>: <?php echo $firma['ad']; ?> / <?php echo $firma['ilce_adi']; ?></dd>
   <dt>Telefon</dt>    <dd>: <?php echo $firma['tel']; ?></dd>
   <dt>Cep Tel</dt>    <dd>: <?php echo $firma['cep']; ?></dd>
   <dt>Faks</dt>    <dd>: <?php echo $firma['fax']; ?></dd>
   <dt>Sektörler</dt>    <dd>:
   <?php
//Kategoriyi ayri �ekelim.
if ($firma['uyeliktur']==1)
{ $seklimit=1;} 
else if($firma['uyeliktur']==2)
{ $seklimit=3; }
else { $seklimit=5;}

$sql="SELECT ustkat.ust_adi, ustkat.ust_id from sektor inner join ustkat on ustkat.ust_id=sektor.s_ustid  where sektor.s_fid='$id' limit 0,$seklimit";
$sorgu=mysql_query($sql) or die(mysql_error());
$max = mysql_num_rows($sorgu);

$i=0;
while($array=mysql_fetch_row($sorgu)) 
{ 
$seokat=seo($array['0']);
echo "<a href='sektorler/".$seokat."_".$array[1].".html' >".$array['0']."</a> ";
$i++;
if($i!=$max) echo " , ";

}
?>	
   </dd>
    
   
   
</dl>
</div>
</div>

<?php if($firma['uyeliktur']>1)  {?>

<div id="uclu">
<div id="detay-solalt">

<dl> 
   <dt>Email </dt>  <dd>: <?php echo $firma['email']; ?></dd>
   <dt>Web </dt>    <dd>: <?php if($firma['web']=="" ) {} else {?><a href="http://<?php echo $firma['web']; ?>" target="_blank"><?php echo $firma['web']; ?></a><?php }?></dd> 
   
 
 </dl>

</div>
<div id="detay-sagalt">
<dl> 
<dt>Facebook  </dt>    <dd>: <?php if($firma['face']=="" ) {} else {?><a href="http://<?php echo $firma['face']; ?>" target="_blank">Facebook Sayfamız</a><?php }?></dd> 
   <dt>Email Formu</dt>    <dd>:
    <?php  if($firma['email']=="") { echo "Email belirtilmemis.";} else { ?>
   
<a href="include/pop-mail-gonder.php?id=<?php echo $id; ?>&iframe=true&width=450&height=230" rel="prettyPhoto[iframes]" title="<?php echo $firma['adi']; ?> mail gönder. ">Tıklayınız.</a>
<?php } ?>
 </dd> 
 </dl>

</div>

</div>

<?php }  ?>

