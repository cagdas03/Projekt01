﻿   <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
   
    
    
<div id="sidebar">


<?php 

$sorgumodul=mysql_query("SELECT id,modul_adi,onay,sira, alias from modul where konum='sol' and onay=1 order by sira asc");
while($modul=mysql_fetch_assoc($sorgumodul)) {
switch($modul['alias'])
{
      case "sektor":
	  reklam_sol(sol_sektorustu);
	  include("include/sol-kategori.php");
	  reklam_sol(sol_sektoralti);
      break;
	         
      case "sef":
      include("include/sol-sonfirmalar.php"); 
	  break;
	  
	  case "uyelik":
      include("include/sol-uyeol.php"); 
      break;
     
      case "eczane":
	  include("include/sol-eczane.php");
	  break;
	  

	        case "sol-son-genel-haber":
	  include("include/sol-songenelhaber.php");
	  break;
	  
	  case "anket":
	  reklam_sol(sol_anketustu);
      include("anket.php"); 
      reklam_sol(sol_anketalti);
	  break;
	       
	  case "hava":
	  include("include/sol-hava.php");
	  break;
	  
	  case "solreklam":
	  include("include/sol-reklamlar.php"); 
	  break;
	  
	  default:
	  break;
	 
     }
	  
}

//include("include/sol-stats.php");  
// include("include/sol-bugunbuay.php");  

  ?>
    
  </div>




