<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<?php 
if($_SESSION['giris']==1 & $_SESSION['sid']>0)
{ 
$sid=$_SESSION['sid']."<br/>";
$_SESSION['giris']

?>

<?php
$sorgu=mysql_query("SELECT firma.id, firma.adi, firma.yetkili, firma.username, firma.etiket, firma.adres, firma.tel, firma.cep, firma.fax, firma.uyeliktur, firma.sehir, firma.ilce, firma.logo, firma.web, firma.face, firma.email, firma.detay, firma.video , firma.koordinat, firma.zoom , uyeliktur.tip_adi ,firma.bastarih FROM firma inner join uyeliktur on firma.uyeliktur=uyeliktur.id where firma.id='$sid' and firma.onay=1 limit 0,1") or die(mysql_error());
$firma=mysql_fetch_assoc($sorgu);

?>

<div class="orta_modul">
<div id="uclu">
<div id="detay-solalt">

<dl> 
   <dt>Kullanıcı Adı: </dt>  <dd>   <span><b style="color:#F00"><?php echo $firma['username']; ?></b></span>   <p></dd>
   <dt>Üyelik Tipi: </dt>  <dd>   <span style="background:#FF6; padding:3px"><b><?php echo $firma['tip_adi']; ?> Üye</b> <img style="padding-left:5px;" src="images/uye<?php echo $firma['uyeliktur']; ?>.png" width="13" height="12" /></span>   <p></dd>
  
   
 
 </dl>

</div>
<div id="detay-sagalt">
<dl> 
   <dt>Firma Adı: </dt>    <dd> <?php echo $firma['adi']; ?></dd> 
   <dt>Kayıt Tarihi:</dt>    <dd><?php tt_tarih($firma['bastarih']); ?></dd> 
 </dl>

</div>

</div>

</div>


     <?php 

	 } else { 
			echo "<script>window.top.location.href = 'index.html';</script>";
			}?>				
            
            
