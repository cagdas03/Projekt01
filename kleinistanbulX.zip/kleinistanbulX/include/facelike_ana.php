<div class="orta_modul">
<div id="uclu">

<div class="face_ana"><fb:like send="false" layout="button_count"  show_faces="true" action="recommend" font="verdana"></fb:like></div>
<div class="face_ana"><g:plusone size="medium"></g:plusone></div>
<div class="face_ana"><a href="https://twitter.com/share" class="twitter-share-button" data-lang="tr">Tweetle</a></div>

</div>
</div>