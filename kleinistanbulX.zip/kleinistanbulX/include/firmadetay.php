﻿     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<?php $id=intval(temizle($_GET['id']));
include("include/mailing.php");
$sorgu=mysql_query("SELECT * FROM firma where id='$id' and onay='1' limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
	
	$sorgu=mysql_query("SELECT firma.adi,  firma.logo, firma.uyeliktur, firma.yetkili,firma.tel, firma.fax, firma.web, firma.koordinat, firma.zoom, firma.face, firma.detay, firma.etiket, firma.email, firma.adres, firma.hit, firma.cep, firma.video, sehir.ad, ilce.ilce_adi, uyeliktur.tip_adi  from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join uyeliktur on uyeliktur.id=firma.uyeliktur where firma.onay=1 and firma.id='$id' limit 0,1") or die(mysql_error() );
	while ( $firma=mysql_fetch_assoc($sorgu) ) {
 //Hit ekleyelim
$yenihit=$firma['hit']+1;
$hitle=mysql_query("UPDATE firma SET hit='$yenihit' where id='$id' ") or die(mysql_error());


 //Hit ekleyelim
				$now=time();
				$gunum=date("z");
				 $ayim=date("m");
				 $yilim=date("y");
				$ipal=$_SERVER["REMOTE_ADDR"]; 
				$cek=mysql_query("SELECT id from hit where firmaid='$id' and gun='$gunum' and ip='$ipal' ");
				$sayip=mysql_num_rows($cek);
				if($sayip>0)
	 { } else 
	{$hitle=mysql_query("INSERT INTO hit (id, firmaid, tarih, gun, ay, yil,ip) VALUES ('', '$id' ,'$now', '$gunum','$ayim', '$yilim','$ipal')") or die(mysql_error());}
?>                
	
    

<div class="orta_modul">
<?php include("include/fdetay_tepe.php"); ?>
  

<div id="uclu">
<div  id="fdtek">
<?php include("include/facelike.php"); ?>
<div class="face w350">
<?php 
    $bugun=date("z");
	$ay=date("m");
	$yil=date("y"); ?>
 Bu firma 
Bugün <b  class="redhit"><?php
$cek=mysql_query("SELECT COUNT(hit.id) FROM hit inner join firma on firma.id=hit.firmaid where hit.firmaid='$id' and hit.gun='$bugun' and hit.ay='$ay' and hit.yil='$yil' ");
while($sayim=mysql_fetch_row($cek)) { echo $sayim['0'] ; }
?></b>, Bu Ay 
 <b class="redhit"><?php
$cek=mysql_query("SELECT COUNT(hit.id) FROM hit inner join firma on firma.id=hit.firmaid where hit.firmaid='$id'  and hit.ay='$ay' and hit.yil='$yil' ");
while($sayim=mysql_fetch_row($cek)) { echo $sayim['0'] ; }
?></b> , toplamda 
<b class="redhit">
<?php
$cek=mysql_query("SELECT COUNT(hit.id) FROM hit inner join firma on firma.id=hit.firmaid where hit.firmaid='$id' ");
while($sayim=mysql_fetch_row($cek)) { echo $sayim['0'] ; }?>
</b> kez ziyaret edildi.</div>

</div>
</div>



</div>











<?php if($firma['uyeliktur']>1)  {?>

<?PHP
    $sql="SELECT firmaresim from firmaresim where fid='$id' order by rand() limit 0,1";
	$fot=mysql_query($sql) or die(mysql_error());
	$foto=mysql_fetch_assoc($fot);
	
	if(!empty($foto))
	{
	$ffoto="uploads/firmaresim/".$foto['firmaresim'];
	}
	else
	{
	$ffoto="images/ilanresim.png";
	$stil=" style='display:none' ";
	}
	?>
    
<div class="orta_modul" <?php echo $stil; ?>>
<div id="uclu">
<div id="detay-fadi">
Firma Resimleri
</div>
<div id="fdtek">
<?php include("include/fotogaleri.php"); ?>
</div>

</div>
</div>







<?php if( !empty($firma['detay'])    ) { ?>
<div class="orta_modul">
<div id="uclu">

<div id="detay-fadi">
Firma Detayları
</div>

<div id="fdtek" style="padding:10px; width:710px;">

<?php echo stripslashes($firma['detay']); ?> 
</div>
</div>
</div>
<?php }  ?>


<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firmanın Haritada Ki Yeri
</div>

<div id="fdtek">
<?php include("include/mapoto.php"); ?>
</div>

</div>
</div>




<?php if( !empty($firma['video'])    ) { ?>

<a name="videogit"></a>
<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firma Videosu
</div>
<div id="fdtek">
<?php echo $firma['video']; ?> 
</div>
</div>
</div>
<?php }  ?>



<?php } // Alt�n ya da g�m�? �yeyse yular�s� olsun?>



<?php if($firma['uyeliktur']==3)  {?>

<?php
$sorgu=mysql_query("SELECT urun.urun_baslik, urun.urunresim , urun.id , urun.urun_etiket from urun inner join firma on firma.id=urun.fid  where urun.fid='$id' and firma.onay=1 and urun.onay=1 limit 0,10 ");
$urunsay=mysql_num_rows($sorgu);
if($urunsay>0) {
?>
<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firma Ürünleri
</div>
<div id="fdtek">
<?php while($urun=mysql_fetch_assoc($sorgu)) {?>
<div id="fdurunkutu">
<a title="<?php echo $urun['urun_etiket']; ?>" href="urunler/<?php echo seo($urun['urun_baslik']); ?>_<?php echo $urun['id']; ?>.html#urungit" >
<?php if($urun['urunresim']=="") { echo "<img src='images/resimyok_detay.png'  >"; } else { ?>
<img src="uploads/urun/<?php echo $urun['urunresim']; ?>"  /><?php } ?>

<br><?php echo $urun['urun_baslik']; ?></a></div>

<?php }?>


</div>
</div>
</div>

 <?php } ?>
 
 
 
 <?php
$sorgu=mysql_query("SELECT ilan.ilan_baslik, ilan.id, ilantip.itip_adi,ilan.ilan_bas_tarih from ilan inner join firma on firma.id=ilan.fid inner join ilantip on ilantip.id=ilan.tip where ilan.fid='$id' and firma.onay=1 and ilan.onay=1 limit 0,10");
$ilansay=mysql_num_rows($sorgu);
if($ilansay>0) {
?>
<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firma Kampanyaları
</div>
<div id="fdtek">

<table class="tablox">
<tbody>
<tr>
<th>Kampanya Başlığı</th>
<th width="16%">Kampanya Tipi</th>
<th width="12%">Tarih</th>
</tr>


<?php while($ilan=mysql_fetch_assoc($sorgu)) {?>

<tr>
<td> <a title="<?php echo $ilan['ilan_baslik']; ?>" href="ilanlar/<?php echo seo($ilan['ilan_baslik']) ;?>_<?php echo $ilan['id']; ?>.html" ><?php echo $ilan['ilan_baslik']; ?></a></td>
<td><?php echo $ilan['itip_adi']; ?></td>
<td><?php echo tt_tarih($ilan['ilan_bas_tarih']); ?></td>

</tr>

<?php }?>

</tbody>
</table>


</div>
</div>
</div>
<?php }?>
 
 
 <?php
$sorgu=mysql_query("SELECT haber.haber_baslik, haber.haberresim , haber.id , haber.haber_etiket from haber inner join firma on firma.id=haber.fid  where haber.fid='$id' and firma.onay=1 and haber.onay=1 limit 0,10 ");
$habersay=mysql_num_rows($sorgu);
if($habersay>0) {
?>
<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firmadan Haberler
</div>
<div id="fdtek">
<?php while($haber=mysql_fetch_assoc($sorgu)) {?>
<div id="fdurunkutu">
<a title="<?php echo $haber['haber_etiket']; ?>" href="haberler/<?php echo seo($haber['haber_baslik']); ?>_<?php echo $haber['id']; ?>.html#habergit" >
<?php if($haber['haberresim']=="") { echo "<img src='images/resimyok_detay.png'  >"; } else { ?>
<img src="uploads/haber/<?php echo $haber['haberresim']; ?>"  /><?php } ?>

<br><?php echo $haber['haber_baslik']; ?></a></div>

<?php }?>


</div>
</div>
</div>

 <?php } ?>
 
 
 
 <?php
   // ilansay  while sonu
 } // alt�n �yelik sonu 
 }
  // $firma while d�ng�s�
  } // firma id sorgulama
  ?>