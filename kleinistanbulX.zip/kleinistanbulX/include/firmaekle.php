       <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
  <div id="content"> 
   <div class="orta_modul">

     <?php
					if(temizle($_GET['uye'])>"0")
						{
						 ?>
					    
												<P class="pathway">
						 <a href="index.html">Anasayfa</a> - Yeni Üyelik/Firma ekleme formu
						 </P>
						
					                            <form action="firma-kayit.html" method="post" enctype="multipart/form-data" class="cmxform" id="signupForm" onsubmit="return validate(this);">
  <fieldset>


<p align="right"> <a href="firma-ekle.html">Geri Git</a></p>
		<p>
      
         <label for="username2">Kullanıcı Adı :</label>
      <input type="text" name="username2" id="username2" onKeyUp="twitter.updateUrl(this.value)" />
    *<div id="status" style="margin-left:10px"></div>
  
	
		<p>
			<label for="password">Şifre:</label>
			<input name="password" type="password" id="password" maxlength="15" />
		*</p>
		<p>
			<label for="confirm_password">Şifre Tekrar:</label>
			<input name="confirm_password" type="password" id="confirm_password" maxlength="15" />
		*</p>
		        

 
 <p>
<label>
		Şehir : </label>
			      
			      <select name="sehir" id="sehir" >
				  
				    <option value="" >--Seçiniz</option> 

<?php  
$sql="SELECT ad,id from sehir order by ad asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option  value="<?php echo $array['id'] ;?>" > <?php echo $array['ad']; ?> </option>  

<?  
}  
?>  
		        </select>
		*</p>
		
		<p>
		<label>
		İlçe: </label>
			      
			      <select name="ilce" id="ilce" >
				   <option value="" >Önce şehir seçiniz</option> 
				   
				   <?php  
$sql="SELECT ilce_adi,sehir,ilceid from ilce order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option  value="<?php echo $array['ilceid'] ;?>" class="<?php echo $array['sehir'];?>"> <?php echo $array['ilce_adi']; ?> </option>  

<?  
}  
?>  
          </select>
		*</p>
 
 
 			
		
				<p>
			<label for="adi">Firma Adı:</label>
			<input name="adi" id="adi" maxlength="200" />
		*</p>
		
				<p>
			<label for="yetkili">Firma Yetkilisi:</label>
			<input name="yetkili" id="yetkili" maxlength="200" />
				</p>
                
                		<p>
			<label for="email">Email:</label>
			<input name="email" id="email" maxlength="200" />
				</p>
                
                <p>
			<label for="etiket">Anahtar Kelimeler:</label>
			<input name="etiket" id="etiket"  /><br>Her kelime arasina virgül koyunuz.
				</p>
	
		<p>
	       <label for="fsektor">Sektör Seçiniz:</label>
			      
			      <select   name="fsektor"   />
                            <option value="">Bir Sektör Seçiniz</option>
                   <?php
						    $sql="SELECT ust_adi,ust_id from ustkat order by ust_adi asc;";
						    $sorgu=mysql_query($sql);
						    while($sektorler=mysql_fetch_assoc($sorgu))
							{?><option  value="<?php echo $sektorler['ust_id']; ?>"><?php echo $sektorler['ust_adi']; ?></option><?php }?>
                           </select>
                           				   
		*</p>
		
		
						
							
	
								<p>
			<label for="adres">Adres:</label>
			<textarea  name="adres" id="adres"></textarea>
								</p>
		<p>
			<label for="tel">İş Telefonu:</label>
			<input name="tel" id="telmask"  />
              <br />
            (0711) XXX-XXXX
		</p>
		
			<p>
			<label for="cep">Cep Telefonu:</label>
			<input name="cep" id="cepmask"  />
              <br />
            (01522) XXX-XXXX
		</p>
		
				<p>
			<label for="fax">Fax:</label>
			<input name="fax" id="faxmask" />
              <br />
            (212) XXX-XXXX
		</p>
        
        				<p>
                        
                        
			<label for="file">Logo:</label>
			<input type="file"  name="f_logo" value="" /> 
            <input type="hidden" name="actionlogo" value="logo" /><br>
            
            Max 200 kb, (jpg, gif ya da png formatında)
		</p>
		
   

        
                <p><label><input type="checkbox" class="checkin" name="agree" id="agree" /></label><span>
               <a href="include/pop-sartlar.php?id=<?php echo $id; ?>&iframe=true&width=450&height=500" rel="prettyPhoto[iframes]" title="Üyelik Şartları"> Üyelik şartlarını </a> okudum ve kabul ediyorum.</span>
        </p>
             
             
             <?php
			 if(temizle($_GET['uye']==1))
			 {
			  ?>
 <p><label><input type="checkbox" class="checkin" onclick="showhide(this, 'txt1');"   /></label>
 <span>Altın ya da gümüş üye olarak bir çok avantajdan  yararlanmak istiyorum.</span></p>
            <?php 
			 }
			 elseif(temizle($_GET['uye']==2))
			 {			 
			?>
 <p><label><input type="checkbox" style="float:right" class="checkin" onclick="showhide(this, 'txt1');" checked="checked"  disabled="disabled"   /></label><span>Gümüş üyemiz olmak istiyorsunuz.</span>
 </p>
 
      <?php 
	} elseif(temizle($_GET['uye']==3)) {			 
			?>
             <p><label><input type="checkbox" class="checkin" onclick="showhide(this, 'txt1');" checked="checked"  disabled="disabled"   /></label><span>Altın Üyemiz olmak istiyorsunuz.</span>
 </p>    
 
        <?php }
		else {
			echo "<meta http-equiv='refresh' content='0;URL=index.html'> "; 
			}
		?>
 
 
                     
            
      <div id="txt1"  <?php if(temizle($_GET['uye'])>1) { } else { echo "style='display:none' "; } ?>>
 

<p><label></label>
<input  type="radio"  style="width:30px" name="arabeni" value="Temsilci" onClick="check('arabeni', this)">
 Tarafıma bir temsilci gönderilmesini istiyorum. </p>
 <p>
 <label></label>
<input  type="radio"  style="width:30px" name="arabeni" value="Telefon" onClick="check('arabeni', this)">
Telefon ile bilgilendirilmek istiyorum.
</p>


<div id="arabeni"  style="display:none" >

<p> <label for="uadi">Ad Soyad:</label>
<input type="text"  name="uadi" value="" /> </p>

<p> 
<label for="uadres">Adres:</label>
<input type="text"  name="uadres" value="" /> 
</p>

<p> <label for="utel">Telefon:</label>
<input type="text"  name="utel" value="" /> </p>

 
 </div>


</div>
               
               
                     		  <p>
			<input  type="hidden" name="utur" value="<?php echo temizle($_GET['uye']); ?>"/>
		</p>
       <p><label></label><img src="securimage/securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>"></p>
        <p><label for="gkod">Güvenlik Kodu:</label><input type="text" name="gkod" id="gkod" maxlength="5" size="30"></p>
        
           		  <p>
			<input class="submit" type="submit" value="Firmamı Ekle!"/>
		</p>
	</fieldset>
</form>
		
					    
                        <?php
						}
				
						else
						{
						?>
						                                                
                       <div  class="entry">
                        <div id="uyetipi">
                       <IMG SRC="images/kampanya.png" >
                        </div>
                      </div>
					  
						
                               <div  class="entry">
                        <div id="uyetipi">
                       <A HREF="normal-firma-ekle.html" >  <IMG SRC="images/normal.png" ></A>
                        </div>
                        </div>
                        
                                                
                       <div  class="entry">
                        <div id="uyetipi">
                       <A HREF="gumus-firma-ekle.html" >  <IMG SRC="images/gumus.png" ></A>
                        </div>
                      </div>
                                                
                        
                           <div  class="entry">
                        <div id="uyetipi">
                      <A HREF="altin-firma-ekle.html" >  <IMG SRC="images/altin.png" ></A>
                        </div>
                        </div>
                     <?php }?>
                        </div>
</div>                     
					