﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_reklam">
<?php 
reklam_solalt(sol_alt1);
reklam_solalt(sol_alt2);
reklam_solalt(sol_alt3);
reklam_solalt(sol_alt4);
reklam_solalt(sol_alt5);
reklam_solalt(sol_alt6);
reklam_solalt(sol_alt7);
reklam_solalt(sol_alt8);
reklam_solalt(sol_alt9);
reklam_solalt(sol_alt10);

 ?>
</div>