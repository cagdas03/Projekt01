     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
				<?php
	
$kosul = '';
if($ustkat > ' '){ $kosul = $kosul . ' and sektor.s_ustid=\''.$ustkat.'\''; }
if($sehir > ' '){ $kosul = $kosul . ' and firma.sehir=\''.$sehir.'\''; }
if($ilce > ' '){ $kosul = $kosul . ' and firma.ilce=\''.$ilce.'\''; }
if($kelime !='Aranacak Kelime..'){ $kosul = $kosul . ' and ilan.ilan_baslik like \'%'.$kelime.'%\''; }

$query = "";

require_once 'lib/sayfalama.class.php';
 $db_count=@mysql_num_rows(mysql_query("SELECT firma.id FROM firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join sektor on sektor.s_fid=firma.id  inner join ustkat on ustkat.ust_id=sektor.s_ustid inner join ilan on ilan.fid=firma.id where 1  ".$kosul." and firma.onay='1' and ilan.onay='1'  and firma.uyeliktur=3 group by ilan.id "));

 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
 $pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
 
 if($db_count<1)
 {
 echo "<div class='hata'> Aradığınız kriterlere uygun ilan bulunamadı. Arama seçeneklerinizi değiştirebilirsiniz.</div>";
 }
 else
 {


	
?>


<div id="ucluliste">



<table class="tablox">
<tbody>
<tr>
<th>İlan Başlığı</th>
<th width="24%">Firma Adi</th>
<th width="25%">İlçe/Şehir</th>
<th width="16%">Üyelik Türü</th>
</tr>


<?php
$result=mysql_query("select ilan.id, ilan.ilan_baslik, ilan.ilan_etiket, firma.adi, firma.uyeliktur, ilce.ilce_adi,sehir.ad from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join sektor on sektor.s_fid=firma.id  inner join ustkat on ustkat.ust_id=sektor.s_ustid inner join ilan on ilan.fid=firma.id  where  1 $kosul and firma.onay='1' and ilan.onay='1' and firma.uyeliktur=3 group by ilan.id order by firma.uyeliktur desc   $pages->limit") or die (mysql_error());
	while($ilan = mysql_fetch_assoc($result))
	{
		?>
<tr>
<td><a title="<?php echo $ilan['ilan_etiket']; ?>" href="ilanlar/<?php echo seo($ilan['ilan_baslik']) ;?>_<?php echo $ilan['id']; ?>.html" ><?php echo $ilan['ilan_baslik']; ?></a></td>
<td> <?php echo $ilan['adi']; ?></a></td>
<td><?php echo $ilan['ilce_adi']; ?> / <?php echo $ilan['ad']; ?></td>
<td><img src="images/xpaket<?php echo $ilan['uyeliktur'];?>.png" /></td>

</tr>
                      					
<?php } ;?>            
	</tbody>
    </table>  
    </div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
 }
?>