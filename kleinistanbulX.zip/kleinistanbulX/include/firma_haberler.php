     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.php';</script>";
   exit();
    } ?> 
 
   <div class="orta_modul">
    
  <div id="anafirma-wrap"> <p>FİRMA HABERLERİ</p>
    <?php
	
	
  $sql="SELECT haber.haberresim,haber.id, haber.haber_baslik, haber.haber_etiket FROM haber inner join firma on firma.id=haber.fid where  firma.onay=1 and firma.uyeliktur=3 and haber.onay=1 order by haber.haber_bas_tarih desc limit 0,".$rowtt['ana_liste']."";
  $sorgu=mysql_query($sql) or die (mysql_error());
  $altinsay=mysql_num_rows($sorgu);
  while($array=mysql_fetch_array($sorgu))
  {
  
  $sef=seo($array['haber_baslik']);

  
  ?>
    <div id="anafirma-dis" >
    <a href="haberler/<?php echo $sef; ?>_<?php echo $array['id'];?>.html"  title="<?php echo $array['haber_baslik'];?> | <?php echo $array['haber_etiket'];?>" >
    <?php if(empty($array['haberresim'])) {
		echo "<img src='images/resimyok_ana.png' />";
	} else {
		 ?>
    <img src="uploads/haber/<? echo $array['haberresim'];?>"  />
    <?php } ?>
    <br />
	<?php echo mb_substr($array['haber_baslik'],0,45,'UTF-8');?></a>
    
    </div>
	

	<?php
    }
	 for($i=$altinsay;$i<$rowtt['ana_liste'];$i++)
    {
		?>
        <div id="anafirma-dis" >
    <a href="altin-firma-ekle.html" title="firma ekle">
    <img src="images/altin_ol.png" width="136" /><br />
	Haberiniz burada olsun ister misiniz?.</a>
    
    </div>
    
        <?php
    }
	?>
</div>
</div>
