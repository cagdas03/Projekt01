<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
<head>
<meta name="robots" content="index, follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico">  
        
   </head>
   <body>
   
   <?php
   include("../include/ayar.inc.php");
  	
	?>

 <style>
 .maildetay{background:#FAF8ED; font-size:12px; font-family:Tahoma; } 
 #stylized{ background-color:#EBF8A4; border:1px solid #FECD6D; padding:5px;}
</style>



<div  class="maildetay">


<div id="stylized">
<?php echo stripslashes($rowtt['sartlar']); ?>
</div>

</div>


</body>
</html>
