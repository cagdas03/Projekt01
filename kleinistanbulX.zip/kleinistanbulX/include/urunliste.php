<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<div class="orta_modul">
<div id="uclu">
<p><b class="red">ÜRÜN LİSTESİ</b><a style="float:right" title="Liste Şeklinde Alt Alta Görüntüle" href="index.php?tur=urun&pg=ara"><img src="images/liste.png" /></a></p>
</div>
</div>


<div class="orta_modul">

<div id="ucluliste">

 <?php
 require_once 'lib/sayfalama.class.php';
 $db_count=@mysql_num_rows(mysql_query("SELECT urun.id FROM urun inner join firma on firma.id=urun.fid where firma.onay=1 and urun.onay=1 and firma.uyeliktur=3 "));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
 $pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
 
 $sql=mysql_query("SELECT urun.id, urun.urun_baslik, urun.urun_etiket, urun.urunresim, urun.urun_fiyat, urun.urun_detay, urun.urun_indirim,  firma.adi, sehir.ad, ilce.ilce_adi FROM urun inner join firma on firma.id=urun.fid  inner join sehir on firma.sehir=sehir.id inner join ilce on firma.ilce=ilce.ilceid where firma.onay=1 and urun.onay=1 and firma.uyeliktur=3 order by urun.urun_bas_tarih desc $pages->limit") or die(mysql_error());
 while($sorgu=mysql_fetch_assoc($sql))
 {?>


<div id="urun_dis">
<div id="urun_listekutu">
<p><a href="urunler/<?php echo seo($sorgu['urun_baslik']);?>_<?php echo $sorgu['id'];?>.html" title="<?php echo $sorgu['urun_etiket']; ?>" />


    <?php if(empty($sorgu['urunresim'])) {echo "<img src='images/resimyok_liste.png' width='136' height='94' />";} else {	 ?>
    <img src="uploads/urun/<?php echo $sorgu['urunresim']; ?>" width="136" height="94"  /> <?php } ?>
<?php echo mb_substr($sorgu['urun_baslik'],0,45,'UTF8'); ?>..</a></p>
</div>

<div id="urun_fiyat">
 <?php  if(!empty($sorgu['urun_fiyat'])) {  
	  if(!empty($sorgu['urun_indirim']))
	  { echo "<b class='red'>".para(round($sorgu['urun_fiyat']-($sorgu['urun_fiyat']*$sorgu['urun_indirim'])/100,2))." TL </b> <b class='indirim'>".para(round($sorgu['urun_fiyat']))." TL </b>"; ?>  <?php }	  else 	  {  echo "<b class='red'>".para(round($sorgu['urun_fiyat']))." TL</b>"  ;	} } else { echo "Belirtilmemiş";}
  ?>
</div>


</div>

<?php
}

?>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>