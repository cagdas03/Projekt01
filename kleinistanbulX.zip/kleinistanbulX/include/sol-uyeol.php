﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<div id="sol_modul">
<div id="sol_modul_tepe" >ÜYELİK</div>

<div id="sol_modul_orta">
<A href="firma-ekle.html">
Üyelik türleri ve avantajlarını görmek için tıklayınız.</A>

</div>
<div id="sol_modul_alt" ></div>
</div>