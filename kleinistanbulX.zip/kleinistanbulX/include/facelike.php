<div class="face"><fb:like send="false" layout="button_count"  show_faces="true" action="recommend" font="verdana"></fb:like></div>
<div class="face"><g:plusone size="medium"></g:plusone></div>
<div class="face"><a href="https://twitter.com/share" class="twitter-share-button" data-lang="tr">Tweetle</a></div>