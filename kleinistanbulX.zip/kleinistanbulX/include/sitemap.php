<?  include ("include/ayar.inc.php");
        function taner($url) 
{
	     $url = trim($url);     
		 $find = array('<b>', '</b>');     
		 $url = str_replace ($find, '', $url);     
		 $url = preg_replace('/<(\/{0,1})img(.*?)(\/{0,1})\>/', 'image', $url);     
		 $find = array(' ', '&quot;', '&amp;', '&', '\r\n', '\n', '/', '\\', '+', '<', '>');     
		 $url = str_replace ($find, '-', $url);     
		 $find = array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ë', 'Ê','ə' ,'Ə');     
		 $url = str_replace ($find, 'e', $url);     
		 $find = array('í', 'ý', 'ì', 'î', 'ï', 'I', 'Ý', 'Í', 'Ì', 'Î', 'Ï','İ','ı');     
		 $url = str_replace ($find, 'i', $url);     
		 $find = array('ó', 'ö', 'Ö', 'ò', 'ô', 'Ó', 'Ò', 'Ô');     
		 $url = str_replace ($find, 'o', $url);     
		 $find = array('á', 'ä', 'â', 'à', 'â', 'Ä', 'Â', 'Á', 'À', 'Â');     
		 $url = str_replace ($find, 'a', $url);     
		 $find = array('ú', 'ü', 'Ü', 'ù', 'û', 'Ú', 'Ù', 'Û');     
		 $url = str_replace ($find, 'u', $url);     
		 $find = array('ç', 'Ç');     
		 $url = str_replace ($find, 'c', $url);     
		 $find = array('þ', 'Þ', 'Ş', 'ş');     
		 $url = str_replace ($find, 's', $url);     
		 $find = array('ð', 'Ð', 'Ğ', 'ğ');     
		 $url = str_replace ($find, 'g', $url);     
		 $find = array('/[^A-Za-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');     
		 $repl = array('', '-', '');     
		 $url = preg_replace ($find, $repl, $url);    
		 $url = str_replace ('--', '-', $url);     
		 $url = strtolower($url);     
		  return $url; } 

$resultsube = mysql_query("SELECT firma.adi, firma.bastarih, firma.id from firma order by firma.bastarih desc")  or die(mysql_error()); 
$tarih= date("Y-n-j");
echo '<?xml version="1.0" encoding="UTF-8" ?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';
echo '<url><loc>'.$rowtt['site_url'].'</loc><lastmod>'.$tarih.'</lastmod><changefreq>daily</changefreq><priority>1.00</priority></url>';

while ($results = mysql_fetch_assoc($resultsube)) 
{?>
<url>
  <loc><?php echo $rowtt['site_url']; ?>/firmalar/<? echo taner($results['adi']);?>_<? echo $results['id']; ?>.html</loc> 
  <lastmod><?  echo $tarih;?></lastmod> 
  <changefreq>daily</changefreq> 
  <priority>0.90</priority>  
  </url>

<? } ?>




</urlset> 
