     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
 <?php

//Fetch Time
$timestamp = time();
$timeout = $timestamp - 3600;

//Insert User
$insert = mysql_query("INSERT INTO online (timestamp, ip) VALUES('$timestamp','".$_SERVER['REMOTE_ADDR']."') ") or die(mysql_error());
//Delete Users
$delete = mysql_query("DELETE FROM online WHERE timestamp<$timeout") or die("online user hata!");
//Fetch Users Online
$result = mysql_query("SELECT DISTINCT ip FROM online") or die("online user hata!");
$users = mysql_num_rows($result);
echo $users;

$bugun=date("z");
$buyil=date("y");
$sorgu=mysql_query("SELECT * from stats where gun='$bugun' and yil='$buyil' ");
$sayhit=@mysql_num_rows($sorgu);
if($sayhit>0)
{
$izsay=@mysql_fetch_assoc($sorgu);
$bugun_view=$izsay['izlenme']+1;
$guncelle_gun = mysql_query("UPDATE stats SET izlenme='$bugun_view' where gun='$bugun' and yil='$buyil'") or die(mysql_error());
}
else
{ $ekle_gun = mysql_query("INSERT INTO stats (izlenme, gun, yil) VALUES ('1' , '$bugun', '$buyil')") or die(mysql_error()); }

$yil_sql=mysql_query("SELECT SUM(izlenme) from stats where id>0 ");
$yil_cek=@mysql_fetch_row($yil_sql);
$toplam_view=$yil_cek['0'];




?> 