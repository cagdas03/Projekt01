<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 
<?php $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT * FROM urun inner join firma on firma.id=urun.fid where urun.id='$id' and urun.onay='1' and firma.onay=1 and firma.uyeliktur=3 limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
	
 $sql="SELECT firma.id, firma.adi,  firma.logo, firma.uyeliktur, firma.yetkili,firma.tel, firma.fax, firma.web, firma.koordinat, firma.zoom, firma.face, firma.detay, firma.etiket, firma.email, firma.adres, urun.hit, sehir.ad, ilce.ilce_adi, uyeliktur.tip_adi, urun.urun_baslik, urun.urun_detay, urun.urunresim, urun.urun_fiyat, urun.urun_bas_tarih, urun.urun_indirim  from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce inner join uyeliktur on uyeliktur.id=firma.uyeliktur inner join urun on urun.fid=firma.id where firma.onay=1 and urun.onay=1 and urun.id='$id' and firma.uyeliktur=3 limit 0,1";
	$sorgu=mysql_query("$sql") or die(mysql_error() );
	while ( $firma=mysql_fetch_assoc($sorgu) ) {
 //Hit ekleyelim
$yenihit=$firma['hit']+1;
$hitle=mysql_query("UPDATE urun SET hit='$yenihit' where id='$id' ") or die(mysql_error());
 ?>
      
<a name="firmagit"></a>
<div class="orta_modul">

<?php // include("include/fdetay_tepe.php"); ?>

    

<div id="uclu">
<div  id="fdtek">
<?php include("include/facelike.php"); ?>
<div class="face w200"> Bu ürün <b style="font-size:14px; color:#F00; font-weight:bold"><?php echo $firma['hit'] ;?></b> kez ziyaret edildi.</div>

</div>
</div>



</div>




<a name="urungit"></a>
<div class="orta_modul">
<div id="uclu">

<div id="detay-fadi">
<?php echo $firma['urun_baslik']; ?>
<span class="fr"><a href="firmalar/<?php echo seo($firma['adi']); ?>_<?php echo $firma['id']; ?>.html">Firma Detayina Git</a></span>
</div>

    <script type="text/javascript">
    $(function() {
        $('#urunresim a').lightBox();
    });
    </script>
    

<div id="fdurun" style="padding:5px;">
<div id="urunresim" class="urunresim">

<?php if(empty($firma['urunresim'])) { ?> <img src="images/resimyok_uidetay.png" width="240"  />
<?php } else {?>
<a href="uploads/urun/<?php echo $firma['urunresim']; ?>" ><img src="uploads/urun/<?php echo $firma['urunresim']; ?>" width="240"  /></a>
<?php }?>
<br />Bu ürün <b style="color:#F00"><?php echo $firma['hit']; ?></b> kez ziyaret edildi




</div>

<dl> 
   <dt>Ürün Adı</dt>  <dd>:<?php echo $firma['urun_baslik']; ?></dd>
   <?php if (!empty($firma['urun_fiyat'])) {?>
   <?php if(!empty($firma['urun_indirim'])) { ?> 
   <dt>Fiyatı:</dt>    <dd>: <b class="indirim"> <?php echo para($firma['urun_fiyat']); ?></b> TL yerine <b> 
   <?php echo para(round($firma['urun_fiyat']-($firma['urun_fiyat']*$firma['urun_indirim'])/100,2)); ?> TL</b> </dd> 
   <dt>İndirim Oranı:</dt>    <dd>: % <?php echo $firma['urun_indirim']; ?> </dd> <?php } else { ?>
   <dt>Fiyatı:</dt>    <dd>: <b> <?php echo para($firma['urun_fiyat']); ?></b></dd> 
   <?php }?>
    <?php }?>
   <dt>Açıklama:</dt>    <dd><?php echo stripslashes($firma['urun_detay']); ?> </dd>
   
   </dl>


</div>
</div>
</div>









<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Firmanin Diğer Ürünleri
</div>
<div id="fdtek">

<?php
$sql="SELECT urun.id, urun.urun_baslik, urun.urunresim, urun.urun_etiket FROM urun inner join firma on firma.id=urun.fid where firma.onay=1 and urun.onay=1 and firma.uyeliktur=3 and urun.fid='".$firma['id']."' limit 0,10";
$sorgu=mysql_query($sql) or die(mysql_error());
while($urun=mysql_fetch_assoc($sorgu))
{
	
$sef=seo($urun['urun_baslik']);	
// 133x84 resim
 ?>

<div id="fdurunkutu">
<a title="<?php echo $urun['urun_etiket']; ?>" href="urunler/<?php echo $sef; ?>_<?php echo $urun['id']; ?>.html#urungit" >

<?php if($urun['urunresim']=="") { echo "<img src='images/resimyok_detay.png' >"; } else { ?>
<img src="uploads/urun/<?php echo $urun['urunresim']; ?>"  /><?php } ?>

<br>
<?php echo $urun['urun_baslik']; ?></a>
</div>

<?php }?>


</div>
</div>
</div>

 
 
 <?php } // while bitis ?>
 
 
 <?php  } // �r�n id bitis?>
 