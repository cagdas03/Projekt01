     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
<?php $id=intval(temizle($_GET['id']));
$sorgu=mysql_query("SELECT haber.id FROM haber inner join firma on firma.id=haber.fid where haber.id='$id' and haber.onay='1' and firma.onay=1 and firma.uyeliktur=3 limit 0,1") or die(mysql_error());
$say=@mysql_num_rows($sorgu);
if($say<1 || $id=='0' ) { echo "<meta http-equiv='refresh' content='0;URL=../index.html'> "; }
else {
$sorgu=mysql_query("SELECT haber.haber_baslik, haber.fid, haber.haber_bas_tarih, haber.haberresim, haber.haber_detay, firma.adi FROM haber inner join firma on firma.id=haber.fid where haber.id='$id' and haber.onay=1 and firma.onay=1 and firma.uyeliktur=3 limit 0,1");
while($haber=mysql_fetch_assoc($sorgu)){?>


<div class="orta_modul">
<div id="uclu">
<div id="detay-hadi">
<?php echo $haber['haber_baslik']; ?> / <a href="firmalar/<?php echo seo($haber['adi']); ?>_<?php echo $haber['fid'];?>.html"><?php echo $haber['adi']; ?></a>

<span  class="fr pr55 tarih"><?php echo tt_tarih($haber['haber_bas_tarih']); ?></span>
</div>
   

<div id="fdtek">
<div id="haberresim" class="haberresim">
<a href="uploads/haber/<?php echo $haber['haberresim']; ?>" ><img src="uploads/haber/<?php echo $haber['haberresim']; ?>"  width="200" /></a>
</div>
<div class="haberdetay">
<p><?php echo stripslashes($haber['haber_detay']); ?></p>
<br />

<a href="firmalar/<?php echo seo($haber['adi']); ?>_<?php echo $haber['fid'];?>.html">Bu Firmanın Detaylarını Gör</a>
</div>

<div class="haberdetay">
<?php include("include/facelike.php"); ?>

</div>


</div>
</div>
</div>

 
 <?php }}?>