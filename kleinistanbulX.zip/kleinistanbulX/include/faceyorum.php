<?php 
$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === FALSE ? 'http' : 'https'; 
// get the protocol 
$host = $_SERVER['HTTP_HOST']; 
// host name
 $script = $_SERVER['SCRIPT_NAME']; // script path
 $params = $_SERVER['QUERY_STRING']; // params 
 $uri = $_SERVER['REQUEST_URI']; // full script path with params if you are not interested in protocol or host name 
$currentUrl = $protocol . '://' . $host . $uri; 
?>
<div class="orta_modul">
<div id="uclu">
<div id="detay-fadi">
Facebook Yorumları
</div>
<div id="fdtek">
<fb:comments href="<?php echo $currentUrl;?>" num_posts="5" width="732"></fb:comments>
</div>
</div>
</div>