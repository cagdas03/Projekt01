     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>    
    <div id="foot">
    
    
    
    <div id="foot_stat">
	<?php
	   $sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=1  and firma.onay=1 ");
	$nsay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=2  and firma.onay=1 ");
	$gsay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT firma.id from firma inner join sehir on sehir.id=firma.sehir inner join ilce on ilce.ilceid=firma.ilce where firma.uyeliktur=3  and firma.onay=1 ");
	$asay=@mysql_num_rows($sorgu);
	 	$sorgu=mysql_query("SELECT ilan.id from ilan inner join firma on firma.id=ilan.fid where firma.uyeliktur=3 and firma.onay=1 and ilan.onay=1 ");
	$isay=@mysql_num_rows($sorgu);
		$sorgu=mysql_query("SELECT urun.id from urun inner join firma on firma.id=urun.fid where firma.uyeliktur=3 and firma.onay=1 and urun.onay=1 ");
	$usay=@mysql_num_rows($sorgu);
  	
	?>
    Rehberimizde şu an <b><?php echo $asay; ?></b> Altın Firma,     <b><?php echo $gsay; ?></b> Gümüş Firma,     <b><?php echo $nsay; ?></b> Normal Firma ,    <b><?php echo $isay; ?></b> İlan ve  <b><?php echo $usay; ?></b> Ürün bulunmaktadır.      </div>
    
  <div id="foot_view">
  Sitemizde şu an <b> <?php include("include/online.php"); ?></b> Online Ziyaretçi olup; Bugün <?php echo $bugun_view; ?> olmak üzere toplamda <?php echo $toplam_view; ?> kez ziyaret edilmiştir.
  </div>
      
      
    
    <p>
   <a href="index.html"> Anasayfa </a> | <a href="/sektorler"> Sektörler </a> | <a href="/firmalar"> Firmalar </a> | <a href="/ilanlar">İlanlar</a> | <a href="/urunler"> Ürünler</a> | <a href="sayfa/reklamlar_7.html"> Reklam</a> | <a href="iletisim.html"> İletişim</a> | <a href="kunye.html"> Künye</a><br />
		<?php // echo temizle($rowtt['footer']); ?>	
		
        <span>
      	<span id="wobsbn"><a href="http://www.onlinewebstats.com/websites/Basvuru-kaynaklari.phtml">
<img src=http://sayac.onlinewebstat.com/logo/c2.gif alt="" border=0></a></span>
<script type="text/javascript" src="http://sayac.onlinewebstat.com/c4.js"></script>
<script type="text/javascript">ows_track("kleinistanbul")</script>
<noscript><img src="http://sayac1.onlinewebstat.com/analiz.php3?user=kleinistanbul" alt="" /></noscript>

      <a HREF="http://www.kleinistanbul.com" title="Kleinistanbul" onmouseover="document.but.src='images/ttyazho.png'"  onmouseout="document.but.src='images/ttyaz.png'" ><IMG SRC="images/ttyaz.png" NAME="but"  BORDER="0" ></A>       
        </span>
	</p>
</div>
    
  
	
		</div>
          <!-- end #wrapper-->
	
</body>
</html>

    
