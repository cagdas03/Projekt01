 [<?php
 include("../include/ayar.inc.php");
  include("../include/fonksiyon.php");
 
  $sql="SELECT firma.logo,firma.adi,firma.id, firma.etiket FROM firma  where  firma.onay=1  and firma.vitrin=1 order by rand() limit 0,".$rowtt['ana_liste']."";
  $sorgu=mysql_query($sql) or die (mysql_error());
  $max=mysql_num_rows($sorgu);
  $i=0;
  while($array=mysql_fetch_array($sorgu))
  {
  $sef=seo($array['adi']);
  ?>
{ "content": "<div class='slide_inner'><a class='photo_link' href='firmalar/<?php echo $sef; ?>_<?php echo $array['id'] ;?>.html'><img class='photo' src='../uploads/logo/<?php echo $array['logo']; ?>' alt='<?php echo $array['adi']; ?>'></a><a class='caption' href='firmalar/<?php echo $sef; ?>_<?php echo $array['id'] ;?>.html'><?php echo mb_substr($array['adi'],0,55); ?></a></div>" }
<?php
$i++; 
if($i!=$max) echo ",";
?>
<?php }	?>
]









