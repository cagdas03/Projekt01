﻿<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<div class="tab_container">
    <div id="tab1" class="tab_content">
  
    <ul>
    <? 
	$bugun=date("z");
	$ay=date("m");
	$yil=date("y");
		$sirano=1;
	$sql=mysql_query("SELECT COUNT(hit.id), firma.adi, firma.id FROM hit inner join firma on firma.id=hit.firmaid where hit.gun='$bugun' and hit.ay='$ay' and hit.yil='$yil' group by hit.firmaid   order by COUNT(hit.id) desc limit 0, 10");
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['1']);
	echo "<li>".$sirano.". <a title='".$tabcek['1']."' href='firmalar/".$sefle."_".$tabcek['2'].".html' >".mb_substr($tabcek['1'],0,28,'UTF8')." (".$tabcek['0'].")</a></li>";
	$sirano++;}
	?>
    </ul>
    </div>
    <div id="tab2" class="tab_content">
    
        <ul>
    <? 
	
	$sql=mysql_query("SELECT COUNT(hit.id), firma.adi, firma.id FROM hit inner join firma on firma.id=hit.firmaid where hit.ay='$ay' and hit.yil='$yil' group by hit.firmaid   order by COUNT(hit.id) desc limit 0, 10");
$sirano=1;
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['1']);
	echo "<li>".$sirano.". <a title='".$tabcek['1']."'  href='firmalar/".$sefle."_".$tabcek['2'].".html' >".mb_substr($tabcek['1'],0,28,'UTF8')." (".$tabcek['0'].")</a></li>";
	$sirano++;}
	?>
    </ul>
    </div>
        <div id="tab3" class="tab_content">
       
       <ul>
    <? 
	
	$sql=mysql_query("SELECT COUNT(hit.id), firma.adi, firma.id FROM hit inner join firma on firma.id=hit.firmaid where  hit.yil='$yil' group by hit.firmaid   order by COUNT(hit.id) desc limit 0, 10");
	$sirano=1;
	while($tabcek=mysql_fetch_row($sql))
	{ 
	$sefle=seo($tabcek['1']);
	echo "<li>".$sirano.". <a title='".$tabcek['1']."' href='firmalar/".$sefle."_".$tabcek['2'].".html' >".mb_substr($tabcek['1'],0,28,'UTF8')." (".$tabcek['0'].")</a></li>";
	$sirano++;
	}
	?>
    </ul>
    </div>
</div>





