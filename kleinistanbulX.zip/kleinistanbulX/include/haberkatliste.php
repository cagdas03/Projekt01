     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
    <div class="orta_modul">

<div id="uclu">
 <?php
 
  $tip=intval(temizle($_GET['tip']));
 
 $sql=mysql_query("SELECT mid,mkatadi FROM  mansetkat order by mid asc ");
 while($sorgu=mysql_fetch_assoc($sql))
 {
	
$saysql=mysql_query("SELECT manset.id, manset.kat from manset inner join mansetkat on mansetkat.mid=manset.kat where manset.onay=1 and mansetkat.mid=$sorgu[mid]"); 
$say=mysql_num_rows($saysql);
?>


<div id="sektorkutu">
<p><a href="haberler/<?php echo seo($sorgu['mkatadi']); ?>_kategorisi_haberleri<?php echo $sorgu['mid']; ?>.html" title="<?php echo $sorgu['mkatadi']; ?>" />
<?php 
if($tip==$sorgu['mid']) { echo "<b class='red'>".$sorgu['mkatadi']."</b>" ; } else { echo $sorgu['mkatadi']; }  ?></a><span> <b>(<?php echo $say;?>)</b>
</span>
</p>
</div>

<?php
}
?>

</div>
</div>


<div class="orta_modul">
<div id="ucluliste">


 <?php
 require_once 'lib/sayfalama.class.php';
 
 
  $kosul = ' ';
 if($tip>'' and $tip!=0){ $kosul = $kosul . ' and manset.kat='.$tip.''; }
 
 
 $db_count=mysql_num_rows(mysql_query("SELECT manset.id FROM manset inner join mansetkat on manset.kat=mansetkat.mid  where 1 ".$kosul." and manset.onay=1 "));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
 $pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
 
 $sql=mysql_query("SELECT manset.id, manset.manset_baslik, manset.manset_etiket, manset.manset_detay, manset.manset_ozet, mansetkat.mkatadi, manset.bastarih, manset.mansetresim FROM manset inner join mansetkat on manset.kat=mansetkat.mid  where 1 ".$kosul."  and manset.onay=1 order by manset.bastarih desc $pages->limit") or die(mysql_error());
 
 ?>
 
 <?php
 while($manset=mysql_fetch_assoc($sql))
 {?>
 
 
 <div class="onecikan-dis">
    <div class="listelogo">
   <a href="manset/<?php echo seo($manset['manset_baslik']); ?>_<?php echo seo($manset['id']); ?>.html" title="<?php echo $manset['manset_etiket']; ?>">
   <img src="uploads/manset/<?php echo $manset['mansetresim']; ?>" width="145"> </a>
 </div>
 
 <div style="width:185px; margin-top:3px; float:left; text-align:justify;">
 
  <b><a href="manset/<?php echo seo($manset['manset_baslik']); ?>_<?php echo $manset['id']; ?>.html" title="<?php echo $manset['manset_etiket']; ?>"><?php echo $manset['manset_baslik']; ?></a></b>
  <br>
  <a  class="ozet" href="manset/<?php echo seo($manset['manset_baslik']); ?>_<?php echo $manset['id']; ?>.html" title="<?php echo $manset['manset_etiket']; ?>">
<?php echo $manset['manset_ozet']; ?></a>
<span class="saat" ><?php echo tt_saat($manset['bastarih']);?></span>

 </div>   
    
    </div>

<?php
}

?>

</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>