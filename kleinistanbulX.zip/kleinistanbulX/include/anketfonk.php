<?php
 require("ayar.inc.php");

//GETTING VARIABLES START
$action 		= mysql_real_escape_string($_POST['action']);
$pollAnswerID	= mysql_real_escape_string($_POST['pollAnswerID']); 
//GETTING VARIABLES END


function getPoll($pollID){
	$query  = "SELECT * FROM polls LEFT JOIN pollAnswers ON polls.pollID = pollAnswers.pollID WHERE polls.pollID = " . $pollID . " ORDER By pollAnswerListing ASC";
	$result = mysql_query($query);
	//echo $query;jquery
	
	while(@$row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		$pollQuestion 		= $row['pollQuestion'];	
		$pollAnswerID 		= $row['pollAnswerID'];	
		$pollAnswerValue	= $row['pollAnswerValue'];
		
		
		$oyla="anket-oyla.png";
		
		
		if ($pollStartHtml == '') {
			$pollStartHtml 	= '     <div id="sol_modul"><div id="sol_modul_tepe" >ANKET</div>
        
        <div id="sol_modul_orta">
		<div id="pollWrap">
		
		<form name="pollForm" method="post" action="include/anketfonk.php?action=vote"> 
		<div class="fl anket-soru">' . $pollQuestion .'</div>
		<div style="clear:left"></div>
		<ul>';
			$pollEndHtml 	= '</ul>
		<input type="image" name="pollSubmit" id="pollSubmit" src="images/' . $oyla .'" alt="Oyla" >
		<span id="pollMessage"></span><img src="images/ajaxLoader.gif" alt="Anket" id="pollAjaxLoader" />
		</form>
		</div>
		</div>
		
		<div id="sol_modul_alt" ></div>
                </div>';	
		}
		$pollAnswersHtml	= $pollAnswersHtml . '<li><input name="pollAnswerID" id="pollRadioButton' . $pollAnswerID . '" type="radio" value="' . $pollAnswerID . '" /> ' . $pollAnswerValue .'<span id="pollAnswer' . $pollAnswerID . '"></span></li>';
		$pollAnswersHtml	= $pollAnswersHtml . '<li class="pollChart pollChart' . $pollAnswerID . '"></li>';
	}
	echo $pollStartHtml . $pollAnswersHtml . $pollEndHtml;
}

function getPollID($pollAnswerID){
	$query  = "SELECT pollID FROM pollAnswers WHERE pollAnswerID = ".$pollAnswerID." LIMIT 1";
	$result = mysql_query($query);
	$row = mysql_fetch_array($result);
	
	return $row['pollID'];	
}

function getPollResults($pollID){
	$colorArray = array(1 => "#ffcc00", "#00ff00", "#cc0000", "#0066cc", "#ff0099", "#ffcc00", "#00ff00", "#cc0000", "#0066cc", "#ff0099");
	$colorCounter = 1;
	$query  = "SELECT pollAnswerID, pollAnswerPoints FROM pollAnswers WHERE pollID = ".$pollID."";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result))
	{
		if ($pollResults == "") {
			$pollResults = $row['pollAnswerID'] . "|" . $row['pollAnswerPoints'] . "|" . $colorArray[$colorCounter];
		} else {
			$pollResults = $pollResults . "-" . $row['pollAnswerID'] . "|" . $row['pollAnswerPoints'] . "|" . $colorArray[$colorCounter];
		}
		$colorCounter = $colorCounter + 1;
	}
	$query  = "SELECT SUM(pollAnswerPoints) FROM pollAnswers WHERE pollID = ".$pollID."";
	$result = mysql_query($query);
	$row = mysql_fetch_array( $result );
	$pollResults = $pollResults . "-" . $row['SUM(pollAnswerPoints)'];
	echo $pollResults;	
}


//VOTE START
if ($action == "vote"){
	
	if (isset($_COOKIE["poll" . getPollID($pollAnswerID)])) {
		echo "voted";
			} else {
		$query  = "UPDATE pollAnswers SET pollAnswerPoints = pollAnswerPoints + 1 WHERE pollAnswerID = ".$pollAnswerID."";
		mysql_query($query) or die('Error, insert query failed');
		setcookie("poll" . getPollID($pollAnswerID), getPollID($pollAnswerID), time()+259200, "/");
		getPollResults(getPollID($pollAnswerID));
	}
}


	

//VOTE END
?>