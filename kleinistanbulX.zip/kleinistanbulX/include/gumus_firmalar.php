     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?> 
 
   <div class="orta_modul">
    
  <div id="anafirma-wrap"> <p>GÜMÜŞ FIRMALAR</p>
    <?php
	
	
  $sql="SELECT firma.logo,firma.adi,firma.id, firma.etiket FROM firma  where  firma.onay=1 and firma.uyeliktur=2 order by firma.bastarih desc limit 0,".$rowtt['ana_liste']."";
  $sorgu=mysql_query($sql) or die (mysql_error());
  $altinsay=mysql_num_rows($sorgu);
  while($array=mysql_fetch_array($sorgu))
  {
  
  $sef=seo($array['adi']);

  
  ?>
    <div id="anafirma-dis" >
  <a href="firmalar/<?php echo $sef;  ?>_<?php echo $array['id'];  ?>.html"  title="<?php echo $array['adi'];?> | <?php echo $array['etiket'];?>" >
    <?php if(empty($array['logo'])) {
		echo "<img src='images/resimyok_ana.png' />";
	} else {
		 ?>
    <img src="uploads/logo/<? echo $array['logo'];?>" />
    <?php } ?>
    <br />
	<?php echo mb_substr($array['adi'],0,45,'UTF-8');?></a>
    
    </div>
	

	<?php
    }
	 for($i=$altinsay;$i<$rowtt['ana_liste'];$i++)
    {
		?>
        <div id="anafirma-dis" >
    <a href="altin-firma-ekle.html" title="firma ekle">
    <img src="images/gumus_ol.png" width="136" /><br />
	Tıklayın, sizin firmanızda burada olsun.</a>
    
    </div>
    
        <?php
    }
	?>
</div>
</div>
