<?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
} ?> 

<script type="text/javascript" src="../js/nicEdit.js"></script>
<script type="text/javascript">
   bkLib.onDomLoaded(function() {
       
        new nicEditor({fullPanel : true}).panelInstance('noise');
        new nicEditor({maxHeight : 300}).panelInstance('area5');
		
  });</script>
<?php 
if($_SESSION['giris']==1 & $_SESSION['sid']>0)
{ 
$sid=$_SESSION['sid'];

?>

<?php
$sorgu=mysql_query("SELECT firma.id, firma.adi, firma.yetkili, firma.username, firma.etiket, firma.adres, firma.tel, firma.cep, firma.fax, firma.uyeliktur, firma.sehir, firma.ilce, firma.logo, firma.web, firma.face, firma.email, firma.detay, firma.video , firma.koordinat, firma.zoom , uyeliktur.tip_adi ,firma.bastarih FROM firma inner join uyeliktur on firma.uyeliktur=uyeliktur.id where firma.id='$sid' and firma.onay=1 limit 0,1") or die(mysql_error());
$firma=mysql_fetch_assoc($sorgu);


if (temizle($_GET['is'])=='lsil') {
$resimyol=mysql_query("SELECT logo FROM firma where onay=1 and id='$sid' limit 0,1 ");
while($unresim=mysql_fetch_assoc($resimyol)){$yol=$unresim['logo']; @unlink("uploads/logo/$yol"); }
$sil=mysql_query("UPDATE firma set logo='' where id='$sid' and onay=1 ");
echo "<meta http-equiv='refresh' content='0;URL=panel_profilim.html'> ";
}
elseif(temizle($_GET['is'])=='frsil')
{
$rid=temizle($_GET['rid']);
$resimyol=mysql_query("SELECT firmaresim FROM firmaresim where onay=1 and fid='$sid' and id='$rid' limit 0,1 ");
while($unresim=mysql_fetch_assoc($resimyol)){$yol=$unresim['firmaresim']; @unlink("uploads/firmaresim/$yol"); }
$sil=mysql_query("DELETE FROM firmaresim where id='$rid' and fid='$sid' and onay=1 ");
echo "<meta http-equiv='refresh' content='0;URL=panel_profilim.html'> ";
	

}


?>

 <div class="orta_modul">
<div id="uclu">
<div id="detay-solalt">

<dl> 
   <dt>Kullanıcı Adı: </dt>  <dd>   <span><b style="color:#F00"><?php echo $firma['username']; ?></b></span>   <p></dd>
   <dt>Üyelik Tipi: </dt>  <dd>   <span style="background:#FF6; padding:3px"><b><?php echo $firma['tip_adi']; ?> Üye</b> <img style="padding-left:5px;" src="images/uye<?php echo $firma['uyeliktur']; ?>.png" width="13" height="12" /></span>   <p></dd>
  
   
 
 </dl>

</div>
<div id="detay-sagalt">
<dl> 
   <dt>Firma Adı: </dt>    <dd> <?php echo $firma['adi']; ?></dd> 
   <dt>Kayıt Tarihi:</dt>    <dd><?php tt_tarih($firma['bastarih']); ?></dd> 
 </dl>

</div>

</div>

</div>

  


   <div class="orta_modul">



		    
											
      <form action="panel_profilim_kayit.html" method="post" enctype="multipart/form-data" class="cmxform" id="signupForm" >
  <fieldset>
	<p>	
<label>
		Şehir : </label>
			      
			      <select name="sehir" id="sehir" >
				  
				    <option value="" >--Seçiniz</option> 

<?php  
$sql="SELECT ad,id from sehir order by ad asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option  value="<?php echo $array['id'] ;?>" <?php if($firma['sehir']==$array['id']) { echo "selected='selected'" ;} ?> > <?php echo $array['ad']; ?> </option>  

<?  
}  
?>  
		        </select>
		*</p>
		
		<p>
		<label>
		İlçe: </label>
			      
			      <select name="ilce" id="ilce" >
				   <option value="" >Önce şehir seçiniz</option> 
				   
				   <?php  
$sql="SELECT ilce_adi,sehir,ilceid from ilce order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  

?>  
<option  value="<?php echo $array['ilceid'] ;?>" class="<?php echo $array['sehir'];?>" <?php if($firma['ilce']==$array['ilceid']) { echo "selected='selected'" ;} ?> > <?php echo $array['ilce_adi']; ?> </option>  

<?  
}  
?>  
          </select>
		*</p>
 
 
 			
		
				<p>
			<label for="adi">Firma Adı:</label>
			<input name="adi" id="adi"  value="<?php echo $firma['adi']; ?>" maxlength="200" />
		*</p>
		
				<p>
			<label for="yetkili">Firma Yetkilisi:</label>
			<input name="yetkili" id="yetkili"   value="<?php echo $firma['yetkili']; ?>" maxlength="200" />
				</p>
                
                <p>
			<label for="email">Email:</label>
			<input name="email" id="email" value="<?php echo $firma['email']; ?>"  />
		</p>
        
                
                <?php if($firma['uyeliktur']>1) { ?>
                								<p>
			<label for="detay">Detay:</label>
			
            <textarea id="noise" name="detay"  ><?php echo stripslashes($firma['detay']); ?></textarea>
<script type="text/javascript" src="js/ckayar.js"></script>
            
								</p>
        <?php }?>
                                
                                
                <p>
			<label for="etiket">Anahtar Kelimeler:</label>
			<input name="etiket" id="etiket"  value="<?php echo $firma['etiket']; ?>" /><br>Her kelime arasina virgül koyunuz.
				</p>
	
		<p>
	       <label for="fsektor">Sektör Seçiniz:</label>
			                    
                       <select   name="fsektor[]" id="s8"  multiple="multiple"  />
				    
                    <?php

													   
						    $sql="SELECT ust_adi,ust_id from ustkat order by ust_adi asc;";
						    $sorgu=mysql_query($sql);
						    while($sektorler=mysql_fetch_assoc($sorgu))
							{								
$seksorgu=mysql_query("SELECT sektor.s_ustid from sektor  where sektor.s_fid='$sid'") or die(mysql_error());?>
                    <option  value="<?php echo $sektorler['ust_id']; ?>" <?php while($sektorfid=mysql_fetch_assoc($seksorgu)) { if($sektorler['ust_id']==$sektorfid['s_ustid']) { echo "selected='selected'"; }} ?> ><?php echo $sektorler['ust_adi']; ?></option>
                    <?php } // firmaya ait sekt&ouml;r listesinin kapanisi?>
                                        </select>
                           				   
		*</p>
		
		
						
							
	
								<p>
			<label for="adres">Adres:</label>
			<textarea  name="adres" id="adres"  ><?php echo $firma['adres']; ?></textarea>
								</p>
		<p>
			<label for="tel">İş Telefonu:</label>
			<input name="tel" id="telmask" value="<?php echo $firma['tel']; ?>"  /><br />
            (212) XXX-XXXX
		</p>
		
			<p>
			<label for="cep">Cep Telefonu:</label>
			<input name="cep" id="cepmask" value="<?php echo $firma['cep']; ?>" />
            <br />
            (532) XXX-XXXX
		</p>
		
				<p>
			<label for="fax">Faks:</label>
			<input name="fax" id="faxmask"  value="<?php echo $firma['fax']; ?>"  />
            <br />
            (212) XXX-XXXX
		</p>
        
        <?php if($firma['uyeliktur']>1) { ?>
        				<p>
			<label for="web">Web:</label>http://
			<input name="web" id="web" value="<?php echo $firma['web']; ?>" maxlength="100" />
		</p>
        
        				
        
               				<p>
			<label for="face">Facebook:</label>http://
			<input name="face" id="face" value="<?php echo $firma['face']; ?>" maxlength="200" />
		</p>
        
        <?php }?>
        
        				<p>
                        
             
         <label for="logo">Logo:</label>
          <?php if ($firma['logo']=="") { ?> 
                          <input type="file"  name="f_logo" value="" />
                           <input type="hidden" name="actionlogo" value="logo" /><br>
                           Max 200 kb, (jpg, gif ya da png formatında)
                          <?php } else { ?>
                                                   
                          <img src="../uploads/logo/<?php echo $firma['logo'];?>" height="100" border="0">
                           <a href="logo-sil.html" style="margin:5px" class="ask">
                           <img src="images/delete.png" alt="Sil" /></a>
                           <?php }?>
                                            
   <?php if($firma['uyeliktur']>1) { ?>
   				<p>
			<label for="video">Video Embed Kod:  </label>          
          
			<textarea name="video" id="video" ><?php echo $firma['video']; ?></textarea>
                      
		</p>
        
         <?php if($firma['video']!=""){echo $firma['video'];}?>
        
  
     
  
	  			<?php 
					$sql="SELECT firmaresim,id from firmaresim where fid='$sid' and onay=1 limit 0,10 ";
					$sorgu=mysql_query($sql) or die(mysql_error());
					$say=mysql_num_rows($sorgu);
					$i=1;
					while ($row=mysql_fetch_array($sorgu))
					{
					?>
					
							        <p>
                    <label for="f_resim">Fotoğraf-<? echo $i;?>:</label>
                    <img src="../uploads/firmaresim/<?php echo $row['firmaresim'];?>" width="80" height="50" border="0">
                    <a href="firmaresim-sil_<?php echo $row['id']; ?>.html" class="ask">
                    <img src="images/delete.png" style="margin:5px" alt="Sil" /></a>
                     </p>
                    				
					<?
					$i++;
					}
					?>
					
					<?php
					$say++;
					for($say;$say<=10;$say++)
					{
					?>
                    <p><label for="f_<?php echo $say;?>">Fotoğraf-<?php echo $say;?>:</label>
                    	<input type="file" name="userfile<?php echo $say;?>">
                                        
                    </p>
                    			
					<?
					}
					
					?>
                    
                    
                    
        <?php //include("gmap.php"); ?> 
   
   
   <?php }?>
   <p><label></label><img src="securimage/securimage_show.php?sid=<?php echo md5(uniqid(time())); ?>"></p>
        <p><label for="gkod">Güvenlik Kodu:</label><input type="text" name="gkod" id="gkod" maxlength="5" size="30"></p>
   
   
           		  <p>
                    <input type="hidden" name="uyeliktur" value="<?php echo $firma['uyeliktur']; ?>"/>
         			<input class="submit" type="submit" value="Firmamı Düzenle!"/>
		</p>
	</fieldset>
</form>
                        </div>
                    
           <?php } else { 
			echo "<script>window.top.location.href = 'index.html';</script>";
			}?>				
            
