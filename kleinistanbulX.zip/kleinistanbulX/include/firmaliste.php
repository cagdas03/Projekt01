     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
    
    
    
<div class="orta_modul">
<div id="uclu">
<p><b class="red">FİRMA LİSTESİ</b><a style="float:right" title="Liste Şeklinde Alt Alta Görüntüle" href="index.php?tur=firma&pg=ara"><img src="images/liste.png" /></a></p>
</div>
</div>


<div class="orta_modul">
<div id="ucluliste">
<?php
 
 require_once 'lib/sayfalama.class.php';
 $db_count=mysql_num_rows(mysql_query("SELECT id FROM 	firma where onay=1"));
 
 $pages = new Paginator;
 $pages->items_total = $db_count;
 $pages->mid_range = 3;
  $pages->default_ipp = $rowtt['liste_sayisi'];
 $pages->paginate();
 
 $sql=mysql_query("SELECT id, adi, logo, uyeliktur FROM firma where onay=1 order by uyeliktur desc, bastarih desc $pages->limit");
 while($sorgu=mysql_fetch_assoc($sql))
 {?>


<div id="listekutu">
<p>

<a href="firmalar/<?php echo seo($sorgu['adi']); ?>_<?php echo $sorgu['id']; ?>.html" title="<?php echo $sorgu['adi']; ?>" />
<img src="images/paket<?php echo $sorgu['uyeliktur'];?>.png" />

    <?php if(empty($sorgu['logo'])) {
		echo "<img src='images/logoyok_liste.png' width='136' />";
	} else {
		 ?>
    <img src="uploads/logo/<?php echo $sorgu['logo']; ?>" width="136" height="94"  />
    <?php } ?>
   
    
<?php echo mb_substr( $sorgu['adi'],0,30,'UTF-8'); ?></a>





</p>
</div>

<?php
}

?>
</div>			
</div>
<?php
echo "<div class='sayfalama_kutu'>";
echo $pages->display_pages();
echo "</div>";
?>