<html>
<head>
<title>PHPMailer - SMTP (Gmail) basic test</title>
</head>
<body>

<?php

//error_reporting(E_ALL);
error_reporting(E_STRICT);

date_default_timezone_set('Europe/Istanbul');

require_once('lib/phpmailer/class.phpmailer.php');
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail             = new PHPMailer();

$body             = file_get_contents('contents.php');
$body             = eregi_replace("[\]",'',$body);

$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "mail.yourdomain.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
$mail->CharSet = 'UTF-8';
$mail->SetLanguage("tr", "lib/phpmailer/language"); //default olarak  "en" dir. Biz türkçe kullanacağız dedik 
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
$mail->Port       = 465;                   // set the SMTP port for the GMAIL server
$mail->Username   = "tanermacit@gmail.com";  // GMAIL username
$mail->Password   = "Şifreniz";            // GMAIL password

$mail->SetFrom('tanermacit@gmail.com', 'Taner Macit');

$mail->AddReplyTo("tanermacit@gmail.com","Taner Macit");

$mail->Subject    = "Doğu Karadeniz Firma Rehberinden EMail Aldınız";

$mail->AltBody    = "Test emailidir."; // optional, comment out and test

$mail->MsgHTML($body);

$address = "tanermacit@gmail.com";
$mail->AddAddress($address, "Taner Macit");

$mail->AddAttachment("images/sifre-unut.jpg");      // attachment
//$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
