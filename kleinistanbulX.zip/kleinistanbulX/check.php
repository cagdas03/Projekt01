<?php

// This is a sample code in case you wish to check the username from a mysql db table

if(isSet($_POST['username2']))
{
$username2 = $_POST['username2'];

include("include/ayar.inc.php");

$sql_check = mysql_query("SELECT id FROM firma WHERE username='$username2'");

if(mysql_num_rows($sql_check))
{
echo '<font color="red"><STRONG>'.$username2.'</STRONG> adlı kullanıcı adı daha önce alınmıştır.</font>';
}
else
{
echo '<font color="#009900""><STRONG>'.$username2.'</STRONG> adlı kullanıcı adı müsaittir.</font>';
}

}

?>