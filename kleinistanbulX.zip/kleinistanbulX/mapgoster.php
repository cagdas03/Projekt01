   

  
  <script type="text/javascript">
  function initialize() {
    var myLatlng = new google.maps.LatLng(<?php echo $firma['koordinat']; ?>);
    var myOptions = {
      zoom: <?php echo $firma['zoom']; ?>,
      center: myLatlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    
    var marker = new google.maps.Marker({
        position: myLatlng, 
        map: map,
        title:"<?php echo $firma['adi']; ?>!"
    }); 
	
    var infowindow = new google.maps.InfoWindow(); 
	infowindow.close() 
    infowindow.setContent("<div class='maphtml'><b><?php echo $firma['adi']; ?></b><br/><br/><?php echo $firma['adres']; ?><br/><?php echo $firma['ilce_adi']; ?>/<?php echo $firma['ad']; ?></div>"); 
    infowindow.open(map, marker);  

	
	
	  
  }
</script>

<body onload="initialize()">
  <div id="map_canvas" style="width: 730px; height: 500px; float:left"></div>
 </body>


