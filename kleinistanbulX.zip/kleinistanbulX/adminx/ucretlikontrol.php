﻿<?php
include("../include/ayar.inc.php");

$sql = "SELECT firma.id, firma.adi,firma.bastarih,firma.gumus_bas, firma.gumus_bit, firma.altin_bas, firma.altin_bit , firma.normal_bas, firma.normal_bit, firma.uyeliktur,firma.yetkili,firma.onay, firma.email, uyeliktur.tip_adi FROM firma inner join sehir on sehir.id=firma.sehir  inner join sektor on sektor.s_fid=firma.id inner join uyeliktur on uyeliktur.id=firma.uyeliktur where  firma.uyeliktur>0 group by firma.id ";
$result = mysql_query($sql) or die(mysql_error());
while($ucretli=mysql_fetch_assoc($result))
{

//Bugünün saniyesini alalım
$bugun=time();



if($ucretli['uyeliktur']==2)
{ // gümüş ise başlama

$gumusgun=intval( ($ucretli['gumus_bit']-$bugun)/86400  );

 if ($gumusgun>0 && $gumusgun<8) // 1,2,3,4,5,6,7,
		    { $ickonu=" ".$ucretli['tip_adi']. " üyeliğinizin süresinin dolmasına ".$gumusgun."  gün kalmıştır.";
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$gumusgun."</b> gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>"; 
$kime=$ucretli['email'];  

include("../include/mail_ayar.php");
			}
			
						elseif( $gumusgun==15) // 8,9,10,11........,30
			{$ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresinin dolmasına ".$gumusgun." gün kalmıştır.";
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$gumusgun."</b>  gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız ,Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>";  
$kime=$ucretli['email']; 
include("../include/mail_ayar.php");
			}
			
			
			elseif( $gumusgun==30) // 8,9,10,11........,30
			{$ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresinin dolmasına ".$gumusgun." gün kalmıştır.";
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$gumusgun."</b>  gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız ,Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>";  
$kime=$ucretli['email']; 
include("../include/mail_ayar.php");
			}
			
			elseif ($gumusgun<1  && $gumusgun>-6 ) // -1, -2, -3, -4, -5,
			{$ickonu=" ".$ucretli['tip_adi']. " üyeliğinizin süresi ".($gumusgun*-1)." gün önce dolmuştur. ";
$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin süresi <b>".($gumusgun*-1)."</b> gün önce dolmuştur. Firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçmiştir. Ödeme yapmak ve tekrar ".$ucretli['tip_adi']." üyeliğe geçmek istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>";
$kime=$ucretli['email'];   
include("../include/mail_ayar.php");			
			
			}
			
			else {}	


} // gümüş bitiş

elseif($ucretli['uyeliktur']==3)
{ // altın ise başlama

$altingun=intval( ($ucretli['altin_bit']-$bugun)/86400);

if ($altingun>0 && $altingun<8) // 1,2,3,4,5,6,7,
		    { $ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresinin dolmasına ".$altingun."  gün kalmıştır.";
			
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$altingun."</b>  gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>"; 
$kime=$ucretli['email']; 
include("../include/mail_ayar.php");
			}
			
			
			elseif( $altingun==15 ) // 8,9,10,11........,30
			{$ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresinin dolmasına ".$altingun."  gün kalmıştır.";
			
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$altingun."</b>  gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>"; 
$kime=$ucretli['email'];  
include("../include/mail_ayar.php");
			}
			
			
			elseif( $altingun==30 ) // 8,9,10,11........,30
			{$ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresinin dolmasına ".$altingun."  gün kalmıştır.";
			
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin dolmasına <b>".$altingun."</b>  gün kalmıştır. Üyeliğinizin süresi dolunca firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçecektir. Ödeme yapmak ve üyeliğinizin süresini uzatmak istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>";  
$kime=$ucretli['email']; 
include("../include/mail_ayar.php");
			}
			
			elseif ($altingun<1  && $altingun>-6 ) //-1, -2, -3, -4, -5,
			{$ickonu=" ".$ucretli['tip_adi']. " Üyeliğinizin süresi ".($altingun*-1)." gün önce dolmuştur.";
			$konu=$rowtt['site_adi']." | ".$ickonu ;	
$mesaj ="Merhaba ".$ucretli['yetkili']."
<p>
".$rowtt['site_adi']." rehberimizde bulunan <b>".$ucretli['adi']."</b> adlı firmanıza ait ".$ucretli['tip_adi']." üyeliğinizin süresi <b>".($altingun*-1)."</b> gün önce dolmuştur. Firmanız otomatik olarak Standart (Ücretsiz) üye durumuna geçmiştir. Ödeme yapmak ve tekrar ".$ucretli['tip_adi']." üyeliğe geçmek istiyorsanız, Lütfen <a href='".$rowtt['site_url']."/iletisim.html' target='_blank' >tıklayınız.</A> 

</p>";  
$kime=$ucretli['email']; 
include("../include/mail_ayar.php");
			}
			
			

} // altın ise bitiş

else
{
	
}




	
} // while bitiş


?>