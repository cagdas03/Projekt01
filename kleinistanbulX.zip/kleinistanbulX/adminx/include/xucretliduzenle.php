<link rel="stylesheet" href="css/jquery.ui.all.css">
	<script src="js/jquery.ui.core.js"></script>
	<script src="js/jquery.ui.datepicker.js"></script>
	<script src="js/jquery.ui.datepicker-tr.js"></script>
<script>
	$(function() {
		$( "#datepicker" ).datepicker();
	$.datepicker.regional['tr'];
	}
	
	);
	
	</script>
	<script>
	$(function() {
		$( "#datepicker2" ).datepicker();
	$.datepicker.regional['tr'];
	}
	
	);
	
	</script>
  	<script language="JavaScript">
function check_reklamekle(){
	
	
		  if (document.kekleform.bas.value == ""){
		alert ("Başlama tarihi seçiniz.");
		document.kekleform.bas.focus();
		return false;  
	}
	
	

	
		  if (document.kekleform.bit.value == ""){
		alert ("Bitiş tarihi seçiniz..");
		document.kekleform.bit.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">


<?php 
$id=intval($_GET['fid']);
$paket=intval($_GET['paket']);
$sorgu=mysql_query("SELECT firma.adi, firma.gumus_bas, firma.gumus_bit, firma.altin_bas, firma.normal_bas, firma.normal_bit, firma.altin_bit, uyeliktur.tip_adi from firma inner join uyeliktur on uyeliktur.id=firma.uyeliktur where firma.id='$id' and firma.uyeliktur='$paket' limit 0,1 ");
while($reklam=mysql_fetch_assoc($sorgu))
{
?>
<form method="post" action="index2.php?pg=ucretli&islem=ucretliduzenle&fid=<?php echo $id; ?>&paket=<?php echo $paket; ?>"  enctype="multipart/form-data" onSubmit="return check_reklamekle()" id="kekleform" name="kekleform" >
          
                            
                            <h2><?php echo $reklam['adi']; ?> / (<?php echo $reklam['tip_adi']; ?>) üyelik tarihi ayarları</h2>         
                      
                        <dl>
        				<dt><label for="bas<?php echo $paket; ?>">Üyelik Başlama Tarihi:</label></dt>
                        <dd> <input type="text" name="bas<?php echo $paket; ?>"
                        value="<?php if($paket==2) { echo tt_tarih($reklam['gumus_bas']) ; } elseif ($paket==3) {echo tt_tarih($reklam['altin_bas']) ;} elseif ($paket==1) {echo tt_tarih($reklam['normal_bas']) ;} ?>" id="datepicker" /> 
                        </dd>
                        </dl>
                        
                        
                        <dl>
        				<dt><label for="bit<?php echo $paket; ?>">Üyelik Bitiş Tarihi:</label></dt>
                        <dd> <input type="text" name="bit<?php echo $paket; ?>" id="datepicker2"
                         value="<?php if($paket==2) { echo tt_tarih($reklam['gumus_bit']) ; } elseif ($paket==3) {echo tt_tarih($reklam['altin_bit']) ;} elseif ($paket==1) {echo tt_tarih($reklam['normal_bit']) ;}?>" />
                        </dd>
                        </dl>
                     

<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Üyeliği Düzenle" />
</form>
<?php } ?>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	
	$paket=intval($_GET['paket']);
	$id=intval($_GET['fid']);
	
	if($paket==2)
	
	{
		
	list($day, $month, $year) = explode('.', $_POST['bas2']);
	$bas2 = mktime(0, 0, 0, $month, $day, $year);
	
	list($day, $month, $year) = explode('.', $_POST['bit2']);
	$bit2 = mktime(0, 0, 0, $month, $day, $year);
	
	// ekleme yapılıyor
	$reklamekle=mysql_query("UPDATE firma SET   gumus_bas='$bas2', gumus_bit='$bit2' where id='$id' ") or die(mysql_error());
	if($reklamekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ucretli&paket=$paket'> ";
	
	}
	
	elseif($paket==3)
	{
	
	list($day, $month, $year) = explode('.', $_POST['bas3']);
	$bas3 = mktime(0, 0, 0, $month, $day, $year);
	
	list($day, $month, $year) = explode('.', $_POST['bit3']);
	$bit3 = mktime(0, 0, 0, $month, $day, $year);
	
		// ekleme yapılıyor
	$reklamekle=mysql_query("UPDATE firma SET   altin_bas='$bas3', altin_bit='$bit3' where id='$id' ") or die(mysql_error());
	if($reklamekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ucretli&paket=$paket'> ";
	
	}
	
	
		elseif($paket==1)
	{
	
	list($day, $month, $year) = explode('.', $_POST['bas1']);
	$bas1 = mktime(0, 0, 0, $month, $day, $year);
	
	list($day, $month, $year) = explode('.', $_POST['bit1']);
	$bit1 = mktime(0, 0, 0, $month, $day, $year);
	
		// ekleme yapılıyor
	$reklamekle=mysql_query("UPDATE firma SET   normal_bas='$bas1', normal_bit='$bit1' where id='$id' ") or die(mysql_error());
	if($reklamekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ucretli&paket=$paket'> ";
	
	}
			
	
		
			  
		
	
   
    }// submite basılmışsa


	 ?>


      
      
     