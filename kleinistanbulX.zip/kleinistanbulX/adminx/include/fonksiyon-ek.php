     <?php if(!defined("TT_YAZILIM")){ 
   echo "<script>window.top.location.href = '../index.html';</script>";
   exit();
    } ?>
          
<?php

function postala($gidecekMail,$gonderenAd,$gonderenMail,$konu,$mesaj) {
$headers = "MIME-Version: 1.0\n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
$headers .= "From:<$gonderenMail>\n";
$headers .= "Reply-To: $gonderenAd<$gonderenMail>\n";
$headers .= "Return-Path: $gonderenAd<$gonderenMail>\n";
@mail($gidecekMail,$konu,$mesaj,$headers);
}



function seo($url) 
{
	     $url = trim($url);     
		 $find = array('<b>', '</b>');     
		
		 $url = str_replace ($find, '', $url);     
		 $url = preg_replace('/<(\/{0,1})img(.*?)(\/{0,1})\>/', 'image', $url);     
		 
		 $find = array(' ', '&quot;', '&amp;', '&', '\r\n', '\n', '/', '\\', '+', '<', '>');     
		 $url = str_replace ($find, '-', $url);     
		 
		 $find = array('€', '£', '@');     
		 $url = str_replace ($find, 'e', $url);     
		
		 $find = array('İ',  'ı' );     
		 $url = str_replace ($find, 'i', $url);     
		 
		 $find = array('Ö', 'ö' );     
		 $url = str_replace ($find, 'o', $url);  
		    
		 $find = array('A','a');     
		 $url = str_replace ($find, 'a', $url);     
		 $find = array('Ü', 'ü');     
		 $url = str_replace ($find, 'u', $url);     
		 $find = array('Ç', 'ç');     
		 $url = str_replace ($find, 'c', $url);     
		 $find = array('ş', 'Ş' ,'$');     
		 $url = str_replace ($find, 's', $url);     
		 $find = array('Ğ', 'ğ');     
		 $url = str_replace ($find, 'g', $url);     
		 $find = array('/[^A-Za-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');     
		 $repl = array('', '-', '');     
		 $url = preg_replace ($find, $repl, $url);    
		 $url = str_replace ('--', '-', $url);     
		 $url = strtolower($url);     
		  return $url; } 
 
 





		//veri temizleme
 function temizle ($veri) {
  

 $veri=str_replace("&","",$veri);
 $veri=str_replace("=","",$veri);
 $veri=str_replace("'"," ",$veri);
 $veri=str_replace("<","",$veri);
 $veri=str_replace(">","",$veri);
 $veri=str_replace("$","Dolar",$veri);
 $veri=str_replace("!","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
 $veri=trim(strip_tags($veri));
 $veri=mysql_real_escape_string($veri);
return $veri;         
} 


 function temizle_adres($veri) {
  

 $veri=str_replace("&","",$veri);
 $veri=str_replace("=","",$veri);
 $veri=str_replace("'"," ",$veri);
 $veri=str_replace("<","",$veri);
 $veri=str_replace(","," ",$veri);
 $veri=str_replace(">","",$veri);
 $veri=str_replace("$","Dolar",$veri);
 $veri=str_replace("!","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
 $veri=trim(strip_tags($veri));
 $veri=mysql_real_escape_string($veri);
return $veri;         
} 

 function area ($veri) {

 $veri=str_replace("'"," ",$veri);
  $veri=str_replace("\""," ",$veri);
 $veri=str_replace("\\","",$veri);
 $veri=str_replace("*","",$veri);
 $veri=str_replace("#","",$veri);
 $veri=str_replace("&amp;","",$veri);
 $veri=str_replace("&lt;","",$veri);
 $veri=str_replace("&gt;","",$veri);
 $veri=str_replace("&quot;","",$veri);
return $veri;         
} 


function tt_tarih($tarih)
{
date_default_timezone_set('Europe/Istanbul');  
setlocale(LC_ALL, 'turkish'); 
echo strftime("%d/%m/%Y", $tarih);
}


?>




<?php
function para($rakam) {
    $rakam = sprintf('%.2f', $rakam);
    $rakam = str_replace(".",",",$rakam);
    while (true) {
        $temp = preg_replace('/(-?d+)(ddd)/', '$1.$2', $rakam);
        if ($temp != $rakam) {
            $rakam = $temp;
        } else {
            break;
        }
    }
    return $rakam;
}



?>


