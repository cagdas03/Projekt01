     <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>


	<script language="JavaScript">
function check_sanekle(){
	
	

	
			if (document.sekleform.firma.value == ""){
		alert ("Lütfen bir firma seçiniz yazınız.");
		document.sekleform.firma.focus();
		return false;  
	}
	
	
					if (document.sekleform.tip.value == ""){
		alert ("Lütfen bir ilan tipi seçiniz.");
		document.sekleform.tip.focus();
		return false;  
	}
	
	
	
				if (document.sekleform.baslik.value == ""){
		alert ("Lütfen başlık yazınız.");
		document.sekleform.baslik.focus();
		return false;  
	}
	
	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=ilanekle"  enctype="multipart/form-data" onSubmit="return check_sanekle()" id="sekleform" name="sekleform" >

<fieldset>
     <h2>Yeni İlan Ekle (İlan Limiti:<?PHP echo $iu_limit; ?>)</h2>
     
             <dl>
                        <dt><label for="firma">Firma Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="firma"  onchange="this.form.submit();">
						    <option value="" >Firma Seç</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 and firma.onay=1 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_POST['firma']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
              
              
              
              <dl>
                        <dt><label for="tip">İlan Tipi:</label></dt>
                        <dd> 
                        <select style="width:305px" name="tip"  >
						    <option value="" >İlan Tipi Seçiniz</option> <?php
						    $sql="SELECT id, itip_adi from ilantip  order by id asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_POST['tip']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['itip_adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
     
     
               <dl>
        				<dt><label for="baslik">İlan Başlığı</label></dt>
                        <dd> <input type="text" class="text"   name="baslik" />  </dd>
                       
              </dl>
     
     
                
               
        				<label for="detay">İlan Detayı</label>
                        <textarea id="noise" name="detay"></textarea> 
                        
                         <script type="text/javascript" src="../js/ckayar.js"></script>
                       
            
              
               
               
             <dl>
                        <dt><label for="etiket">Etiketler:</label></dt>
                        <dd><input type="text" class="text" name="etiket" /></dd>
                    </dl>
      
      
                                
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionilan" value="ilan" />
<input type="submit" class="google" name="duzenle"  value="İlan Ekle" />

</fieldset>
</form>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	$firma=$_POST['firma'];
		
		 
	$pano=mysql_query("SELECT id FROM ilan where fid='$firma'");
	$saypano=mysql_num_rows($pano);
	if($saypano>($iu_limit-1)) { 
	echo "<script>alert('En fazla $iu_limit adet ilan ekleyebilirsiniz. Limit dolmuş görünüyor. Limiti genel ayarlardan artırabilirsiniz');</script>";
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilanekle'> ";
	exit();
	 }
	else {	
	
	
	include("include/upload.php");
	$baslik=$_POST['baslik'];
	$detay=addslashes($_POST['detay']);
	$etiket=$_POST['etiket'];
	$tip=$_POST['tip'];
	$time=time();
	// ekleme yapılıyor
	$ilanekle=mysql_query("INSERT INTO ilan (id, fid,ilan_baslik, ilan_detay, ilan_etiket, onay, ilan_bas_tarih, tip) VALUES ('', '$firma', '$baslik', '$detay', '$etiket'  ,'1','$time', '$tip' )") or die(mysql_error());
	if($ilanekle) { echo "<div class='valid_box'>İlan  eklendi.</div>";} else {echo "İlan eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilan'> ";
	
	
	
	} // ilan tur eklenememiş
   
    }// submite basulmışsa
	 
}
	 ?>


      
      
     