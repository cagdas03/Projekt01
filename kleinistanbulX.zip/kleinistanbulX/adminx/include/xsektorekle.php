    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.ust_adi.value == ""){
		alert ("Lütfen sektör adınız yazınız.");
		document.ekleform.ust_adi.focus();
		return false;  
	}
	
				if (document.ekleform.etiket.value == ""){
		alert ("Lütfen sektör etiketi yazınız.");
		document.ekleform.etiket.focus();
		return false;  
	}
	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=sektor&islem=ekle" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2>Yeni Sektör Ekle</h2>
     <dl>
                        <dt><label for="ust_adi">Sektör Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="ust_adi" /></dd>
                                             </dl>
                                             
                                                <dl>
                        <dt><label for="etiket">Etiket</label></dt>
                        <dd><input type="text" value="" class="text" name="etiket" /></dd>
                                             </dl>
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Sektör Ekle" />
</form>
</div>

<?php if(!empty($_POST['hiddenekle'])) {
	$ust_adi=$_POST['ust_adi'];
	$etiket=$_POST['etiket'];
		
	$sektorekle=mysql_query("INSERT INTO ustkat (ust_adi, etiket) VALUES ('$ust_adi', '$etiket')") or die(mysql_error());
	if($sektorekle) { echo "<div class='valid_box'>Sektör eklendi.</div>";} else {echo "Sektör eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='2;URL=index2.php?pg=sektor'> ";
	
	 }?>


      
      
     