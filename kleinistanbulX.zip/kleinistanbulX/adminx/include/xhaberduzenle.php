     <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>


	<script language="JavaScript">
function check_sanekle(){
	
			if (document.sekleform.firma.value == ""){
		alert ("Lütfen bir firma seçiniz yazınız.");
		document.sekleform.firma.focus();
		return false;  
	}
	
				if (document.sekleform.baslik.value == ""){
		alert ("Lütfen başlık yazınız.");
		document.sekleform.baslik.focus();
		return false;  
	}
	
	
	
	
	 }

</script>
<div class="form">

<?php
$id=$_GET['sid'];
$sorgu=mysql_query("SELECT haber.haber_baslik, haber.haber_detay, haber.haber_etiket, firma.adi, haber.fid, haber.haberresim from haber inner join firma on firma.id=haber.fid where haber.id='$id'");
while($haber=mysql_fetch_assoc($sorgu))
{
 ?>

<form method="post" action="index2.php?pg=haberduzenle&sid=<?php echo $id; ?>"  enctype="multipart/form-data" onSubmit="return check_sanekle()" id="sekleform" name="sekleform" >

<fieldset>
     <h2><?php echo $haber['haber_baslik']; ?> / <?php  echo $haber['adi']; ?></h2>
     
             <dl>
                        <dt><label for="firma">Firma Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="firma" >
						    <option value="" >Firma Seç</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($haber['fid']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
     
     
               <dl>
        				<dt><label for="baslik">Haber Başlığı</label></dt>
                        <dd> <input type="text" class="text"  value="<?php echo $haber['haber_baslik']; ?>"  name="baslik" />  </dd>
                       
              </dl>
     
     
                
               
        				<label for="detay">Haber Detayı</label>
                        <textarea id="noise" name="detay" ><?php echo stripslashes($haber['haber_detay']); ?></textarea> 
                         <script type="text/javascript" src="../js/ckayar.js"></script>
                       
            
              
                
              
               
             <dl>
                        <dt><label for="etiket">Etiketler:</label></dt>
                        <dd><input type="text" class="text" value="<?php echo $haber['haber_etiket']; ?>" name="etiket" /></dd>
                    </dl>
      
      
              <dl><dt><label>Resim:</label></dt>
              <dd   style="height:50px;">
			 <?php if(!empty($haber['haberresim'])) {?>   <img src="../uploads/haber/<?php echo $haber['haberresim'];?>" width="80" height="50" border="0"><a href="index2.php?pg=haberduzenle&islem=resimsil&rid=<?php echo $id; ?>" style="margin:5px" class="ask"><img src="images/delete.png" alt="Sil" /></a></dd>  <?php } else {?>
                           <input type="file"  name="f_haber" value="" /> </dd>
                       <?php }?>
                      </dl>
                      
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionhaber" value="haber" />
<input type="submit" class="google" name="duzenle"  value="Haberi Düzenle" />

</fieldset>
</form>
<?php }?>
</div>

			   
<?php

if($_GET['islem']=="resimsil")
{  

$rid=$_GET['rid'];
$resimyol=mysql_fetch_row(mysql_query("SELECT haberresim from haber where id='$rid' limit 0,1"));
$ryol=$resimyol['0'];
@unlink("../uploads/haber/$ryol");
$resimsil=mysql_query("UPDATE haber SET haberresim=''  where id='$rid'");
   echo "<div class='valid_box'>Resim Silindi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=haberduzenle&sid=$rid'> ";
 break;

}





 if(!empty($_POST['duzenle'])) {
	
	$firma=$_POST['firma'];
	include("include/upload.php");
	$baslik=$_POST['baslik'];
	$detay=addslashes($_POST['detay']);
	$etiket=$_POST['etiket'];
		// ekleme yapılıyor
	
	 $sorgu=mysql_query("SELECT haberresim from haber where id='$id' limit 0,1");
			  $sec=mysql_fetch_row($sorgu);
			  if($_FILES['f_haber']['name']==''){ $f_haber=$sec['0'];} else { $f_haber=$haberismi;}
				
				
	$haberekle=mysql_query("UPDATE  haber  SET fid='$firma' ,haber_baslik='$baslik', haber_detay='$detay', haber_etiket='$etiket', haberresim='$f_haber' where id='$id' ") or die(mysql_error());
	if($haberekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haberduzenle&sid=$id'> ";
	
	
	
	} // haber tur eklenememiş
   
    }// submite basulmışsa
	 
	 ?>


      
      
     