<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT ust_adi, etiket from ustkat where ust_id='$sid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>

<div class="form">

<form method="post" action="index2.php?pg=sektor&islem=sektorduzenle&sid=<?php echo $sid;?>" onSubmit="return check_fekle()" id="sabitform" name="sabitform" >
     <h2>Sektör Düzenle</h2>
     <dl>
                        <dt><label for="ust_adi">Sektör Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['ust_adi']; ?>" class="text" name="ust_adi" /></dd>
                                            </dl>
                                            
                                            
                                                                         <dl>
                        <dt><label for="etiket">Etiket</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['etiket']; ?>" class="text" name="etiket" /></dd>
                                             </dl>
                                             
                                             
                                            
                                                
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle"  value="gönder" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$sid=$_GET['sid'];
		$ust_adi=$_POST['ust_adi'];
		$etiket=$_POST['etiket'];
	
	$sektorupdate=mysql_query("UPDATE ustkat SET  ust_adi='$ust_adi', etiket='$etiket' where ust_id='$sid'");
	if($sektorupdate) { echo "<div class='valid_box'>Sektör düzenledi.</div>";} else {echo "Sektör düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sektor'> ";
	
	 }?>


      
      
     