
<body>
<div class="form">



<form id="form1" method="post"   onSubmit="return check_aekle()"  name="eklesube">

    <dl>
     <dt><label for="email">Tüm E-mailler</label></dt>
     <textarea name="email" style="width:700px; height:500px"   class="area">
     			   
<?php 	
$sql="SELECT email from firma where onay=1 and email!='' and id>0 ";
$sorgu=mysql_query($sql);
while($emailcek=mysql_fetch_row($sorgu))
{
echo $emailcek['0'];
echo ",";

}

?> 
     </textarea>
     
     </dl> 
      
<input type="hidden" name="hiddenekle" value="ok" />
</form>
</div>
   






      
      
     