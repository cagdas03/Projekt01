 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
 	
    
    <script language="JavaScript">
function check_fekle(){
	
			if (document.sabitform.sabit_baslik.value == ""){
		alert ("Lütfen sayfa başlığını (adını) yazınız.");
		document.sabitform.sabit_baslik.focus();
		return false;  
	}
	
				if (document.sabitform.menu.value == ""){
		alert ("Lütfen bir menü seçiniz.");
		document.sabitform.menu.focus();
		return false;  
	}


	
	 }

</script>
  
    
    <?php
	
	
	//Kelime araması yapıldıysa aratılan kelime ile ilgilii sonuçları çıkaralım.
	

	
	// include your code to connect to DB.

	$tbl_name="sayfa";		//your table name
	// How many adjacent pages should be shown on each side?
	$adjacents = 20;
	
	/* 
	   First get total number of rows in data table. 
	   If you have a WHERE clause in your query, make sure you mirror it here.
	*/
	$query = "SELECT COUNT(*) as num FROM $tbl_name";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	
	/* Setup vars for query. */
	$targetpage = "index2.php?pg=sabitliste"; 	//your file name  (the name of this file)
	$limit = 20; 								//how many items to show per page
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	$sql = "SELECT sayfa.id, sayfa.adi , sayfa.detay, menu.madi, sayfa.sira, sayfa.url, sayfa.onay from sayfa inner join menu on menu.mpg=sayfa.pg order by sayfa.pg asc LIMIT $start, $limit";
	$result = mysql_query($sql);
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\">« Geri</a>";
		else
			$pagination.= "<span class=\"disabled\">« Geri</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage&page=$next\">İleri »</a>";
		else
			$pagination.= "<span class=\"disabled\">İleri »</span>";
		$pagination.= "</div>\n";		
	}
?>
<a href="index2.php?pg=sabitliste&islem=ekle" class="bt_green"><span class="bt_green_lft"></span><strong>Yeni Sayfa Ekle</strong><span class="bt_green_r"></span></a>
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr >
        	<th scope="col" class="rounded-company">Sıra</th>
            <th scope="col" class="rounded">Sayfa Başlık</th>
            <th scope="col" class="rounded">Menü</th>
            <th scope="col" class="rounded" width="25">Onay</th>
            <th scope="col" class="rounded" width="25">Düzen</th>
            <th scope="col" class="rounded-q4" width="25">Sil</th>
                    </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="5" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
    <form method="GET" action="index2.php">
	<?php
		while($row = mysql_fetch_assoc($result))
		{
			if ( $row['onay']==1){$onayresim=onay;}else{$onayresim=busy;}
			?>
	    	<tr>
        	<td><?php echo $row['sira'];?></td>
            <td><?php echo $row['adi']; ?></td>
            <td><?php echo $row['madi']; ?></td>
            <td><a href="index2.php?pg=sabitliste&islem=onay&deger=<?php echo $row['onay']; ?>&page=<?php echo $_GET['page']; ?>&sid=<?php echo $row['id']; ?>"> <img src="images/<?php echo $onayresim; ?>.png" alt="Onay" title="" border="0" /></a></td>
           
            
            
             <td><a href="index2.php?pg=sabitliste&islem=sabitduzenle&page=<?php echo $_GET['page']; ?>&sid=<?php echo $row['id']; ?>"><img src="images/user_edit.png" alt="Düzenle" title="" border="0" /></a></td>
             
              <td> <a href="index2.php?pg=sabitliste&islem=sil&page=<?php echo $_GET['page']; ?>&sid=<?php echo $row['id']; ?>" class="ask" ><img src="images/trash.png" alt="Sil" title="" border="0" /> </a></td>
            
        </tr>
            
    
	<?
		}
	?>
   
     <input type="hidden"  name="page" value="<?php echo $_GET['page']; ?>" />
     <input type="hidden"  name="pg" value="sabitliste" />
         
 
     </form>
 </tbody>
</table>
<?=$pagination?>  
 <?php
//İşlemleri aşağıda ypıp uyarı ya da valid değerlerini verelim

//Onaylama İşlemi

$islem=$_GET['islem'];
switch($islem){

case "sabitduzenle":
include("include/xsabitduzenle.php");
break;

case "ekle":
include("include/xsabitekle.php");
break;

case "onay":
$fid=$_GET['sid'];
$deger=$_GET['deger'];
$page=$_GET['page'];

if($deger==1){  $uponay=mysql_query("UPDATE sayfa set onay=0 where id='$fid'");
   echo "<div class='valid_box'>Yayımlanma durduruldu.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=sabitliste&page=$page'> ";  }
elseif($deger==0) {  $uponay=mysql_query("UPDATE sayfa set onay=1 where id='$fid'");
   echo "<div class='valid_box'>Onaylandı.</div>"; 
   echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sabitliste&page=$page'> "; }
else{echo "<div class='error_box'>Bu sayfanın veritabanındaki onay bölümünde tanımlanamayan değerler var.</div>";}
break;


 case "sil":
$sid=$_GET['sid'];
$sil = mysql_query("DELETE FROM sayfa where id='$sid' ");
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sabitliste&page=$page'> ";


default:

}


?>  
<?php } //üye kontrol kapat?>