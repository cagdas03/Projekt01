
<div class="form">

     <h2>Sol Bölüm Modülleri</h2>
     
     <?php

$sorgu=mysql_query("SELECT id,modul_adi,onay,sira from modul where konum='sol' order by sira asc");
while($modul=mysql_fetch_assoc($sorgu)) {
 ?>
<form method="post" action="index2.php?pg=modul&do=modulonay&mid=<?php echo $modul['id'];?>"   >
    <dl>
     <dt><label for="show"><?php echo $modul['modul_adi']; ?></label></dt>
     <dd><select name="show" class="text" >
     <option value="1" <?php if($modul['onay']==1) { echo "selected='selected'";} ?>>Göster</option>
     <option value="0" <?php if($modul['onay']==0) { echo "selected='selected'";} ?>>Gizle</option>
     </select>Sıra:<input type="text" value="<?php echo $modul['sira']; ?>" name="sira"  />
     <input type="submit" value="Kaydet" />
     </dd>
        </dl>
     </form>
     <?php  }?>
     
      
 <h2>Anasayfa Orta Bölüm Modülleri</h2>
 <?php 
 $sorgu=mysql_query("SELECT id,modul_adi,onay,sira from modul where konum='orta' order by sira asc");
while($modul=mysql_fetch_assoc($sorgu)) {
 ?>
 <form method="post" action="index2.php?pg=modul&do=modulonay&mid=<?php echo $modul['id'];?>"   >
    <dl>
     <dt><label for="show"><?php echo $modul['modul_adi']; ?></label></dt>
     <dd><select name="show" class="text" >
     <option value="1" <?php if($modul['onay']==1) { echo "selected='selected'";} ?>>Göster</option>
     <option value="0" <?php if($modul['onay']==0) { echo "selected='selected'";} ?>>Gizle</option>
     </select>Sıra:<input type="text" value="<?php echo $modul['sira']; ?>" name="sira"  />
     <input type="submit" value="Kaydet" />
     </dd>
        </dl>
     </form>
    <?php  }?>
 
</div>

<?php
if($_GET['do']=='modulonay')
{
$mid=intval($_GET['mid']);
$sira=intval($_POST['sira']);
if($_POST['show']==0)
{mysql_query("UPDATE modul set onay=0, sira='$sira' where id='$mid'");}

elseif($_POST['show']==1)
{ mysql_query("UPDATE modul set onay=1, sira='$sira' where id='$mid'");}

else
{}
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=modul'> ";

}
 ?>
    
      
     