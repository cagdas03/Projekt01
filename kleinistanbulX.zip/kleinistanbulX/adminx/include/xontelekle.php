    <script language="JavaScript">
function check_oekle(){
	
			if (document.ontelekle.o_adi.value == ""){
		alert ("Lütfen bir ad yazınız.");
		document.ontelekle.o_adi.focus();
		return false;  
	}
	
	
	
	if (document.ontelekle.o_tel.value == ""){
		alert ("Lütfen Telefon numarasını Yazınız.");
		document.ontelekle.o_tel.focus();
		return false;  
	}
	
	
		if (document.ontelekle.o_sehir.value == ""){
		alert ("Lütfen Bir Şehir Seçiniz.");
		document.ontelekle.o_sehir.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=ontel&islem=ekle" onSubmit="return check_oekle()" id="ontelekle" name="ontelekle" >
     <h2>Yeni Telefon No Ekle</h2>
     <dl>
                        <dt><label for="o_adi">Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="o_adi" /></dd>
                        </dl>
                        <dl>
                           <dt><label for="o_tel">Telefon No:</label></dt>
                        <dd><input type="text" class="text" name="o_tel" /></dd>
                    </dl>
                             <dl>
                           <dt><label for="o_tel">Şehir:</label></dt>
                        <dd>
                        <select name="o_sehir" class="text" >
						    <option value="" >Lütfen Bir Şehir Seçiniz</option> <?php
						    $sql="SELECT sehir_id, sehir_adi from sehir order by sehir_adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['sehir_id']; ?>" <?php if($_POST['f_sehir']==$sehircek['sehir_id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['sehir_adi']; ?></option><?php }?>
                               </select></dd>
                    </dl>
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Telefon Ekle" />
</form>
</div>

<div style="margin-bottom:20px"></div>
<hr />

<?php if(!empty($_POST['hiddenekle'])) {
	$o_adi=$_POST['o_adi'];
	$o_tel=$_POST['o_tel'];
	$o_sehir=$_POST['o_sehir'];
	
	$ontelekle=mysql_query("INSERT INTO ontel (o_adi,o_tel,o_sehir,o_onay) VALUES ('$o_adi','$o_tel','$o_sehir','1')") or die(mysql_error());
	if($ontelekle) { echo "<div class='valid_box'>Telefon eklendi.</div>";} else {echo "Telefon eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ontel&islem=ekle'> ";
	
	 }?>


      
      
     