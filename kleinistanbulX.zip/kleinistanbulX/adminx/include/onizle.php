	<div class="header">
    <div class="right_header">  <a href="index2.php?act=logout" class="logout">Oturumu Kapat</a></div>
     </div>