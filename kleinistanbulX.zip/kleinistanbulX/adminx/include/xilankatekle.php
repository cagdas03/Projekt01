    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.itip_adi.value == ""){
		alert ("Lütfen ad yazınız.");
		document.ekleform.itip_adi.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=ilankat&islem=ekle" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2>Yeni İlan Kategorisi Ekle</h2>
     <dl>
                        <dt><label for="itip_adi">İlan Kategorisi Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="itip_adi" /></dd>
                                             </dl>
                                                                                            
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="İlan Kategorisi Ekle" />
</form>
</div>

<?php if(!empty($_POST['hiddenekle'])) {
	$itip_adi=$_POST['itip_adi'];
			
	$sektorekle=mysql_query("INSERT INTO ilantip (id,itip_adi) VALUES ('','$itip_adi')") or die(mysql_error());
	if($sektorekle) { echo "<div class='valid_box'>İlan Kategorisi eklendi.</div>";} else {echo "İlan Kategorisi eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilankat'> ";
	
	 }?>


      
      
     