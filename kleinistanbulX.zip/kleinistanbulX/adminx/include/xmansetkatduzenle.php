<?php
$xid=temizle($_GET['xid']);
$sorgu=mysql_query("SELECT mkatadi from mansetkat where mid='$xid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>

<div class="form">

<form method="post" action="index2.php?pg=mansetkat&islem=mansetkatduzenle&xid=<?php echo $xid;?>" onSubmit="return check_fekle()" id="sabitform" name="sabitform" >
     <h2>Genel Haber Kategorisi  Düzenle</h2>
     <dl>
                        <dt><label for="mkatadi">Kategori  Adı: Kategori Adı: (Max: 30 karakter</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['mkatadi']; ?>" class="text" name="mkatadi" /></dd>
                                            </dl>
                                            
                                 
                                            
                                                
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle"  class="google" value="gönder" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$xid=intval($_GET['xid']);
	$mkatadi=temizle($_POST['mkatadi']);
	
	$mansetkatupdate=mysql_query("UPDATE mansetkat SET  mkatadi='$mkatadi' where mid='$xid'");
	if($mansetkatupdate) { echo "<div class='valid_box'>Genel Haber Kategorisi  düzenledi.</div>";} else {echo "Genel Haber Kategorisi  düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=mansetkat'> ";
	
	 }?>


      
      
     