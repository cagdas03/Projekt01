<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT modul_id,modul_adi,modul_onay from modul where modul_adi='anket' limit 0,1");
$modul=mysql_fetch_assoc($sorgu);
 ?>
<div class="form">
<form method="post" action="index2.php?pg=anket&islem=ayar&do=modulonay&sid=<?php echo $sid;?>"  onSubmit="return check_anketedit()"   >
     <h2>Anket Ayarları</h2>

    <dl>
     <dt><label for="show">Anasayfa Durumu:</label></dt>
     <dd><select name="show" class="text" onchange="form.submit();">
     <option value="1" <?php if($modul['modul_onay']==1) { echo "selected='selected'";} ?>>Göster</option>
     <option value="0" <?php if($modul['modul_onay']==0) { echo "selected='selected'";} ?>>Gizle</option>
     </select> // Anket modülünün ana sayfadaki gösterimi ile ilgili ayardır.</dd>
     </dl> 
</form>
</div>

<?php
if($_GET['do']=='modulonay')
{

if($_POST['show']==0)
{mysql_query("UPDATE modul set modul_onay=0 where modul_adi='anket'");}

elseif($_POST['show']==1)
{ mysql_query("UPDATE modul set modul_onay=1 where modul_adi='anket'");}

else
{}
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=anket&islem=ayar'> ";

}
 ?>
    
      
     