<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT ilce.ilce_adi, sehir.id, sehir.ad from ilce inner join sehir on sehir.id=ilce.sehir where ilceid='$sid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>

<div class="form">

<form method="post" action="index2.php?pg=ilce&islem=ilceduzenle&sid=<?php echo $sid;?>" enctype="multipart/form-data" onSubmit="return check_fekle()" id="sehirform" name="sehirform" >
     <h2><b><?php echo $sabitsayfa['ad']; ?></b> İlçelerini Düzenle</h2>
     <dl>
                        <dt><label for="ilce_adi">İlçe Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['ilce_adi']; ?>" class="text" name="ilce_adi" /></dd>
    </dl>
    
   
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle" class="google"  value="İlçe Düzenle" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$sid=$_GET['sid'];
	
	$ilce_adi=$_POST['ilce_adi'];
					
	
	$sehirupdate=mysql_query("UPDATE ilce SET  ilce_adi='$ilce_adi'  where ilceid='$sid'");
	if($sehirupdate) { echo "<div class='valid_box'>İlçe düzenledi.</div>";} else {echo "İlçe düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilce&id=$sabitsayfa[id]'> ";
	
	 }?>

   
      
     