    <script language="JavaScript">
function check_hekleform(){
	

	if (document.hekleform.resim.value == ""){
		alert ("Lütfen haber resmi ekleyiniz.");
		document.hekleform.resim.focus();
		return false;  
	}
	
		 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=manset&islem=ekle"  enctype="multipart/form-data" onSubmit="return check_hekleform()" id="hekleform" name="hekleform" >
     <h2>Yeni Haber Ekle</h2>
     
          <dl><b>Eğer Url varsa resim direk bu url'ye yönlenecektir.</b> Url yoksa haberdeki resme tıklayınca site içinde bir sayfa açılacak ve aşağıda yazılacak Haber başlığı ve detayları bu sayfada gösterilecektir.</dl>
          
          
          
          <dl>
                        <dt><label for="kat">Genel Haber Kategorisi:</label></dt>
                        <dd> 
                        <select style="width:305px" name="kat"  >
						    <option value="" >Kategori Seçiniz</option> <?php
						    $sql="SELECT mid, mkatadi from mansetkat  order by mid asc";
						    $sorgu=mysql_query($sql) or die(mysql_error());
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['mid']; ?>" <?php if($_POST['kat']==$sehircek['mid']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['mkatadi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
              
              
     
          
     
     
    
     <dl>
                        <dt><label for="baslik">Haber Başlığı:</label></dt>
                        <dd><input type="text" value="" class="text" name="baslik" /></dd>
     </dl>
     
     
          <p>
                      <label for="ozet">Haber özeti: (90 karakter maksimum)</label><br />
                       <textarea  style="width:600px; height:80px" maxlength="90"  name="ozet"></textarea>
     
     
     
     </p>
     
    
                              <label for="detay">Haber Detayı:</label>
                       <textarea id="noise" name="detay" ></textarea>
      <script type="text/javascript" src="../js/ckayar.js"></script>
              
  
     
              <dl><dt></dt><dd style="color:#C36"><b>Uygun boyut:</b> 427x225px | <b>Dosya Türü:</b> Jpg, png , gif ]</dd></dl>
           <dl>
        				<dt><label>Haber Resmi:</label></dt>
                        <dd> <input type="file"  name="resim" /> </dd>
                       
     </dl>
     
     
               <dl>
                        <dt><label for="vitrin">Vitrin Olsun Mu?</label></dt>
                        <dd><select name="vitrin" /> 
                        <option value="0" selected="selected"> Hayır</option>
                        <option value="1">Evet</option></select> Vitrin olan haber diğerlerinden daha önde yer alır.
                        </dd>
     </dl>
     
     <dl>
                        <dt><label for="url">Haber Url:</label></dt>
                        <dd><input type="text" value="" class="text" name="url" /></dd>
     </dl>
     
     
   <div style="clear:both"></div>
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionmanset" value="manset" />
<input type="submit"  name="duzenle" class="google"  value="Haberi Kaydet" />
</form>
<br />
<br />
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	
	include("include/upload.php");
	$baslik=temizle($_POST['baslik']);
	$detay=addslashes($_POST['detay']);
	$url=$_POST['url'];
	$sabit=intval($_POST['vitrin']);
	$kat=intval($_POST['kat']);
	$ozet=area($_POST['ozet']);
	$tarih=time();
	
	
	$mansetekle=mysql_query("INSERT INTO manset (manset_baslik,manset_detay,mansetresim, manset_url, bastarih, sabit, onay,kat, manset_ozet)
	                                      VALUES ('$baslik', '$detay', '$mansetresmi', '$url' ,  '$tarih', '$sabit' ,'1','$kat', '$ozet')") or die(mysql_error());
	if($mansetekle) { echo "<div class='valid_box'>Haber eklendi.</div>";} else {echo "Haber eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=manset'> ";
	
	 }?>


      
      
     