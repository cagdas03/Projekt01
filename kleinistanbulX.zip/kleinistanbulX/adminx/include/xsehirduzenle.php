<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT ad from sehir where id='$sid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>

<div class="form">

<form method="post" action="index2.php?pg=sehir&islem=sehirduzenle&sid=<?php echo $sid;?>" enctype="multipart/form-data" onSubmit="return check_fekle()" id="sehirform" name="sehirform" >
     <h2>Şehir Düzenle</h2>
     <dl>
                        <dt><label for="sehir_adi">Şehir Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['ad']; ?>" class="text" name="sehir_adi" /></dd>
    </dl>
    
   
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle" class="google"  value="Şehir Düzenle" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$sid=$_GET['sid'];
	
	$sehir_adi=$_POST['sehir_adi'];
					
	
	$sehirupdate=mysql_query("UPDATE sehir SET  ad='$sehir_adi'  where id='$sid'");
	if($sehirupdate) { echo "<div class='valid_box'>Şehir düzenledi.</div>";} else {echo "Şehir düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sehir&islem=sehirduzenle&sid=$sid'> ";
	
	 }?>

   
      
     