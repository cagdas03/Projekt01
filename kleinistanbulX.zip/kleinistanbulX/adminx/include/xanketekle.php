    <script language="JavaScript">
function check_aekle(){
	
			if (document.ekleanket.soru.value == ""){
		alert ("Lütfen anket adını yazınız.");
		document.ekleanket.soru.focus();
		return false;  
	}
	
	 }

</script>

<script type="text/javascript">
function addFormField() {
	var id = document.getElementById("id").value;
	$("#divTxt").append("<dl id='row" + id + "'><dt><label for='txt" + id + "'>Seçenek&nbsp;&nbsp;</dt><dd><input type='text' class='text' size='20' name='txt[]' id='txt" + id + "'>&nbsp;&nbsp<a href='#' onClick='removeFormField(\"#row" + id + "\"); return false;'>Sil</a></dd><dl>");
	
	
	id = (id - 1) + 2;
	document.getElementById("id").value = id;
}

function removeFormField(id) {
	$(id).remove();
}
</script>

<body>
<div class="form">

 <h2>Yeni Anket Ekle</h2>


<form id="form1" method="post" action="index2.php?pg=anket&islem=ekle"  onSubmit="return check_aekle()"  name="ekleanket">

  
    <dl>
     <dt><label for="soru">Anket Adı:</label></dt>
     <dd><input type="text" value="" class="text" name="soru" /></dd>
     </dl> 
 <p style="float:left">
 <a href="#" onClick="addFormField(); return false;" class="bt_green"><span class="bt_green_lft"></span><strong>Seçenek Ekle</strong><span class="bt_green_r"></span></a></p>
  <div style="clear:both;"></div>

<input type="hidden" id="id" value="1">
<div id="divTxt"></div>
   
 <div style="clear:both; margin-bottom:10px"></div>      
  
 

<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionanket" value="anket" />
<input type="submit" class="google" name="duzenle"  value="Yeni Anket Ekle" />
</form>
</div>
 <div style="clear:both; margin-bottom:10px"></div>  

			   
<?php if(!empty($_POST['duzenle'])) {
	$soru=$_POST['soru'];
	
	if (isset($_POST['txt']) ) {
		
	$ekle=mysql_query("INSERT INTO polls (pollQuestion,pollStatus) values ('$soru','1')");
	
	if($ekle)
	{ // ekleme başarılı ise başlat
	
	$sorgu=mysql_query("select pollID from polls order by pollID desc limit 0,1");
	$anket=mysql_fetch_row($sorgu);
	$anketid=$anket['0'];
	$secenek=$_POST['txt'];	
	
		
	foreach($secenek as $sec)
	{  mysql_query("INSERT INTO pollAnswers (pollID,pollAnswerValue) VALUES ('$anketid','$sec') "); }
	echo "<div class='valid_box'>Tebrikler anketiniz başarıyla eklendi.</div>";
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=anket&page=$page'> ";
	} // başarılı ekleme kapat
	 
	 else  { "<div class='error_box'>Anket eklenemedi</div>"; }
	
	}
	else
	{ echo "Hiç seçenek girmediniz lütfen <b> Seçenek Ekle </b> ekle butonuna basınız";}
	
	 // txt var mı?
	} // düzenleme kapat
	
?>


      
      
     