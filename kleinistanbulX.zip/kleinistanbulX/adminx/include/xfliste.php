 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
<script type="application/javascript">
function secKaldir(check) {
	for(i=0;i<document.getElementsByName(check).length;i++) {
		document.getElementsByName(check)[i].checked = !document.getElementsByName(check)[i].checked;
	}
}
</script>
 	<script LANGUAGE="JavaScript">
function confirmSubmit()
{
var agree=confirm("Firmaya ait tüm bilgiler (Eğer varsa ilan, ürün ,resimler, logo, sektör, video...) tamamen silinecektir, Emin misiniz?");
if (agree)
	return true ;
else
	return false ;
}
// -->
</script>

 	<script LANGUAGE="JavaScript">
function vitrinSubmit()
{
var agree=confirm("Firmanın vitrin özelliğinin kaldırılmasını istediğinizden emin misiniz ? ");
if (agree)
	return true ;
else
	return false ;
}
// -->
</script>
    
    
    <?php
	
	
	//Kelime araması yapıldıysa aratılan kelime ile ilgilii sonuçları çıkaralım.
	
	if (isset($_GET['fara']) || isset($_GET['fara_x'])) {
		
		 } 
	$fkelime=$_GET['fkelime'];
	$sehir=$_GET['sehir'];
	$sektor=$_GET['sektor'];
	$paket=$_GET['paket'];
	$sira=$_GET['sira'];
	 $kosul = '';
     if($fkelime > ' '){ $kosul = $kosul . ' and firma.adi like \'%'.$fkelime.'%\''; }
	 if($sehir> ' '){ $kosul = $kosul . ' and firma.sehir='.$sehir.''; }
	 if($sektor > ' '){ $kosul = $kosul . ' and sektor.s_ustid=\''.$sektor.'\''; }
	 if($paket > ' '){ $kosul = $kosul . ' and firma.uyeliktur=\''.$paket.'\''; }
	 
	 if($sira > ' ' & $sira=='fadi'){ $kosulsira = $kosulsira . ' order by firma.adi asc '; }
	 if($sira > ' ' & $sira=='fadi2'){ $kosulsira = $kosulsira . ' order by firma.adi desc'; }
	 if($sira > ' ' & $sira=='vitrin'){ $kosulsira = $kosulsira . ' order by firma.vitrin desc '; }
	  if($sira > ' ' & $sira=='vitrin2'){ $kosulsira = $kosulsira . ' order by firma.vitrin asc '; }
	 if($sira > ' ' & $sira=='sehir'){ $kosulsira = $kosulsira . ' order by sehir.ad asc '; }
	  if($sira > ' ' & $sira=='sehir2'){ $kosulsira = $kosulsira . ' order by sehir.ad desc '; }
	  if($sira > ' ' & $sira=='paket'){ $kosulsira = $kosulsira . ' order by firma.uyeliktur asc '; }
	  if($sira > ' ' & $sira=='paket2'){ $kosulsira = $kosulsira . ' order by firma.uyeliktur desc '; }
	  if($sira > ' ' & $sira=='onay'){ $kosulsira = $kosulsira . ' order by firma.onay desc '; }
	   if($sira > ' ' & $sira=='onay2'){ $kosulsira = $kosulsira . ' order by firma.onay asc '; }
	   if($sira > ' ' & $sira=='tarih'){ $kosulsira = $kosulsira . ' order by firma.bastarih asc '; }
	     if($sira > ' ' & $sira=='tarih2'){ $kosulsira = $kosulsira . ' order by firma.bastarih desc '; }
		if($sira < ' '){ $kosulsira = $kosulsira . ' order by firma.bastarih desc '; }
	  
	
	
	// include your code to connect to DB.

	$tbl_name="firma";		//your table name
	// How many adjacent pages should be shown on each side?
	$adjacents = 20;
	
	/* 
	   First get total number of rows in data table. 
	   If you have a WHERE clause in your query, make sure you mirror it here.
	*/
	$query = "SELECT COUNT(*) as num FROM $tbl_name inner join sehir on sehir.id=firma.sehir inner join sektor on sektor.s_fid=firma.id where 1 ".$kosul."";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	
	/* Setup vars for query. */
	$targetpage = "index2.php?pg=fliste&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket&sira=$sira"; 	//your file name  (the name of this file)
	$limit = 50; 								//how many items to show per page
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	$sql = "SELECT firma.id, firma.adi,firma.bastarih,firma.uyeliktur,firma.yetkili,firma.onay, firma.vitrin, sehir.ad FROM $tbl_name inner join sehir on sehir.id=firma.sehir  inner join sektor on sektor.s_fid=firma.id where 1 ".$kosul." group by firma.id ".$kosulsira." LIMIT $start, $limit";
	$result = mysql_query($sql) or die(mysql_error());
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\">« Geri</a>";
		else
			$pagination.= "<span class=\"disabled\">« Geri</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage&page=$next\">İleri »</a>";
		else
			$pagination.= "<span class=\"disabled\">İleri »</span>";
		$pagination.= "</div>\n";		
	}
?>

            <form method="GET" action="index2.php">
            
            
     <select name="sehir" class="text" onchange="this.form.submit();">
						    <option value="" >Tüm Şehirler</option> <?php
						    $sql="SELECT id, ad from sehir order by ad asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_GET['sehir']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['ad']; ?></option><?php }?>
                            <option value="999" <?php if($_GET['sehir']==999) { echo "selected='selected'";} ?>>Diğer Şehirler</option>
                            </select>
                            
                            
                            
                                 <select name="sektor" style="width:180px" class="text" onchange="this.form.submit();">
						    <option value="" >Tüm Kategoriler</option> <?php
						    $sql="SELECT ust_id, ust_adi from ustkat order by ust_adi asc";
						    $sorgu=mysql_query($sql);
						    while($sektorcek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sektorcek['ust_id']; ?>" <?php if($_GET['sektor']==$sektorcek['ust_id']) { echo "selected='selected'";} ?>>
							<?php echo $sektorcek['ust_adi']; ?></option><?php }?>
                                                    </select>
                                                    
                                                    
                                                          <select name="paket" class="text" onchange="this.form.submit();">
						    <option value="" >Üye Türü</option> <?php
						    $sql="SELECT id, tip_adi from uyeliktur order by id asc";
						    $sorgu=mysql_query($sql);
						    while($paketcek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $paketcek['id']; ?>" <?php if($_GET['paket']==$paketcek['id']) { echo "selected='selected'";} ?>>
							<?php echo substr($paketcek['tip_adi'],0,16); ?></option><?php }?>
                                                    </select>
                            
                            
                            
 <div class="sidebar_search" style="float:right"><input type="text" name="fkelime" class="search_input" value="<?php echo $_GET['fkelime'];?>" onclick="this.value=''">
 <input type="image" name="fara" class="search_submit" src="images/search.png">   </div> 
            <input type="hidden" name="pg" value="fliste" />
           
            </form>            
         
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	<th scope="col" class="rounded-company"><input type="button"  class="google" onclick='secKaldir("comment[]")' value='Tümü'></th>
            <th scope="col" class="rounded">
			<?php if($sira=='fadi2') { echo "<a href='index2.php?pg=fliste&sira=fadi'>Firma Adı<img src='images/downs.png' /></a>"; }
			else if ( $sira=="fadi") { echo " <a href='index2.php?pg=fliste&sira=fadi2'>Firma Adı<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=fadi'>Firma Adı</a>"; }
			?> </th>
            <th scope="col" class="rounded">
            <?php if($sira=='sehir2') { echo "<a href='index2.php?pg=fliste&sira=sehir'>Şehir<img src='images/downs.png' /></a>"; }
			else if ( $sira=="sehir") { echo " <a href='index2.php?pg=fliste&sira=sehir2'>Şehir<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=sehir'>Şehir</a>"; }
			?>
        </th>
            <th scope="col" class="rounded">
                   <?php if($sira=='paket2') { echo "<a href='index2.php?pg=fliste&sira=paket'>Üye Tipi<img src='images/downs.png' /></a>"; }
			else if ( $sira=="paket") { echo " <a href='index2.php?pg=fliste&sira=paket2'>Üye Tipi<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=paket'>Üyelik Tipi</a>"; }
			?>
      </th>
            <th scope="col" class="rounded">
               <?php if($sira=='tarih2') { echo "<a href='index2.php?pg=fliste&sira=tarih'>Tarih<img src='images/downs.png' /></a>"; }
			else if ( $sira=="tarih") { echo " <a href='index2.php?pg=fliste&sira=tarih2'>Tarih<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=tarih'>Tarih</a>"; }
			?>
      </th>
            <th scope="col" class="rounded">
                               <?php if($sira=='vitrin2') { echo "<a href='index2.php?pg=fliste&sira=vitrin'>Vitrin<img src='images/downs.png' /></a>"; }
			else if ( $sira=="vitrin") { echo " <a href='index2.php?pg=fliste&sira=vitrin2'>Vitrin<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=vitrin'>Vitrin</a>"; }
			?>
      </th>            
            <th scope="col" class="rounded">
                     <?php if($sira=='onay2') { echo "<a href='index2.php?pg=fliste&sira=onay'>Onay<img src='images/downs.png' /></a>"; }
			else if ( $sira=="onay") { echo " <a href='index2.php?pg=fliste&sira=onay2'>Onay<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=fliste&sira=onay'>Onay</a>"; }
			?>
      </th>
            <th scope="col" class="rounded">Düz.</th>
            <th scope="col" class="rounded-q4">Sil</th>
        </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="8" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
    <form method="GET" action="index2.php">
	<?php
		while($row = mysql_fetch_assoc($result))
		{
	//Onaylı mı ? Değil mi ? Ona bakalım ve buna göre resim adı atayalım.
	if ( $row['onay']==1){$onayresim=onay;}else{$onayresim=busy;}	
    if ( $row['vitrin']==1){$onayvitrin=vitrinvar;}else{$onayvitrin=vitrinyok;}	?>
	    	<tr>
        	<td><input type="checkbox" name="comment[]" value="<?php echo $row['id'];?>" /></td>
            <td><?php echo $row['adi']; ?></td>
            <td><?php echo $row['ad']; ?></td>
            <td><img src="images/xpaket<?php echo $row['uyeliktur'] ?>.png" /></td>
            <td><?php echo strftime("%d/%m/%Y", $row['bastarih']); ?></td>
            <td><a href="index2.php?pg=fliste&page=<?php echo $_GET['page']; ?>&islem=tekvitrin&fid=<?php echo $row['id']; ?>&deger=<?php echo $row['vitrin']; ?>&fkelime=<?php echo $_GET['fkelime'];?>&sehir=<?php echo $_GET['sehir']; ?>&sektor=<?php echo $_GET['sektor']; ?>&paket=<?php echo $_GET['paket'];?>"><img src="images/<?php echo $onayvitrin; ?>.gif" alt="Vitrin"  border="0" /></a></td>
            
            <td><a href="index2.php?pg=fliste&page=<?php echo $_GET['page']; ?>&islem=onay&fid=<?php echo $row['id']; ?>&deger=<?php echo $row['onay']; ?>&fkelime=<?php echo $_GET['fkelime'];?>&sehir=<?php echo $_GET['sehir']; ?>&sektor=<?php echo $_GET['sektor']; ?>&paket=<?php echo $_GET['paket'];?>"><img src="images/<?php echo $onayresim; ?>.png" alt="Onay" title="" border="0" /></a></td>
            
            <td><a href="index2.php?pg=fduzenle&page=<?php echo $_GET['page']; ?>&fid=<?php echo $row['id']; ?>&fkelime=<?php echo $_GET['fkelime'];?>&sehir=<?php echo $_GET['sehir']; ?>&sektor=<?php echo $_GET['sektor']; ?>&paket=<?php echo $_GET['paket'];?>"><img src="images/user_edit.png" alt="Düzenle" title="" border="0" /></a></td>
            
            <td><a href="index2.php?pg=fliste&page=<?php echo $_GET['page']; ?>&islem=teksil&fid=<?php echo $row['id']; ?>&fkelime=<?php echo $_GET['fkelime'];?>&sehir=<?php echo $_GET['sehir']; ?>&sektor=<?php echo $_GET['sektor']; ?>&paket=<?php echo $_GET['paket'];?>" class="ask"><img src="images/trash.png" alt="Sil" title="" border="0" /></a></td>
        </tr>
            
    
	<?
		}
	?>
     <tr><td colspan="9">Seçilenleri:
     <input type="hidden"  name="page" value="<?php echo $_GET['page']; ?>" />
     <input type="hidden"  name="pg" value="fliste" />
     <input type="hidden"  name="fkelime" value="<?php echo $_GET['fkelime']; ?>" />
     <input type="hidden"  name="sehir" value="<?php echo $_GET['sehir']; ?>" />
     <input type="hidden"  name="sektor" value="<?php echo $_GET['sektor']; ?>" />
     <input type="hidden"  name="paket" value="<?php echo $_GET['paket']; ?>" />
     <input type="submit" class="google" name="tumonay" value="Aktif Et" />
     <input type="submit" class="google" name="tumiptal" value="Pasif Et" />
     <input type="submit" class="google" style="color:#C36" onclick="return confirmSubmit();" name="tumsil" value="Sil" />
     <div style="float:right">
     <input type="submit" class="google"  name="tumvitrin" value="Vitrin Yap"  />
     <input type="submit" class="google"  name="tumvitriniptal" value="Vitrini Kaldır" onclick="return vitrinSubmit();" />
     <input type="submit" class="google"  name="tumgold" value="Altın Yap" />
     <input type="submit" class="google"    name="tumsilver" value="Gümüş Yap" />
     <input type="submit" class="google"   name="tumstandart" value="Normal Yap" />
     </div>
         </td></tr>
     </form>
 </tbody>
</table>
<?=$pagination?>  
 <?php
//İşlemleri aşağıda ypıp uyarı ya da valid değerlerini verelim

//Onaylama İşlemi
$islem=$_GET['islem'];
switch($islem){
		
case "onay":
$fid=intval($_GET['fid']);
$deger=intval($_GET['deger']);
$page=$_GET['page'];
$fkelime=$_GET['fkelime'];

$soron=mysql_query("SELECT adi,id,email,username from firma where id='$fid'");
$onfirma=mysql_fetch_assoc($soron);
$firma_adi=seo($onfirma['adi']);
if($deger==1){  $uponay=mysql_query("UPDATE firma set onay=0 where id='$fid'");
   echo "<div class='valid_box'>Firmanın yayımlanması durduruldu.</div>";
    echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";  }
elseif($deger==0) {  $uponay=mysql_query("UPDATE firma set onay=1 where id='$fid'");
   echo "<div class='valid_box'>Firma onaylandı.</div>"; 
  
$konu=$site_adi. " rehberimizdeki ".$onfirma['adi']." adlı Firmanız Onaylandı.";	
$mesaj = "<p><b>Mesaj: Firma detaylarını görmek için <a href='".$rowtt['site_url']."/firmalar/".$firma_adi."_".$onfirma['id'].".html'> tıklayınız</a></p>";  
postala($onfirma['email'],$site_adi,$mailayar,$konu,$mesaj); 

 
   echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> "; }
else{echo "<div class='error_box'>Bu firmanın veritabanındaki onay bölümünde tanımlanamayan değerler var ya da firma onayı için firma düzenleme menüsünü kullanınız.</div>";}
break;

case "tekvitrin":
$fid=$_GET['fid'];
$deger=$_GET['deger'];
$page=$_GET['page'];
$fkelime=$_GET['fkelime'];
if($deger==1){  $upvitrin=mysql_query("UPDATE firma set vitrin=0 where id='$fid'");
   echo "<div class='valid_box'>Firmanın vitin özelliği kaldırıldı.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";  }
elseif($deger==0) {  $upvitrin=mysql_query("UPDATE firma set vitrin=1 where id='$fid'");
   echo "<div class='valid_box'>Firmaya vitrin özelliği eklendi.</div>"; 
   echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> "; }
else{echo "<div class='error_box'>Bu firmanın veritabanındaki vitrin bölümünde tanımlanamayan değerler var ya da firma vitrini için firma düzenleme menüsünü kullanınız.</div>";}
break;

case "teksil":
$fid=$_GET['fid'];
$page=$_GET['page'];
$fkelime=$_GET['fkelime'];

//Resim dosyaları klasörden siliniyor
$resimyol=mysql_query("SELECT firmaresim FROM firmaresim where fid='$fid' ");
while($unresim=mysql_fetch_assoc($resimyol)){$ryol=$unresim['firmaresim']; @unlink("../uploads/firmaresim/$ryol"); }
//Video dosyaları klasörden siliniyor

$logoyol=mysql_query("SELECT logo FROM firma where id='$fid' ");
while($unlogo=mysql_fetch_assoc($logoyol)){$yol=$unlogo['logo']; @unlink("../uploads/logo/$yol"); }


$firmasil = mysql_query("DELETE FROM firma where id='$fid' ");
$resimsil = mysql_query("DELETE FROM firmaresim where fid='$fid' ");
$sektorsil = mysql_query("DELETE FROM sektor where s_fid='$fid' "); 

   echo "<div class='valid_box'>Firmaya Ait Tüm Bilgiler Silindi.</div>"; 
   echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
break;

default:

}

//Seçilenleri Aktif Et/////////////////////

if(isset($_GET['tumonay']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set onay=1 where id in (".implode(',', $comments).")"; 
mysql_query($sql); 

 echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
}

//Seçilenleri Pasif Et/////////////////////
if(isset($_GET['tumiptal']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set onay=0 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
  //Seçilenleri Vitrin Yap/////////////////////
if(isset($_GET['tumvitrin']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set vitrin=1 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
   //Seçilenleri Vitrin İptal/////////////////////
if(isset($_GET['tumvitriniptal']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set vitrin=0 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
 //Seçilenleri Altın Yap/////////////////////
if(isset($_GET['tumgold']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set uyeliktur=3 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
  //Seçilenleri Gümüş Yap/////////////////////
if(isset($_GET['tumsilver']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set uyeliktur=2 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
   //Seçilenleri Normal Yap/////////////////////
if(isset($_GET['tumstandart']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE firma set uyeliktur=1 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
 }
 
 
//Seçilenleri Sil/////////////////////
if(isset($_GET['tumsil']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 

//Resim dosyaları klasörden siliniyor
$resimyol=mysql_query("SELECT firmaresim FROM firmaresim where fid in (".implode(',', $comments).")");
while($unresim=mysql_fetch_assoc($resimyol)){$ryol=$unresim['firmaresim']; @unlink("../uploads/firmaresim/$ryol"); }



//Logo dosyaları klasörden siliniyor
$logoyol=mysql_query("SELECT logo FROM firma where id in (".implode(',', $comments).")");
while($unlogo=mysql_fetch_assoc($logoyol)){$yol=$unlogo['logo']; @unlink("../uploads/logo/$yol"); }



$resimsil = mysql_query("DELETE FROM firmaresim where fid in (".implode(',', $comments).")");
$firmasil = mysql_query("DELETE FROM firma where id in (".implode(',', $comments).")");
$sektorsil = mysql_query("DELETE FROM sektor where s_fid in (".implode(',', $comments).")"); 
 

echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste&page=$page&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket'> ";
}

?>  
<?php } //üye kontrol kapat?>