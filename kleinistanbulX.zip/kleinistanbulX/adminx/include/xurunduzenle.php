     <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>


	<script language="JavaScript">
function check_sanekle(){
	
			if (document.sekleform.firma.value == ""){
		alert ("Lütfen bir firma seçiniz yazınız.");
		document.sekleform.firma.focus();
		return false;  
	}
	
				if (document.sekleform.baslik.value == ""){
		alert ("Lütfen başlık yazınız.");
		document.sekleform.baslik.focus();
		return false;  
	}
	
	
	
	
	 }

</script>
<div class="form">

<?php
$id=$_GET['sid'];
$sorgu=mysql_query("SELECT urun.urun_baslik, urun.urun_detay, urun.urun_etiket, urun.urun_fiyat , firma.adi, urun.fid, urun.urunresim from urun inner join firma on firma.id=urun.fid where urun.id='$id'");
while($urun=mysql_fetch_assoc($sorgu))
{
 ?>

<form method="post" action="index2.php?pg=urunduzenle&sid=<?php echo $id; ?>"  enctype="multipart/form-data" onSubmit="return check_sanekle()" id="sekleform" name="sekleform" >

<fieldset>
     <h2><?php echo $urun['urun_baslik']; ?> / <?php  echo $urun['adi']; ?></h2>
     
             <dl>
                        <dt><label for="firma">Firma Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="firma" >
						    <option value="" >Firma Seç</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($urun['fid']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
     
     
               <dl>
        				<dt><label for="baslik">Ürün Başlığı</label></dt>
                        <dd> <input type="text" class="text"  value="<?php echo $urun['urun_baslik']; ?>"  name="baslik" />  </dd>
                       
              </dl>
     
     
                
               
        				<label for="detay">Ürün Detayı</label>
                        <textarea id="noise" name="detay" ><?php echo stripslashes($urun['urun_detay']); ?></textarea> 
                         <script type="text/javascript" src="../js/ckayar.js"></script>
                       
            
              
               
               <dl>
        				<dt><label for="fiyat">Ürün Fiyatı</label></dt>
                        <dd> <input type="text" class="text" value="<?php echo $urun['urun_fiyat']; ?>"  name="fiyat" /> </dd>
                       
              </dl> 
              
              
               
             <dl>
                        <dt><label for="etiket">Etiketler:</label></dt>
                        <dd><input type="text" class="text" value="<?php echo $urun['urun_etiket']; ?>" name="etiket" /></dd>
                    </dl>
      
      
              <dl><dt><label>Resim:</label></dt>
              <dd   style="height:50px;">
			 <?php if(!empty($urun['urunresim'])) {?>   <img src="../uploads/urun/<?php echo $urun['urunresim'];?>" width="80" height="50" border="0"><a href="index2.php?pg=urunduzenle&islem=resimsil&rid=<?php echo $id; ?>" style="margin:5px" class="ask"><img src="images/delete.png" alt="Sil" /></a></dd>  <?php } else {?>
                           <input type="file"  name="f_urun" value="" /> </dd>
                       <?php }?>
                      </dl>
                      
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionurun" value="urun" />
<input type="submit" class="google" name="duzenle"  value="Ürünü Düzenle" />

</fieldset>
</form>
<?php }?>
</div>

			   
<?php

if($_GET['islem']=="resimsil")
{  

$rid=$_GET['rid'];
$resimyol=mysql_fetch_row(mysql_query("SELECT urunresim from urun where id='$rid' limit 0,1"));
$ryol=$resimyol['0'];
@unlink("../uploads/urun/$ryol");
$resimsil=mysql_query("UPDATE urun SET urunresim=''  where id='$rid'");
   echo "<div class='valid_box'>Resim Silindi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=urunduzenle&sid=$rid'> ";
 break;

}





 if(!empty($_POST['duzenle'])) {
	
	$firma=$_POST['firma'];
	include("include/upload.php");
	$baslik=$_POST['baslik'];
	$detay=addslashes($_POST['detay']);
	$fiyat=$_POST['fiyat'];
	$etiket=$_POST['etiket'];
		// ekleme yapılıyor
	
	 $sorgu=mysql_query("SELECT urunresim from urun where id='$id' limit 0,1");
			  $sec=mysql_fetch_row($sorgu);
			  if($_FILES['f_urun']['name']==''){ $f_urun=$sec['0'];} else { $f_urun=$urunismi;}
				
				
	$urunekle=mysql_query("UPDATE  urun  SET fid='$firma' ,urun_baslik='$baslik', urun_detay='$detay', urun_fiyat='$fiyat', urun_etiket='$etiket', urunresim='$f_urun' where id='$id' ") or die(mysql_error());
	if($urunekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=urunduzenle&sid=$id'> ";
	
	
	
	} // urun tur eklenememiş
   
    }// submite basulmışsa
	 
	 ?>


      
      
     