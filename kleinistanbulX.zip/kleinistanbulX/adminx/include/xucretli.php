 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
    
    
    <?php
	
	if($_GET['islem']=="ucretliduzenle")
	{
	include("include/xucretliduzenle.php");
	}
	
	
	//Kelime araması yapıldıysa aratılan kelime ile ilgilii sonuçları çıkaralım.
	
	if (isset($_GET['fara']) || isset($_GET['fara_x'])) {}
	
	 
	$fkelime=$_GET['fkelime'];
	$sehir=$_GET['sehir'];
	$sektor=$_GET['sektor'];
	$paket=$_GET['paket'];
	$sira=$_GET['sira'];
	 $kosul = '';
     if($fkelime > ' '){ $kosul = $kosul . ' and firma.adi like \'%'.$fkelime.'%\''; }
	 if($sehir> ' '){ $kosul = $kosul . ' and firma.sehir='.$sehir.''; }
	 if($sektor > ' '){ $kosul = $kosul . ' and sektor.s_ustid=\''.$sektor.'\''; }
	 if($paket > ' '){ $kosul = $kosul . ' and firma.uyeliktur=\''.$paket.'\''; }
	 
	 if($sira > ' ' & $sira=='fadi'){ $kosulsira = $kosulsira . ' order by firma.adi asc '; }
	 if($sira > ' ' & $sira=='fadi2'){ $kosulsira = $kosulsira . ' order by firma.adi desc'; }
	 if($sira > ' ' & $sira=='vitrin'){ $kosulsira = $kosulsira . ' order by firma.vitrin desc '; }
	  if($sira > ' ' & $sira=='vitrin2'){ $kosulsira = $kosulsira . ' order by firma.vitrin asc '; }
	 if($sira > ' ' & $sira=='sehir'){ $kosulsira = $kosulsira . ' order by sehir.ad asc '; }
	  if($sira > ' ' & $sira=='sehir2'){ $kosulsira = $kosulsira . ' order by sehir.ad desc '; }
	  if($sira > ' ' & $sira=='paket'){ $kosulsira = $kosulsira . ' order by firma.uyeliktur asc '; }
	  if($sira > ' ' & $sira=='paket2'){ $kosulsira = $kosulsira . ' order by firma.uyeliktur desc '; }
	  if($sira > ' ' & $sira=='onay'){ $kosulsira = $kosulsira . ' order by firma.onay desc '; }
	   if($sira > ' ' & $sira=='onay2'){ $kosulsira = $kosulsira . ' order by firma.onay asc '; }
	  
	  if($sira < ' '){   if($paket==1) { $kosulsira = $kosulsira . ' order by firma.normal_bit ASC ';  } else if($paket==2) 
	  { $kosulsira = $kosulsira . ' order by firma.gumus_bit ASC ';}    else if ($paket==3) 
	  { $kosulsira = $kosulsira . ' order by firma.altin_bit ASC '; }
	     }
	   
	  	  
	$bugun=time();
	
	// include your code to connect to DB.

	$tbl_name="firma";		//your table name
	// How many adjacent pages should be shown on each side?
	$adjacents = 20;
	
	/* 
	   First get total number of rows in data table. 
	   If you have a WHERE clause in your query, make sure you mirror it here.
	*/
	$query = "SELECT COUNT(*) as num FROM $tbl_name inner join sehir on sehir.id=firma.sehir inner join sektor on sektor.s_fid=firma.id where 1 and firma.uyeliktur>0 ".$kosul."";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	
	/* Setup vars for query. */
	$targetpage = "index2.php?pg=ucretli&fkelime=$fkelime&sehir=$sehir&sektor=$sektor&paket=$paket&sira=$sira"; 	//your file name  (the name of this file)
	$limit = 50; 								//how many items to show per page
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	$sql = "SELECT firma.id, firma.adi,firma.bastarih,firma.gumus_bas, firma.gumus_bit, firma.altin_bas, firma.altin_bit , firma.normal_bas, firma.normal_bit, firma.uyeliktur,firma.yetkili,firma.onay, firma.vitrin, sehir.ad FROM $tbl_name inner join sehir on sehir.id=firma.sehir  inner join sektor on sektor.s_fid=firma.id where 1 and firma.uyeliktur>0 ".$kosul." group by firma.id ".$kosulsira." LIMIT $start, $limit";
	$result = mysql_query($sql) or die(mysql_error());
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\">« Geri</a>";
		else
			$pagination.= "<span class=\"disabled\">« Geri</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage&page=$next\">İleri »</a>";
		else
			$pagination.= "<span class=\"disabled\">İleri »</span>";
		$pagination.= "</div>\n";		
	}
	
	
	
?>

            <form method="GET" action="index2.php">
            
            
     <select name="sehir" class="text" onchange="this.form.submit();">
						    <option value="" >Tüm Şehirler</option> <?php
						    $sql="SELECT id, ad from sehir order by ad asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_GET['sehir']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['ad']; ?></option><?php }?>
                           
                            </select>
                            
                            
                            
                                 <select name="sektor" style="width:180px" class="text" onchange="this.form.submit();">
						    <option value="" >Tüm Kategoriler</option> <?php
						    $sql="SELECT ust_id, ust_adi from ustkat order by ust_adi asc";
						    $sorgu=mysql_query($sql);
						    while($sektorcek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sektorcek['ust_id']; ?>" <?php if($_GET['sektor']==$sektorcek['ust_id']) { echo "selected='selected'";} ?>>
							<?php echo $sektorcek['ust_adi']; ?></option><?php }?>
                                                    </select>
                                                    
                                                    
                                                          <select name="paket" class="text" onchange="this.form.submit();">
						    <option value="" >Üye Türü</option> <?php
						    $sql="SELECT id, tip_adi from uyeliktur where id>0 order by id asc";
						    $sorgu=mysql_query($sql);
						    while($paketcek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $paketcek['id']; ?>" <?php if($_GET['paket']==$paketcek['id']) { echo "selected='selected'";} ?>>
							<?php echo substr($paketcek['tip_adi'],0,16); ?></option><?php }?>
                                                    </select>
                            
                            
                            
 <div class="sidebar_search" style="float:right"><input type="text" name="fkelime" class="search_input" value="<?php echo $_GET['fkelime'];?>" onclick="this.value=''">
 <input type="image" name="fara" class="search_submit" src="images/search.png">   </div> 
            <input type="hidden" name="pg" value="ucretli" />
           
            </form>            
         
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	<th scope="col" class="rounded-company" style="width:70px" >Kalan Gün</th>
            <th scope="col" class="rounded">
			<?php if($sira=='fadi2') { echo "<a href='index2.php?pg=ucretli&sira=fadi&paket=$paket'>Firma Adı<img src='images/downs.png' /></a>"; }
			else if ( $sira=="fadi") { echo " <a href='index2.php?pg=ucretli&sira=fadi2&paket=$paket'>Firma Adı<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=ucretli&sira=fadi&paket=$paket'>Firma Adı</a>"; }
			?> </th>
            
            <th scope="col" class="rounded">
                   Üye Tipi
      </th>
      
      <th scope="col" class="rounded">        Baş. Tarih      </th>
      
        <th scope="col" class="rounded">        Bit. Tarih      </th>
        
          
                        
            
            <th scope="col" class="rounded-q4">Düz.</th>
               </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="5" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
    <form method="GET" action="index2.php">
	<?php
		while($row = mysql_fetch_assoc($result))
		{
	//Onaylı mı ? Değil mi ? Ona bakalım ve buna göre resim adı atayalım.
	?>
    
    
    <?php
			 if($paket==2) { $kgun=intval(($row['gumus_bit']-$bugun)/86400); }
			  elseif ($paket==3) { $kgun=intval(($row['altin_bit']-$bugun)/86400);}
			   elseif ($paket==1) {$kgun=intval(($row['normal_bit']-$bugun)/86400);} 
			   
		    if ($kgun>0 && $kgun<8) 
		    { $stil=" style='background:#F8ABAD' ";}
			elseif( $kgun>7 && $kgun<31)
			{ $stil=" style='background:#FFCC00' "; }
			elseif ($kgun<1 )
			{ $stil=" style='background:#666' "; }
			else
			{ $stil='';}		
		   
			 ?>
             
	    	<tr>
            <td width="60" <?php echo $stil; ?> ><b style="color:#000"><?php echo $kgun; ?> gün</b></td>
        	<td <?php echo $stil; ?>><?php echo $row['adi']; ?></td>
            <td <?php echo $stil; ?>><img src="images/xpaket<?php echo $row['uyeliktur'] ?>.png" /></td>
            
            <td <?php echo $stil; ?>><?php if($paket==2) { echo strftime("%d/%m/%Y", $row['gumus_bas']);} elseif ($paket==3) {echo strftime("%d/%m/%Y", $row['altin_bas']);} elseif ($paket==1) {echo strftime("%d/%m/%Y", $row['normal_bas']);} ?></td>
            <td <?php echo $stil; ?>><?php if($paket==2) { echo strftime("%d/%m/%Y", $row['gumus_bit']);} elseif ($paket==3) {echo strftime("%d/%m/%Y", $row['altin_bit']);} elseif ($paket==1) {echo strftime("%d/%m/%Y", $row['normal_bit']);} ?></td>
                    
            <td <?php echo $stil; ?>><a href="index2.php?pg=ucretli&islem=ucretliduzenle&page=<?php echo $_GET['page']; ?>&fid=<?php echo $row['id']; ?>&paket=<?php echo $_GET['paket'];?>"><img src="images/user_edit.png" alt="Düzenle" title="" border="0" /></a></td>

            
            
        </tr>
            
    
	<?
		}
	?>
     <tr><td colspan="6"></td></tr>
     </form>
 </tbody>
</table>
<?=$pagination?>  
  
<?php } //üye kontrol kapat?>