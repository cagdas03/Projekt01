<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT sayfa.adi, sayfa.sira, sayfa.pg, sayfa.url, sayfa.detay, menu.madi from sayfa inner join menu on menu.mpg=sayfa.pg where sayfa.id='$sid' limit 0,1");
while($sabitsayfa=mysql_fetch_assoc($sorgu)) {
 ?>

<div class="form" style="margin-top:10px">

<form method="post" action="index2.php?pg=sabitliste&islem=sabitduzenle&sid=<?php echo $sid;?>" onSubmit="return check_fekle()" id="sabitform" name="sabitform" >
     <h2><?php echo $sabitsayfa['madi']; ?>/<?php echo $sabitsayfa['adi']; ?></h2>
     
             <dl>
                        <dt><label for="sabit_baslik">Menü Seç:</label></dt>
                        <dd>
                        <select name="menu">
                        <option value="">Menü Seç</option>
						<?php 
						$sorgum=mysql_query("SELECT madi, mpg from menu order by madi asc") or die(mysql_error());
						while($menu=mysql_fetch_assoc($sorgum))
						{
							?>
					  <option value="<?php echo $menu['mpg']; ?>" <?php if ($menu['mpg']==$sabitsayfa['pg']) { echo "selected='selected'";} ?> ><?php echo $menu['madi']; ?>
                      </option>
							<?php
						}
						
						?>
                        </select>
                        </dd>
                                                
                    </dl>
                    
                    
     <dl>
                        <dt><label for="sabit_baslik">Alt Menü Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['adi']; ?>" class="text" name="sabit_baslik" /></dd>
                                                
                    </dl>
                    
                         
             <dl>
                        <dt><label for="sira">Sıra:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['sira']; ?>" class="text" name="sira" /></dd>
             </dl>
            
                    
                    
<b>Sayfa İçeriği:</b><br>  

<br>
<label for="detay"></label>
 <textarea id="noise" name="detay" ><?php echo stripslashes($sabitsayfa['detay']); ?></textarea>
 <script type="text/javascript" src="../js/ckayar.js"></script>
                      
     
     
     
             <dl>
                        <dt><label for="url">Url:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['url']; ?>" class="text" name="url" /></dd>
             </dl>
                                
                                                 
                      

<input type="hidden" name="duzen" value="ok" />
<input type="submit" name="duzenle"  value="Düzenle" />
</form>
</div>

<?php }?>

<?php if(!empty($_POST['duzen'])) {
	$sid=$_GET['sid'];
	$sabit_icerik=addslashes($_POST['detay']);
	$sabit_baslik=$_POST['sabit_baslik'];
	$menu=$_POST['menu'];
	$url=$_POST['url'];
	$sira=$_POST['sira'];
		
	$sabitupdate=mysql_query("UPDATE sayfa SET detay='$sabit_icerik', adi='$sabit_baslik' , pg='$menu', url='$url' , sira='$sira' where id='$sid'");
	if($sabitupdate) { echo "<div class='valid_box'>Alt Menü düzenledi.</div>";} else {echo "Alt Menü düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sabitliste'> ";
	
	 }?>


      
      
     