 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
 <link rel="stylesheet" type="text/css" href="css/ui.dropdownchecklist.themeroller.css">
 <script type="text/javascript" src="js/uicustom.js"></script>
 <script type="text/javascript" src="js/ui.dropdownchecklist-1.1-min.js"></script>
 <script type="text/javascript" language="javascript">
 $(document).ready(function() {
 $("#s8").dropdownchecklist( { emptyText: "Lütfen Seçiniz...", width: 295 } );        
 });

//username check
pic1 = new Image(16, 16); 
pic1.src = "images/loader.gif";
$(document).ready(function(){
$("#username2").change(function() { 
var usr = $("#username2").val();
if(usr.length >= 3)
{
$("#status").html('<img src="../images/loader.gif" align="absmiddle">Kontrol ediliyor...');

    $.ajax({  
    type: "POST",  
    url: "check.php",  
    data: "username2="+ usr,  
    success: function(msg){  
   
   $("#status").ajaxComplete(function(event, request, settings){ 

	if(msg == 'Kullanıcı Adı Müsait')
	{ 
        $("#username2").removeClass('object_error'); // if necessary
		$("#username2").addClass("object_ok");
		$(this).html('<img src="../images/accepted.png" align="absmiddle"> <font color="Green"> Uygun </font>  ');
	}  
	else  
	{  
		$("#username2").removeClass('object_ok'); // if necessary
		$("#username2").addClass("object_error");
		$(this).html(msg);
	}  
   
   });

 } 
   
  }); 

}
else
	{
	$("#status").html('<font color="red">Kullanıcı adı en az <strong>3</strong> karakter olmalıdır.</font>');
	$("#username2").removeClass('object_ok'); // if necessary
	$("#username2").addClass("object_error");
	}

});

});


function check_fekle(){
	
	
	
 	
	if (document.paket.paket.value == ""){
		alert ("Lütfen Üyelik Tipi Seçiniz.");
		document.paket.paket.focus();
		return false;  
	}
	
	
				if (document.fekleform.username2.value == ""){
		alert ("Kullanıcı adı yazınız.");
		document.fekleform.username2.focus();
		return false;  
	}
	
	
		if (document.fekleform.password.value == ""){
		alert ("Şifre yazınız.");
		document.fekleform.password.focus();
		return false;  
	}
	
	
		
		if (document.fekleform.confirm_password.value == ""){
		alert ("Şifreyi tekrar yazınız.");
		document.fekleform.confirm_password.focus();
		return false;  
	}
	
	
				if (document.fekleform.password.value != document.fekleform.confirm_password.value){
		alert ("Şifre ile Şifre tekrarı uyuşmuyor.");
		document.fekleform.password.focus();
		return false;
	}
	
	
	
	if (document.fekleform.f_adi.value == ""){
		alert ("Lütfen Firma Adını Yazınız.");
		document.fekleform.f_adi.focus();
		return false;  
	}
	
	if (document.fekleform.f_adi.value.length<3 || document.fekleform.f_adi.value.length>200){
		alert ("Firma adınız 3 karakterden az, 200 karakterden fazla olmamalıdır.");
		document.fekleform.f_adi.focus();
		return false; 	
	}
	
	if (document.fekleform.sehir.value == ""){
		alert ("Lütfen Bir Şehir Seçiniz.");
		document.fekleform.sehir.focus();
		return false;
	}
	
		if (document.fekleform.ilce.value == ""){
		alert ("Lütfen Bir İlçe Seçiniz.");
		document.fekleform.ilce.focus();
		return false;
	}
	
	
	
	  if (document.fekleform["fsektor[]"].value == "")
    {
    alert ('Lütfen en az bir sektör seçiniz.') ;
	document.fekleform.s8.focus();
	 return false; 
	}
	
	


	
	
	 }

</script>



 <?php if( !empty ($_POST['fsubmit'] ) )
		  {
			  //Upload sınıfı yükleniyor
			  include("include/upload.php"); 
			 
			 //POST verileri oluşturuluyor
			  $f_kayitno=rand(1000000,9999999);
			  
			  $username=temizle($_POST['username2']);
			  $password=temizle($_POST['password']);
			  $yenipass=md5($password);
			  
			  $f_adi=temizle($_POST['f_adi']);
			  $f_yetkili=temizle($_POST['f_yetkili']);
			  $f_detay=addslashes($_POST['detay']);
			  $f_adres=$_POST['f_adres'];
			
			  $f_sehir=intval($_POST['sehir']);
			  $sql=mysql_query("SELECT ad from sehir where id='$f_sehir' limit 0,1");
			  $sehiradi=mysql_fetch_row($sql);
			  $sehiradi=$sehiradi['0'];
			 			
			  $f_email=temizle($_POST['f_email']);
			  $f_logo=$logoismi;
			  $f_web=$_POST['f_web'];
			  $f_face=$_POST['f_face'];
			  $f_tel=$_POST['f_tel'];
			  $f_fax=$_POST['f_fax'];
			  
			  $vlink=$_POST['vlink'];
			  $ilce=intval($_POST['ilce']);
			   
			   
			  
			  $f_etiket=temizle($_POST['f_etiket']).",".$sehiradi;
		
			  $f_paket=intval($_POST['f_paket']);
			  
			  
			  $f_tarih=time();
			  $koordinat=area($_POST['koordinat']);
			  $zoom=intval($_POST['zoom']);
			  //Sanaltur işaretlendiyse 1 işaretlenmediyse 1 değeri veriliyor
		      // if(isset($_POST['f_sanaltur']) &&  $_POST['f_sanaltur'] == 'Evet'){$f_sanaltur=1;} else { $f_sanaltur=0; }   
              $f_cep=$_POST['f_cep'];
			  
			  
			  
			  
switch ( $f_paket ) {
case 1:
    
	$sek_adet=1;
	$turadi="Normal";
	$nbas=time();
	$nbit=$nbas+31556926;
	 break;
	
case 2:
    $sek_adet=3;
	$turadi="Gümüş";
	$gbas=time();
	$gbit=$gbas+31556926; 
    break;
	
case 3:
    $sek_adet=5;
	$turadi="Altın";
	$abas=time();
	$abit=$abas+31556926;
    break;
	
default:
  $sek_adet=1;
  $turadi="Normal";
  $nbas=time();
  $nbit=$nbas+31556926;
  break;
   
}

			  
/////////////FİRMA   EKLENİYOR////////////////////////////////////////			  
$fekle=mysql_query("INSERT INTO firma (id,adi, yetkili, detay,adres,sehir, ilce, email,web,face,tel,fax,etiket,logo,uyeliktur,bastarih,onay,cep,kod,username, password, video, koordinat, zoom,normal_bas,normal_bit,gumus_bas,gumus_bit,altin_bas,altin_bit)
VALUES ('','$f_adi', '$f_yetkili', '$f_detay',  '$f_adres','$f_sehir', '$ilce', '$f_email','$f_web', '$f_face' , '$f_tel','$f_fax','$f_etiket','$f_logo','$f_paket','$f_tarih','1','$f_cep','$f_kayitno', '$username' ,'$yenipass', '$vlink' ,'$koordinat' ,'$zoom' ,'$nbas','$nbit', '$gbas', '$gbit', '$abas', '$abit')");
if($fekle) {
	 echo "<div class='valid_box'>Firma Veritabanına Eklendi</div>";
	  echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fliste'> ";
	  } else { echo "<div class='error_box'>Firma Veritabanına Eklenemedi.</div>";}

/////////////Eklenen firmanın ID'si Çekiliyor////////////////////////////////////////
$sorgu=mysql_query("SELECT id from firma where kod='$f_kayitno' order by bastarih desc limit 0,1");
while($array=mysql_fetch_array($sorgu)){
$r_fid=$array['id'];


/////////////Eğer video linki eklneidyse 11 karakter ise youtube 11 değilse vimeodur ////////////////////////////////////////
 
 


/////////////SEKTÖRLER  EKLENİYOR////////////////////////////////////////

$sektoral=$_POST['fsektor'];
$gelensektor=count($sektoral);
if($gelensektor>$sek_adet)
{
echo "<script>alert(' $turadi üyeliklerde firmanızı aynı anda en fazla $sek_adet adet sektöre ekleyebilirsiniz. Biz bunun farkında olduğunuzu düşünerek şu an sektörleri ekledik ama eğer unuttuysanız lütfen bu firmayı düzenleyerek sektör sayısını azaltınız. ');</script>";
$sektoral=$_POST['fsektor'];
if ($sektoral){foreach ($sektoral as $ustid){
$sektorekle=mysql_query("INSERT INTO sektor (s_id,s_fid,s_ustid) VALUES ('','$r_fid','$ustid')");
if($sektorekle) { echo "<div class='valid_box'>Sektörler Eklendi.</div>"; } else { echo "<div class='error_box'>Sektörler Eklenemedi.</div>";}

}}

}
else
{
$sektoral=$_POST['fsektor'];
if ($sektoral){foreach ($sektoral as $ustid){
$sektorekle=mysql_query("INSERT INTO sektor (s_id,s_fid,s_ustid) VALUES ('','$r_fid','$ustid')");
if($sektorekle) { echo "<div class='valid_box'>Sektörler Eklendi.</div>"; } else { echo "<div class='error_box'>Sektörler Eklenemedi.</div>";}

}}
}

/////////////SANALTUR  EKLENİYOR////////////////////////////////////////
//if(isset($_POST['f_sanaltur']) &&  $_POST['f_sanaltur'] == 'Evet')
//{
//$sanalekle=mysql_query("INSERT INTO panomik (p_id,p_fid,p_onay) VALUES ('','$r_fid','1') ");
//if($sanalekle) { echo "<div class='valid_box'>Sanal Tur Eklendi. Dosyları yüklemeyi unutmayınız.</div>"; } 
//else { echo "<div class='error_box'>Sanal Tur Veritabanına Eklenemedi.</div>";} }
//////////////////////////////////////////////////////////////////////////


/////////////FİRMA RESİMLERİ  EKLENİYOR////////////////////////////////////////

$resimbul=explode("-",$resim);
$say=count($resimbul);
$yeni=$say-1;
for($i=0;$i<$yeni;$i++)
{
$resekle=mysql_query("INSERT INTO firmaresim (id,fid,firmaresim,onay) VALUES ('','$r_fid','$resimbul[$i]','1') ");
if($resekle) { echo "<div class='valid_box'>Firma Resimleri Eklendi.</div>"; } else { echo "<div class='error_box'>Firma Resimleri Eklenemedi.</div>";}
}

 
		  }// r_fid kapat
		  }// submit post kapat
		  ?>
          
   
<h2>Firma Ekle</h2>
<div class="form">
<form name="paket" enctype="multipart/form-data"   method="post" onSubmit="return check_fekle()" action="index2.php?pg=fekle">
<fieldset>
<dl>
                         <dt><label for="paket">Üyelik Tipi:</label></dt>
                         <dd><select name="paket" id="paket" class="text" onchange="this.form.submit();" >
						    <option value="" >Lütfen Bir Üyelik Tipi Seçiniz</option> <?php
						    $sql="SELECT tip_adi,id from uyeliktur order by id asc;";
						    $sorgu=mysql_query($sql);
						    while($tip=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $tip['id']; ?>" <?php if($_POST['paket']==$tip['id']) { echo "selected='selected'";} ?>><?php echo $tip['tip_adi']; ?></option>
                            <?php }?></select></dd>
                     </dl>
                     </fieldset>
                     <input type="hidden" name="basla"  value="dolu"/>
</form>

<?php if(!empty($_POST['basla']) ){
	$paket=intval($_POST['paket']);
	?>


         <form action="index2.php?pg=fekle" enctype="multipart/form-data" onSubmit="return check_fekle()" id="fekleform" name="fekleform"  method="post">
         
                <fieldset>
             
                       <h2>Kullanıcı Bilgileri</h2>
                       
                       
                    <dl>
                        <dt><label for="username2">Kullanıcı Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['username2']; ?>" class="text" name="username2" id="username2" /><br />
                        <div id="status" style="margin-left:10px"></div></dd>
                    </dl>
                  
                    
                    
                  
                    
                    <dl>
                        <dt><label for="password">Şifre:</label></dt>
                        <dd><input type="password" value="" class="text" name="password" id="password" /></dd>
                    </dl>
                    
                    
                                        
                    <dl>
                        <dt><label for="confirm_password">Şifre Tekrar:</label></dt>
                        <dd><input type="password" value="" class="text" name="confirm_password" id="confirm_password" /></dd>
                    </dl>
                    
                    <h2>Firma Bilgileri</h2>
                    <dl>
                        <dt><label for="f_adi">Firma Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['f_adi']; ?>" class="text" name="f_adi" /></dd>
                    </dl>
                    
                                     
                    
                    <dl>
                        <dt><label for="f_yetkili">Yetkili Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['f_yetkili']; ?>" class="text" name="f_yetkili" /></dd>
                    </dl>
                    
                    
                       <dl>
                        <dt><label for="f_email">Email:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['f_email']; ?>" class="text" name="f_email" /></dd>
                    </dl>
                    
                                   
                    
                    <dl>
                        <dt><label for="f_adres">Adres:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['f_adres']; ?>" class="text" name="f_adres" /></dd>
                    </dl>
                    
                    
                    
                       <dl>
                        <dt><label for="sehir">Şehir :</label></dt>
                        <dd><select name="sehir" id="sehir" >
				  
				    <option value="" >--Seçiniz</option> 

<?php  
$sql="SELECT ad,id from sehir order by ad asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  ?>  
<option  value="<?php echo $array['id'] ;?>"  > <?php echo $array['ad']; ?> </option>  
<?  }  ?>  
		        </select></dd>
                    </dl>
                    
                                        
                       <dl>
                        <dt><label for="ilce">İlçe:</label></dt>
                        <dd><select name="ilce" id="ilce" >
				   <option value="" >Önce şehir seçiniz</option> 
				      <?php  
$sql="SELECT ilce_adi,sehir,ilceid from ilce order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  ?>  
<option  value="<?php echo $array['ilceid'] ;?>" class="<?php echo $array['sehir'];?>"  > <?php echo $array['ilce_adi']; ?> </option>  

<?  
}  
?>  
          </select></dd>
                    </dl>
                    
                
                     
                    <dl>
                        <dt><label for="f_tel">Telefon:</label></dt>
                        <dd><input id="telmask" type="text" value="<?php echo $_POST['f_tel']; ?>" class="text" name="f_tel" /></dd>
                    </dl>
                    
                    
                    
                    
                    <dl>
                        <dt><label for="f_cep">Cep Tel:</label></dt>
                        <dd><input id="cepmask"  type="text" value="<?php echo $_POST['f_cep']; ?>" class="text" name="f_cep" /></dd>
                    </dl>
                    
                    
                    
                    <dl>
                        <dt><label for="f_fax">Fax:</label></dt>
                        <dd><input id="faxmask" type="text" value="<?php echo $_POST['f_fax']; ?>" class="text" name="f_fax" /></dd>
                    </dl>
                    
                      <dl>
                        <dt><label for="f_etiket">NOT:</label></dt>
                        <dd style=" color:#F36">Etiketler arasına virgül "," koyunuz. Şehir Adı otomatik eklenecektir.</dd>
                    </dl>
                       <dl>
                        <dt><label for="f_etiket">Etiketler:</label></dt>
                        <dd><input type="text" value="<?php echo $_POST['f_etiket']; ?>" class="text" name="f_etiket" /></dd>
                    </dl>
                    
                    
                    
                    
                    <dl>
                         <dt><label for="fsektor">Sektör Seçiniz:</label></dt>
                         <dd><select   name="fsektor[]" id="s8"  multiple="multiple"  />
                       
                                                       <?php
						    $sql="SELECT ust_adi,ust_id from ustkat order by ust_adi asc;";
						    $sorgu=mysql_query($sql);
						    while($sektorler=mysql_fetch_assoc($sorgu))
							{?><option  value="<?php echo $sektorler['ust_id']; ?>"><?php echo $sektorler['ust_adi']; ?></option><?php }?>
                           </select></dd>
                    </dl>
                    
                     <h2>Logo Yükleme</h2>   
                      <dl>  
                           <dt><label for="f_logo">Logo :</label></dt>
                           <dd><input type="file"  name="f_logo" value="" />  </dd>
                      </dl>
                    
                    
                   <?php if($_POST['paket']!=1) {?>
                    
                        
                        <div  style="margin-bottom:10px"></div> 
                                 
                      <h2>Firma Detayları</h2>      
                      <label for="detay"></label>
                      <textarea id="noise" name="detay"></textarea>
                      <script type="text/javascript" src="../js/ckayar.js"></script>
                      
                      
                    
                 
                    
                    
                     <dl>
                        <dt><label for="f_web">Web Adresi:</label></dt>
                        <dd>http://<input type="text" value="<?php echo $_POST['f_web']; ?>" class="text" name="f_web" /></dd>
                    </dl>
                    
                                 <dl>
                        <dt><label for="f_face">Facebook Adresi:</label></dt>
                        <dd>http://<input type="text" value="<?php echo $_POST['f_face']; ?>" class="text" name="f_face" /></dd>
                    </dl>
                    
                                       
                    
                       <div style="clear:both; margin-bottom:10px"></div>  
       
                                   
                    
                    <h2>Firma Resimleri</h2>
                                   
                      <dl>
                      
                           
                            <dt><label for="f_1">Fotoğraf-1:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_2">Fotoğraf-2:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_3">Fotoğraf-3:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_4">Fotoğraf-4:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_5">Fotoğraf-5:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_6">Fotoğraf-6:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_7">Fotoğraf-7:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_8">Fotoğraf-8:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            <dt><label for="f_9">Fotoğraf-9:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /></dd>
                            
                            
                            
                            
                            <dt><label for="f_10">Fotoğraf-10:</label></dt><dd>  <input type="file" size="32" name="my_field[]" value="" /> <input type="hidden" name="actionmulti" value="multiple" /></dd>
                         
                      </dl>
                            
                      
                        <div  style="margin-bottom:10px"></div> 
                           
                      
                        <h2>Video Ekleme</h2> 
                      <dl>  
                           <dt><label for="vlink">Video Adresi [Embed Kod]:</label></dt>
                           <dd><input type="text" class="text" name="vlink" />  </dd>
                      </dl>
                          
            <div  style="margin-bottom:10px"></div>               
                             
             
                                    
                      
                           <?php // include("gmap.php"); ?>   
                              
                                                                                                           
                                            
                          <?php }?>               
                     <dl class="submit">
                     <input type="hidden" name="f_paket" value="<?php echo $_POST['paket']; ?>" />
                 
                    <input type="submit" name="fsubmit" id="submit" value="Firmayı Kaydet" />
                     </dl>
                                        
                    
                </fieldset>
        
        <input type="hidden" name="actionlogo" value="logo" />
		               
         </form>
         
         <?php }?>
         
                  </div>
     
         
        
		  
          <?php } //üye kontrol kapat?>

          
 

	  
