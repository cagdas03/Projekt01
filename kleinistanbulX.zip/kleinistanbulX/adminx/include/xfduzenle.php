 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
 <link rel="stylesheet" type="text/css" href="css/ui.dropdownchecklist.themeroller.css">
 <script type="text/javascript" src="js/uicustom.js"></script>
 <script type="text/javascript" src="js/ui.dropdownchecklist-1.1-min.js"></script>
 <script type="text/javascript">
 $(document).ready(function() {
 $("#s8").dropdownchecklist( { emptyText: "Lütfen Seçiniz...", width: 295 } );        
 });
 </script>
<script src="../Scripts/swfobject.js" type="text/javascript" ></script>

          
         
<script language="JavaScript">
function check_fekle(){
	
	if (document.paket.paket.value == ""){
		alert ("Lütfen Üyelik Tipi Seçiniz.");
		document.paket.paket.focus();
		return false;  
	}
	
	if (document.fekleform.username.value == ""){
		alert ("Lütfen Kullanıcı Adı Yazınız.");
		document.fekleform.username.focus();
		return false;  
	}
	
	if (document.fekleform.password.value == ""){
		alert ("Lütfen Şifre Yazınız.");
		document.fekleform.password.focus();
		return false;  
	}
	
	if (document.fekleform.f_adi.value == ""){
		alert ("Lütfen Firma Adını Yazınız.");
		document.fekleform.f_adi.focus();
		return false;  
	}
	
	if (document.fekleform.f_adi.value.length<3 || document.fekleform.f_adi.value.length>200){
		alert ("Firma adınız 3 karakterden az, 200 karakterden fazla olmamalıdır.");
		document.fekleform.f_adi.focus();
		return false; 	
	}
	
		
		if (document.fekleform.f_adres.value == ""){
		alert ("Lütfen Firmanızın Sokak Adı ve Numarasını Yazınız.");
		document.fekleform.f_adres.focus();
		return false;  
	}
	
	

		if (document.fekleform.f_sehir.value == ""){
		alert ("Lütfen Bir Şehir Seçiniz.");
		document.fekleform.f_sehir.focus();
		return false;
	}
	
	
  if (document.fekleform["fsektor[]"].value == "")
    {
    alert ('Lütfen en az bir sektör seçiniz.') ;
	 return false; 
	}
	
	 }

</script>

<?php 
//id ye göre firma bilgilerini çekelim.
$fid=$_GET['fid'];
$sorgu=mysql_query("SELECT firma.uyeliktur, uyeliktur.tip_adi,firma.adi,firma.yetkili,firma.adres, firma.ilce, sehir.ad,firma.sehir,firma.tel,firma.cep,firma.fax, firma.face,firma.email, firma.username, firma.password, firma.web,firma.etiket,firma.logo,firma.detay, firma.video, firma.koordinat, firma.zoom from firma inner join sehir on sehir.id=firma.sehir inner join uyeliktur on uyeliktur.id=firma.uyeliktur where firma.id='$fid' limit 0,1 ") or die(mysql_error());
$duzen=mysql_fetch_assoc($sorgu);
?>
<?php
$islem=$_GET['islem'];
switch($islem){

case "paketdegis":
$fid=$_GET['fid'];
$paket=$_GET['paket'];
$paketdegis=mysql_query("UPDATE firma set uyeliktur=$paket where id='$fid'");
   echo "<div class='valid_box'>Paket Değiştirildi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fduzenle&fid=$fid'> ";
break;
case "resimsil":
$fid=$_GET['fid'];
$rid=$_GET['rid'];
$resimyol=mysql_fetch_row(mysql_query("SELECT firmaresim from firmaresim where id='$rid' limit 0,1"));
$ryol=$resimyol['0'];
@unlink("../uploads/firmaresim/$ryol");
$resimsil=mysql_query("DELETE from firmaresim where id='$rid'");
   echo "<div class='valid_box'>Resim Silindi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fduzenle&fid=$fid'> ";
 break;
 

 case "logosil":
$fid=$_GET['fid'];
$logoyol=mysql_fetch_row(mysql_query("SELECT logo from firma where id='$fid' limit 0,1"));
$logoyol=$logoyol['0'];
@unlink("../uploads/logo/$logoyol");
$logosil=mysql_query("UPDATE firma set logo='' where id='$fid'");
   echo "<div class='valid_box'>Logo Silindi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fduzenle&fid=$fid'> ";
 break;
 
default:

}
?>

        <?php if( !empty ($_POST['fsubmit'] ) )
		  {
			  //Upload sınıfı yükleniyor
			  include("include/upload.php"); 
			 
			 //POST verileri oluşturuluyor
			  $fid=$_POST['f_id'];
			  $f_adi=$_POST['f_adi'];
			  $username=$_POST['username2'];
			  //Şİfre işlemleri
			  $password=$_POST['password'];
			  if(strlen($password)==32)
			  {
				 $yenipass=$password; 
				 }
				 else
				 {
			     $yenipass=md5($password);
					 }
			  $f_yetkili=temizle($_POST['f_yetkili']);
			  $f_detay=addslashes($_POST['detay']);
			  $f_adres=temizle($_POST['f_adres']);
			  $f_sehir=temizle($_POST['sehir']);
			  $ilce=temizle($_POST['ilce']);
			  $f_email=area($_POST['f_email']);
			    			  
			  $f_web=$_POST['f_web'];
			   $face=$_POST['face'];
			  $f_tel=$_POST['f_tel'];
			  $f_fax=$_POST['f_fax'];
			  $f_etiket=$_POST['f_etiket'];
			 //$f_paket=$_POST['f_paket'];
			 	
			  $vlink=$_POST['vlink'];
			  $koordinat=$_POST['koordinat'];
			  $zoom=temizle($_POST['zoom']);
						      
              $f_cep=$_POST['f_cep'];
			  $uyeliktur=$_POST['f_paket'];
	
			  $sorgu=mysql_query("SELECT logo from firma where id='$fid' limit 0,1");
			  $sec=mysql_fetch_row($sorgu);
			  if($_FILES['f_logo']['name']==''){ $f_logo=$sec['0'];} else { $f_logo=$logoismi;}
				
				
						  
/////////////FİRMA   DÜZENLENİYOR////////////////////////////////////////		




$fedit=mysql_query("
             UPDATE firma SET 
 adi='$f_adi', 
 password='$yenipass',
 detay='$f_detay',  
 adres='$f_adres', 
 sehir='$f_sehir', 
 ilce='$ilce',  
 email='$f_email', 
 web='$f_web', 
 face='$face', 
 tel='$f_tel', 
 fax='$f_fax', 
 etiket='$f_etiket', 
 logo='$f_logo', 
 cep='$f_cep', 
 yetkili='$f_yetkili', 
 video='$vlink' ,
 koordinat='$koordinat',
 zoom='$zoom',
 uyeliktur='$uyeliktur'
              WHERE id='$fid'");
if($fedit) { echo "<div class='valid_box'>Firma Başarıyla Düzenlendi</div>"; } else { echo "<div class='error_box'>Firma Düzenlenemedi.</div>";}



/////////////SEKTÖRLER  EKLENİYOR////////////////////////////////////////
$sektoral=$_POST['fsektor'];
$sektorsilold=mysql_query("DELETE from sektor where s_fid='$fid'");
if ($sektoral){foreach ($sektoral as $ustid){
// Önce eskileri silelim
// Yeni esktörleri ekleyelim.
$sektorekle=mysql_query("INSERT INTO sektor (s_id,s_fid,s_ustid) VALUES ('','$fid','$ustid')");
if($sektorekle) { echo "<div class='valid_box'>Sektörler Düzenlendi.</div>"; } else { echo "<div class='error_box'>Sektörler Düzenlenemedi.</div>";}
}}

/////////////SANALTUR  DÜZENLENİYOR////////////////////////////////////////
//if(isset($_POST['f_sanaltur']) &&  $_POST['f_sanaltur'] == 'Evet')
//{
//$sanaledit=mysql_query("DELETE FROM panomik WHERE p_fid='$fid' ");
//if($sanaledit) { echo "<div class='valid_box'>Sanal Tur Silindi. Dosyaları silmeyi unutmayınız.</div>"; } else { echo "<div class='error_box'>Sanal Tur Silme İşlemi Başarısız Oldu.</div>";}
//}


/////////////FİRMA RESİMLERİ  DÜZENLENİYOR////////////////////////////////////////

$resimbul=explode("-",$resim);
$say=count($resimbul);
$yeni=$say-1;
for($i=0;$i<$yeni;$i++)
{
$resekle=mysql_query("INSERT INTO firmaresim (id,fid,firmaresim,onay) VALUES ('','$fid','$resimbul[$i]','1') ");
if($resekle) { echo "<div class='valid_box'>Firma Resimleri Eklendi.</div>"; } else { echo "<div class='error_box'>Firma Resimleri Eklenemedi.</div>";}
}


	
	
	
  echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=fduzenle&fid=$fid'> ";

		  }// submit post kapat
		  ?>
          
          

<h2>Firma Düzenleme</h2>
<div class="form">
<form name="paket"  method="GET" onSubmit="return check_fekle()" action="index2.php">

<fieldset>

<dl>
                         <dt><label for="paket">Üyelik Tipi:</label></dt>
                         <dd><select name="paket" id="paket" class="text" onchange="this.form.submit();" >
						    <option value="" >Lütfen Bir Üyelik Tipi Seçiniz</option><?php
						    $sql="SELECT tip_adi,id from uyeliktur order by id asc limit 0,3;";
						    $sorgu=mysql_query($sql);
						    while($tip=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $tip['id']; ?>" <?php if($duzen['uyeliktur']==$tip['id']) { echo "selected='selected'";} ?>><?php echo $tip['tip_adi']; ?></option>
                            <?php }?></select></dd>
                     </dl>
                     
                     <input type="hidden" name="islem" value="paketdegis" />
                     <input type="hidden" name="pg" value="fduzenle" />
                      <input type="hidden" name="fid" value="<?php echo $_GET['fid']; ?>" />
                      
                      </fieldset>
</form>


         <form action="index2.php?pg=fduzenle" enctype="multipart/form-data" onSubmit="return check_fekle()" id="fekleform" name="fekleform"  method="post">
         
               <fieldset> 
                    <h2>Kullanıcı Bilgileri</h2>
                    
                     <dl>
                        <dt><label for="username2">Kullanıcı Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['username']; ?>" disabled="disabled" class="text" name="username" id="username" /><br />
                        <div id="status" style="margin-left:10px"></div></dd>
                    </dl>
                  
                    
                    
                  
                    
                    <dl>
                        <dt><label for="password">Şifre:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['password']; ?>" class="text" name="password" id="password" /></dd>
                    </dl>
                    
                     <h2>Firma Bilgileri</h2>
                    
                    <dl>
                        <dt><label for="f_adi">Firma Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['adi']; ?>" class="text" name="f_adi" /></dd>
                    </dl>
                    
                    
                    
                    
                    <dl>
                        <dt><label for="f_yetkili">Yetkili Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['yetkili']; ?>" class="text" name="f_yetkili" /></dd>
                    </dl>
                    
                              
                        <dl>
                        <dt><label for="f_email">Email:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['email']; ?>" class="text" name="f_email" /></dd>
                    </dl>
                    
                    
                    <dl>
                        <dt><label for="f_adres">Adres:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['adres']; ?>" class="text" name="f_adres" /></dd>
                    </dl>
                    
                  
                    
                     <dl>
                        <dt><label for="sehir">Şehir :</label></dt>
                        <dd><select name="sehir" id="sehir" >
				  
				    <option value="" >--Seçiniz</option> 

<?php  
$sql="SELECT ad,id from sehir order by ad asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  ?>  
<option  value="<?php echo $array['id'] ;?>" <?php if($duzen['sehir']==$array['id']) { echo "selected='selected'" ;} ?> > <?php echo $array['ad']; ?> </option>  
<?  }  ?>  
		        </select></dd>
                    </dl>
                    
                                        
                       <dl>
                        <dt><label for="ilce">İlçe:</label></dt>
                        <dd><select name="ilce" id="ilce" >
				   <option value="" >Önce şehir seçiniz</option> 
				      <?php  
$sql="SELECT ilce_adi,sehir,ilceid from ilce order by ilce_adi asc";  
$sorgu=mysql_query($sql);  
while($array=mysql_fetch_array($sorgu))  
{  ?>  
<option  value="<?php echo $array['ilceid'] ;?>" class="<?php echo $array['sehir'];?>" <?php if($duzen['ilce']==$array['ilceid']) { echo "selected='selected'" ;} ?> > <?php echo $array['ilce_adi']; ?> </option>  

<?  
}  
?>  
          </select></dd>
                    </dl>
                   
               
                                        
                     
                    <dl>
                        <dt><label for="f_tel">Telefon:</label></dt>
                        <dd><input id="telmask" type="text" value="<?php echo $duzen['tel']; ?>" class="text" name="f_tel" /></dd>
                    </dl>
                    
                    
                    
                    
                    <dl>
                        <dt><label for="f_cep">Cep Tel:</label></dt>
                        <dd><input id="cepmask" type="text" value="<?php echo $duzen['cep']; ?>" class="text" name="f_cep" /></dd>
                    </dl>
                    
                    
                    
                    <dl>
                        <dt><label for="f_fax">Fax:</label></dt>
                        <dd><input id="faxmask" type="text" value="<?php echo $duzen['fax']; ?>" class="text" name="f_fax" /></dd>
                    </dl>
                    
                    
                    
                   
                    
                    
                        <dl>
                        <dt><label for="f_etiket">NOT:</label></dt>
                        <dd style=" color:#F36">Etiketler arasına virgül "," koyunuz. Faklı kelimeler kullanınız</dd>
                    </dl>
                       <dl>
                        <dt><label for="f_etiket">Etiketler:</label></dt>
                        <dd><input type="text" value="<?php echo $duzen['etiket']; ?>" class="text" name="f_etiket" /></dd>
                    </dl>
                    
                    
                    
                    
                    <dl>
                         <dt><label for="fsektor">Sektör Seçiniz:</label></dt>
                         <dd><select   name="fsektor[]" id="s8"  multiple="multiple"  />
                                                       <?php

													   
						    $sql="SELECT ust_adi,ust_id from ustkat order by ust_adi asc;";
						    $sorgu=mysql_query($sql);
						    while($sektorler=mysql_fetch_assoc($sorgu))
							{								
$seksorgu=mysql_query("SELECT sektor.s_ustid from sektor  where sektor.s_fid='$fid'") or die(mysql_error());?>

<option  value="<?php echo $sektorler['ust_id']; ?>" <?php while($sektorfid=mysql_fetch_assoc($seksorgu)) { if($sektorler['ust_id']==$sektorfid['s_ustid']) { echo "selected='selected'"; }} ?> ><?php echo $sektorler['ust_adi']; ?></option>
                            
                            
                            <?php } // firmaya ait sektör listesinin kapanışı?>
                           </select></dd>
                    </dl>
                                
                    
                    
                       <div style="clear:both; margin-bottom:10px"></div>  
       
                                   
                    
                    <h2>Logo Yükleme</h2>
                    
                    
                         <dl><dt><label>Logo:</label></dt><dd   style="height:50px;">
						   <?php if(!empty($duzen['logo'])) {?>   <img src="../uploads/logo/<?php echo $duzen['logo'];?>" width="80" height="50" border="0"><a href="index2.php?pg=fduzenle&islem=logosil&fid=<?php echo $_GET['fid']; ?>" style="margin:5px" class="ask"><img src="images/delete.png" alt="Sil" /></a></dd>  <?php } else {?>
                           <input type="file"  name="f_logo" value="" /> </dd>
                       <?php }?>
                      </dl>
                      
                      <div <?php if($_POST['paket']==1 || $duzen['uyeliktur']==1 ) { echo "style='display:none'"; } ?> >
                      
                                   
                                   <h2>Firma Detayları</h2>      
                        <label for="detay"></label>
                      <textarea id="noise" name="detay" ><?php echo stripslashes($duzen['detay']); ?></textarea>
                         <script type="text/javascript" src="../js/ckayar.js"></script>
                       
             
                    
                    
                     <dl>
                        <dt><label for="f_web">Web Adresi:</label></dt>
                        <dd>http://<input type="text" value="<?php echo $duzen['web']; ?>" class="text" name="f_web" /></dd>
                    </dl>
                       
                                    
                                    
                                       <dl>
                        <dt><label for="face">Facebook Adresi:</label></dt>
                        <dd>http://<input type="text" value="<?php echo $duzen['face']; ?>" class="text" name="face" /></dd>
                    </dl>          
                      
                      
                      <h2>Firma  Resimleri</h2> 
                      
                        
                            
                            	<?php 
					$sql="SELECT firmaresim, id from firmaresim where fid='$fid' limit 0,10";
					$sorgu=mysql_query($sql) or die(mysql_error());
					$say=mysql_num_rows($sorgu);
					$i=1;
					while ($row=mysql_fetch_assoc($sorgu))
					{
					?>
                    <dl>
                    <dt>
                    <label for="f_<?php echo $i; ?>">Fotoğraf-<?php echo $i; ?>:</label>
                    </dt>
                    <dd   style="height:50px;">
                    <img src="../uploads/firmaresim/<?php echo $row['firmaresim'];?>" width="80" height="50" border="0">
                    <a href="index2.php?pg=fduzenle&islem=resimsil&fid=<?php echo $_GET['fid']; ?>&rid=<?php echo $row['id'] ;?>" class="ask">
                    <img src="images/delete.png" style="margin:5px" alt="Sil" /></a>
                    </dd>
                    </dl>
                    
                    <? $i++; } //Resim varsa yukarıda kaç reim varsa önzilemesiyle göster ?>	
					<?php $say++; for($say;$say<=10;$say++) { ?>
                    <dl>
                    <dt><label for="f_<?php echo $say;?>">Fotoğraf-<?php echo $say;?>:</label></dt>
                    <dd   style="height:50px;">  <input type="file" size="32" name="my_field[]"  />
                    <input type="hidden" name="actionmulti" value="multiple" />
                    </dd>
                     </dl>
                    <?php }?>
                      
                     
                   
                          
                         <div  style="margin-bottom:10px"></div> 
                           
                      
                        <h2>Video Ekleme</h2> 
				
                           
                      <dl><dt>NOT:</dt><dd style=" color:#F36">Video embed kodunu yapıştırınız. (Youtube, vimeo..) [width:730 height:500]</dd></dl>
                    <dl>
                    <dt><label for="vlink">Video Embed Kodu:</label></dt>
                    <dd   style="height:70px;"> <textarea style="width:400px; height:70px" name="vlink"><?php echo $duzen['video'];?></textarea>
                                   </dd>
                     </dl>



                 <div  style="margin-bottom:10px"></div>               
                             
             
                                    
                      
                           <?php // include("gmap.php"); ?>   
                           
                           

                    
                    
                    
                      
                         
                             
                            </div>  
                      
                                                    
                    <div  style="margin-bottom:10px; display:block; clear:both"></div>            
                       
                                      
                           
                           
                     <dl class="submit">
                     <input type="hidden" name="f_paket" value="<?php echo $duzen['uyeliktur']; ?>" />
                     <input type="hidden" name="f_id" value="<?php echo $_GET['fid']; ?>" />
                    <input type="submit" name="fsubmit" class="google" id="submit" value="Düzenle" />
                     </dl>
                                     
                    
              
             </fieldset>      
         
        <input type="hidden" name="actionlogo" value="logo" />
	
              
         </form>
         </div>

         
         
 
		  
          <?php } //üye kontrol kapat?>