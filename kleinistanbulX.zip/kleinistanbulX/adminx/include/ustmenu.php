<?php
 //Onaysız firma say
$sql="SELECT adi, onay, bastarih from firma where onay=0 ";
$sorgu=mysql_query($sql) or die(mysql_error());
$f_say=mysql_num_rows($sorgu);


$ontopla=($f_say);

?>

                <div class="menu">
                    <ul>
                    <li><a class="current" href="index2.php">Admin Anasayfa</a> </li>
                    <li><a class="current" href="index2.php?pg=onay">
                    <?php if($ontopla>0) { echo "<font color='#9D0000'><strong>Onay Bekleyenler ($ontopla)</strong></font>";} else {?>
                    Onay Bekleyenler <?php }?></a></li>
                    <li><a class="current" href="index2.php?pg=fekle">Yeni Firma Ekle</a></li>
                    <li><a class="current" href="index2.php?pg=stats">İstatistikler</a></li>
                    </ul>
                    </div> 