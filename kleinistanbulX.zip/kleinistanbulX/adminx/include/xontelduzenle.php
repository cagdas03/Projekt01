<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT o_adi,o_tel,o_sehir from ontel where o_id='$sid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>
 
     <script language="JavaScript">
function check_oduzenle(){
	
			if (document.ontelform.o_adi.value == ""){
		alert ("Lütfen bir ad yazınız.");
		document.ontelform.o_adi.focus();
		return false;  
	}
	
				if (document.ontelform.o_tel.value == ""){
		alert ("Lütfen bir telefon numarası yazınız.");
		document.ontelform.o_tel.focus();
		return false;  
	}
	
	
	
	if (document.ontelform.o_sehir.value == ""){
		alert ("Lütfen Bir Şehir Seçiniz.");
		document.ontelform.o_sehir.focus();
		return false;  
	}
	

	
	 }

</script>

<div class="form">

<form method="post" action="index2.php?pg=ontel&islem=ontelduzenle&sid=<?php echo $sid;?>" onSubmit="return check_oduzenle()" id="ontelform" name="ontelform" >
     <h2>Önemli Telefon Düzenle</h2>
                        <dl>
                        <dt><label for="o_adi">Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['o_adi']; ?>" class="text" name="o_adi" /></dd>
                        </dl>
                        
                        
                        <dl>
                         <dt><label for="o_tel">Telefon No:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['o_tel']; ?>" class="text" name="o_tel" /></dd>
                        </dl>
                    
                      <dl>
                         <dt><label for="o_sehir">Şehir:</label></dt>
                        <dd><select name="o_sehir" class="text" >
						    <option value="" >Lütfen Bir Şehir Seçiniz</option> <?php
						    $sql="SELECT sehir_id, sehir_adi from sehir order by sehir_adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['sehir_id']; ?>" <?php if($sabitsayfa['o_sehir']==$sehircek['sehir_id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['sehir_adi']; ?></option><?php }?>
                                                        </select></dd>
                      </dl>
                      
                      
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle"  value="Gönder" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$sid=$_GET['sid'];
	$o_adi=$_POST['o_adi'];
	$o_tel=$_POST['o_tel'];
	$o_sehir=$_POST['o_sehir'];

	
	$sektorupdate=mysql_query("UPDATE ontel SET  o_adi='$o_adi',o_tel='$o_tel',o_sehir='$o_sehir' where o_id='$sid' ");
	if($sektorupdate) { echo "<div class='valid_box'>Telefon düzenledi.</div>";} else {echo "Telefon düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='1;URL=index2.php?pg=ontel&islem=ontelduzenle&sid=$sid'> ";
	
	 }?>


      
      
     