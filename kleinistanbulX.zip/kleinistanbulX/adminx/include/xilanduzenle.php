     <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>


	<script language="JavaScript">
function check_sanekle(){
	
			if (document.sekleform.firma.value == ""){
		alert ("Lütfen bir firma seçiniz yazınız.");
		document.sekleform.firma.focus();
		return false;  
	}
	
				if (document.sekleform.baslik.value == ""){
		alert ("Lütfen başlık yazınız.");
		document.sekleform.baslik.focus();
		return false;  
	}
	
	
					if (document.sekleform.tip.value == ""){
		alert ("İlan tipi seçiniz.");
		document.sekleform.tip.focus();
		return false;  
	}
	
	

	
	 }

</script>
<div class="form">

<?php
$id=$_GET['sid'];
$sorgu=mysql_query("SELECT ilan.ilan_baslik, ilan.ilan_detay, ilan.ilan_etiket,  firma.adi, ilan.fid, ilan.tip from ilan inner join firma on firma.id=ilan.fid where ilan.id='$id'") or die(mysql_error());
while($ilan=mysql_fetch_assoc($sorgu))
{
 ?>

<form method="post" action="index2.php?pg=ilanduzenle&sid=<?php echo $id; ?>"  enctype="multipart/form-data" onSubmit="return check_sanekle()" id="sekleform" name="sekleform" >

<fieldset>
     <h2><?php echo $ilan['ilan_baslik']; ?> / <?php  echo $ilan['adi']; ?></h2>
     
             <dl>
                        <dt><label for="firma">Firma Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="firma" >
						    <option value="" >Firma Seç</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($ilan['fid']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
              
              
              <dl>
                        <dt><label for="tip">İlan Tipi</label></dt>
                        <dd> 
                        <select style="width:305px" name="tip" >
						    <option value="" >İlan Tipi Seç</option> <?php
						    $sql="SELECT ilantip.id, ilantip.itip_adi from ilantip  order by ilantip.itip_adi asc";
						    $sorgu=mysql_query($sql) or die(mysql_error());
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($ilan['tip']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['itip_adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
     
     
               <dl>
        				<dt>
        				  <label for="baslik">İlan Başlığı</label></dt>
                        <dd> <input type="text" class="text"  value="<?php echo $ilan['ilan_baslik']; ?>"  name="baslik" />  </dd>
                       
              </dl>
     
     
                
               
        				<label for="detay">İlan Detayı</label>
                        <textarea id="noise" name="detay" ><?php echo stripslashes($ilan['ilan_detay']); ?></textarea> 
                       
             <script type="text/javascript" src="../js/ckayar.js"></script>
              
               
                     
              
               
             <dl>
                        <dt><label for="etiket">Etiketler:</label></dt>
                        <dd><input type="text" class="text" value="<?php echo $ilan['ilan_etiket']; ?>" name="etiket" /></dd>
                    </dl>
      
      
              
                      
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionilan" value="ilan" />
<input type="submit" class="google" name="duzenle"  value="İlanı Düzenle" />

</fieldset>
</form>
<?php }?>
</div>

			   
<?php


 if(!empty($_POST['duzenle'])) {
	
	$firma=temizle($_POST['firma']);
	$baslik=temizle($_POST['baslik']);
	$detay=addslashes($_POST['detay']);
	$fiyat=temizle($_POST['fiyat']);
	$etiket=temizle($_POST['etiket']);
	$tip=intval($_POST['tip']);
		// ekleme yapılıyor
			
				
	$ilanekle=mysql_query("UPDATE  ilan  SET fid='$firma' ,ilan_baslik='$baslik', ilan_detay='$detay',  ilan_etiket='$etiket', tip='$tip' where id='$id' ") or die(mysql_error());
	if($ilanekle) { echo "<div class='valid_box'>Düzenlendi.</div>";} else {echo "Düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilanduzenle&sid=$id'> ";
	
	
	
	} // ilan tur eklenememiş
   
    }// submite basulmışsa
	 
	 ?>


      
      
     