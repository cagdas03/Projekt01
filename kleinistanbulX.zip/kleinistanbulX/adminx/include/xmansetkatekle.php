    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.mkatadi.value == ""){
		alert ("Lütfen ad yazınız.");
		document.ekleform.mkatadi.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=mansetkat&islem=ekle" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2>Yeni Genel Haber Kategorisi Ekle</h2>
     <dl>
                        <dt><label for="mkatadi">Kategori Adı: (Max: 30 karakter)</label></dt>
                        <dd><input type="text" value="" class="text" name="mkatadi" /></dd>
                                             </dl>
                                                                                            
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Genel Haber Kategorisi Ekle" />
</form>
</div>

<?php if(!empty($_POST['hiddenekle'])) {
	$mkatadi=temizle($_POST['mkatadi']);
			
	$sektorekle=mysql_query("INSERT INTO mansetkat (mid,mkatadi) VALUES ('','$mkatadi')") or die(mysql_error());
	if($sektorekle) { echo "<div class='valid_box'>Kategori eklendi.</div>";} else {echo "Genel Haber Kategorisi Eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=mansetkat'> ";
	
	 }?>


      
      
     