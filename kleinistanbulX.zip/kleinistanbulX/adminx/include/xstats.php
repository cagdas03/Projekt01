<?php
//Firmaları say
$sql="select id from firma";
$sorgu=mysql_query($sql) or die (mysql_error());
$xfirmasay=mysql_num_rows($sorgu);


$sql="select id from firma where uyeliktur=3";
$sorgu=mysql_query($sql) or die (mysql_error());
$xgoldsay=mysql_num_rows($sorgu);

$sql="select id from firma where uyeliktur=2";
$sorgu=mysql_query($sql) or die (mysql_error());
$xsilversay=mysql_num_rows($sorgu);

$sql="select id from firma where uyeliktur=1";
$sorgu=mysql_query($sql) or die (mysql_error());
$xstandartsay=mysql_num_rows($sorgu);




//Sektör Say
$sql="select ust_id from ustkat";
$sorgu=mysql_query($sql) or die (mysql_error());
$xseksay=mysql_num_rows($sorgu);





?>

<dl><dt>Firma Sayısı</dt><dd><?php echo $xfirmasay; ?>
<span  class="rayt">
<font color="#CC9900">  Altın Üye: <b> <?php echo $xgoldsay; ?> </b> </font>
<font color="#666666">  Gümüş Üye: <b> <?php echo $xsilversay; ?> </b></font>
<font color="#0099FF">  Normal Üye: <b> <?php echo $xstandartsay; ?> </b></font>
</span>
</dd></dl>


<dl><dt>Sektör Sayısı</dt><dd><?php echo $xseksay; ?></dd></dl>



</dd></dl>




   

