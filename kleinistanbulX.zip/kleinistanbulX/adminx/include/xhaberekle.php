     <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>


	<script language="JavaScript">
function check_sanekle(){
	
			if (document.sekleform.firma.value == ""){
		alert ("Lütfen bir firma seçiniz yazınız.");
		document.sekleform.firma.focus();
		return false;  
	}
	
				if (document.sekleform.baslik.value == ""){
		alert ("Lütfen başlık yazınız.");
		document.sekleform.baslik.focus();
		return false;  
	}
	
	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=haberekle"  enctype="multipart/form-data" onSubmit="return check_sanekle()" id="sekleform" name="sekleform" >

<fieldset>
     <h2>Yeni Haber Ekle (Haber Limiti:<?php echo $iu_limit; ?>)</h2>
     
             <dl>
                        <dt><label for="firma">Firma Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="firma"  onchange="this.form.submit();">
						    <option value="" >Firma Seç</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 and firma.onay=1 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_POST['firma']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
     
     
               <dl>
        				<dt><label for="baslik">Haber Başlığı</label></dt>
                        <dd> <input type="text" class="text"   name="baslik" />  </dd>
                       
              </dl>
     
     
                
               
        				<label for="detay">Haber Detayı</label>
                        <textarea id="noise" name="detay" ></textarea> 
                         <script type="text/javascript" src="../js/ckayar.js"></script>
                       
            
                    
              
               
             <dl>
                        <dt><label for="etiket">Etiketler:</label></dt>
                        <dd><input type="text" class="text" name="etiket" /></dd>
                    </dl>
      
      
              <dl>
        				<dt><label for="f_haber">Haber Resmi</label></dt>
                        <dd> <input type="file"  name="f_haber" /> </dd>
                       
              </dl>
                      
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="hidden" name="actionhaber" value="haber" />
<input type="submit" class="google" name="duzenle"  value="Haber Ekle" />

</fieldset>
</form>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	$firma=$_POST['firma'];
		
		 
	$pano=mysql_query("SELECT id FROM haber where fid='$firma'");
	$saypano=mysql_num_rows($pano);
	if($saypano>( $iu_limit-1)) { 
	echo "<script>alert('En fazla $iu_limit adet haber ekleyebilirsiniz. Limit dolmuş görünüyor. Limiti genel ayarlardan artırabilirsiniz');</script>";
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haberekle'> ";
	exit();
	 }
	else {	
	
	
	include("include/upload.php");
	$baslik=$_POST['baslik'];
	$detay=addslashes($_POST['detay']);
	$etiket=$_POST['etiket'];
	$time=time();
	// ekleme yapılıyor
	$haberekle=mysql_query("INSERT INTO haber (id, fid,haber_baslik, haber_detay,haber_etiket, haberresim, onay, haber_bas_tarih) VALUES ('', '$firma', '$baslik', '$detay','$etiket' ,'$haberismi' ,'1','$time' )") or die(mysql_error());
	if($haberekle) { echo "<div class='valid_box'>Haber eklendi.</div>";} else {echo "Haber eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber'> ";
	
	
	
	} // haber tur eklenememiş
   
    }// submite basulmışsa
	 
}
	 ?>


      
      
     