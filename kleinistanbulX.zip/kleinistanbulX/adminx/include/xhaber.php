<script LANGUAGE="JavaScript">
function confirmSubmit()
{
var agree=confirm("Haber silinecek emin misiniz");
if (agree)
	return true ;
else
	return false ;
}
// -->
</script>


 

 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
    
	<?php
	
	if (isset($_GET['fara']) || isset($_GET['fara_x'])) { } 
	
	$fkelime=$_GET['fkelime'];
	$firma=$_GET['firma'];
	$sehir=$_GET['sehir'];
	$sira=$_GET['sira'];
	
	 $kosul = '';
     if($fkelime > ' '){ $kosul = $kosul . ' and haber.haber_baslik like \'%'.$fkelime.'%\''; }
	 if($sehir> ' '){ $kosul = $kosul . ' and firma.sehir='.$sehir.''; }
	 if($firma> ' '){ $kosul = $kosul . ' and firma.id='.$firma.''; }
	 if($sira > ' ' & $sira=='fadi'){ $kosulsira = $kosulsira . ' order by haber.haber_baslik asc '; }
	 if($sira > ' ' & $sira=='fadi2'){ $kosulsira = $kosulsira . ' order by haber.haber_baslik desc'; }
	  if($sira > ' ' & $sira=='onay'){ $kosulsira = $kosulsira . ' order by haber.onay desc '; }
	   if($sira > ' ' & $sira=='onay2'){ $kosulsira = $kosulsira . ' order by haber.onay asc '; }
	   if($sira > ' ' & $sira=='tarih'){ $kosulsira = $kosulsira . ' order by haber.haber_bas_tarih asc '; }
	     if($sira > ' ' & $sira=='tarih2'){ $kosulsira = $kosulsira . ' order by haber.haber_bas_tarih desc '; }
		if($sira < ' '){ $kosulsira = $kosulsira . ' order by haber.haber_bas_tarih desc '; }
		
		
		
		
	
	
	$tbl_name="haber";		//your table name
	$adjacents = 3;
	$query = "SELECT COUNT(*) as num FROM haber inner join firma on firma.id=haber.fid inner join sehir on sehir.id=firma.sehir where 1 ".$kosul." ";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	
	/* Setup vars for query. */
	$targetpage = "index2.php?pg=haber&fkelime=$fkelime&sehir=$sehir&sira=$sira&firma=$firma"; 	//your file name  (the name of this file)
	$limit = 50; 								//how many items to show per page
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	$sql = "SELECT haber.id, haber.haber_baslik , haber.haberresim,firma.adi, haber.fid, haber.onay from $tbl_name inner join firma on firma.id=haber.fid inner join sehir on sehir.id=firma.sehir where 1 ".$kosul."   ".$kosulsira."  LIMIT $start, $limit";
	$result = mysql_query($sql);
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\">« Geri</a>";
		else
			$pagination.= "<span class=\"disabled\">« Geri</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage&page=$next\">İleri »</a>";
		else
			$pagination.= "<span class=\"disabled\">İleri »</span>";
		$pagination.= "</div>\n";		
	}
?>

  <?php
//İşlemleri aşağıda ypıp uyarı ya da valid değerlerini verelim
//Onaylama İşlemi
$islem=$_GET['islem'];
switch($islem){

case "haberduzenle":
include("xhaberduzenle.php");
break;


case "sil":
$sid=$_GET['sid'];
$page=$_GET['page'];

//Şehir dosyaları klasörden siliniyor
$haberyol=mysql_query("SELECT haberresim FROM haber where id='$sid' ");
while($unhaber=mysql_fetch_assoc($haberyol)){$yol=$unhaber['haberresim']; @unlink("../uploads/haber/$yol"); }
$sil=mysql_query("DELETE from haber where id='$sid'");
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&sehir=$sehir&firma=$firma&sira=$sira&fkelime=$fkelime'> ";
break;


case "onay":
$id=$_GET['id'];
$deger=$_GET['deger'];
$page=$_GET['page'];

if($deger==1){  $uponay=mysql_query("UPDATE haber set onay=0 where id='$id'");
   echo "<div class='valid_box'>Yayın durduruldu.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&sehir=$sehir&firma=$firma&sira=$sira&fkelime=$fkelime'> ";  }
elseif($deger==0) {  $uponay=mysql_query("UPDATE haber set onay=1 where id='$id'");
   echo "<div class='valid_box'>Onaylandı.</div>"; 
   echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&sehir=$sehir&firma=$firma&sira=$sira&fkelime=$fkelime'> "; }
else{echo "<div class='error_box'>Bu ürünün veritabanındaki onay bölümünde tanımlanamayan değerler var.</div>";}
break;



case "ekle":
include("xhaberekle.php");
break;

default:

}

//Seçilenleri Aktif Et/////////////////////

if(isset($_GET['tumonay']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE haber set onay=1 where id in (".implode(',', $comments).")"; 
mysql_query($sql); 

 echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma&sira=$sira'> ";
}

//Seçilenleri Pasif Et/////////////////////
if(isset($_GET['tumiptal']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 
$sql = "UPDATE haber set onay=0 where id in (".implode(',', $comments).")"; 
mysql_query($sql);
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma&sira=$sira'> ";
 }
 


//Seçilenleri Sil/////////////////////
if(isset($_GET['tumsil']) and isset($_GET['comment']) ) {
$comments = $_GET['comment']; 
foreach($comments as $k => $v){  $comments[$k] = intval($v); } 

$resimyol=mysql_query("SELECT haberresim FROM haber where id in (".implode(',', $comments).")");
while($unresim=mysql_fetch_assoc($resimyol)){$ryol=$unresim['haberresim']; @unlink("../uploads/haber/$ryol"); }
$habersil = mysql_query("DELETE FROM haber where id in (".implode(',', $comments).")");

echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=haber&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma&sira=$sira'> ";
}



?>


 
 <form method="GET" action="index2.php">
            
            
                 <select name="firma"  style="width:250px" onchange="this.form.submit();">
						    <option value="" >Tüm Firmalar</option> <?php
						    $sql="SELECT firma.id, firma.adi from firma where firma.uyeliktur=3 order by firma.adi asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_GET['firma']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['adi']; ?></option><?php }?>
                                                   </select>
                                                   
                                                   
            
     <select name="sehir" class="text" onchange="this.form.submit();">
						    <option value="" >Tüm Şehirler</option> <?php
						    $sql="SELECT id, ad from sehir order by ad asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($_GET['sehir']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['ad']; ?></option><?php }?>
                                                   </select>
                            
                            
                                                        
                            
                            
 <div class="sidebar_search" style="float:right">
 <input type="text" name="fkelime" class="search_input" value="<?php echo $_GET['fkelime'];?>" onclick="this.value=''">
 <input type="image" name="fara" class="search_submit" src="images/search.png">   </div> 
            <input type="hidden" name="pg" value="haber" />
            <input type="hidden" name="sira" value="<?php echo $_GET['sira']; ?>" />
           
            </form>
 
 
  
 
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        <th scope="col" class="rounded-company"><input type="button"  class="google" onclick='secKaldir("comment[]")' value='Tümü'></th>
        	 <th scope="col" class="rounded">
             <?php if($sira=='fadi2') { echo "<a href='index2.php?pg=haber&sira=fadi&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Haber Başlık<img src='images/downs.png' /></a>"; }
			else if ( $sira=="fadi") { echo " <a href='index2.php?pg=haber&sira=fadi2&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Haber Başlık<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=haber&sira=fadi&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Haber Başlık</a>"; }
			?> 
             </th>
              <th scope="col" class="rounded">Firma Adı</th>
               <th scope="col" class="rounded" width="25">
               <?php if($sira=='onay2') { echo "<a href='index2.php?pg=haber&sira=onay&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Onay<img src='images/downs.png' /></a>"; }
			else if ( $sira=="onay") { echo " <a href='index2.php?pg=haber&sira=onay2&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Onay<img src='images/ups.png' /></a>"; }
			else { echo " <a href='index2.php?pg=haber&sira=onay&page=$page&fkelime=$fkelime&sehir=$sehir&firma=$firma'>Onay</a>"; }
			?>
               </th>
             <th scope="col" class="rounded" width="25">Düzen</th>
            <th scope="col" class="rounded-q4" width="25">Sil</th>
                    </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="5" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
   <form method="GET" action="index2.php">
	<?php
		while($row = mysql_fetch_assoc($result))
		{
			if ( $row['onay']==1){$onayresim=onay;}else{$onayresim=busy;}
			?>
	    	<tr>
            <td><input type="checkbox" name="comment[]" value="<?php echo $row['id'];?>" /></td>
        	<td><?php echo $row['haber_baslik']; ?></td>
            <td><?php echo $row['adi']; ?></td>
             <td><a href="index2.php?pg=haber&sehir=<?php echo $_GET['sehir']; ?>&fkelime=<?php echo $_GET['fkelime']; ?>&firma=<?php echo $_GET['firma']; ?>&page=<?php echo $_GET['page']; ?>&islem=onay&id=<?php echo $row['id']; ?>&deger=<?php echo $row['onay']; ?>&sira=<?php echo $_GET['sira']; ?>"><img src="images/<?php echo $onayresim; ?>.png" alt="Onay" title="Onay" border="0" /></a></td>
             
            <td><a href="index2.php?pg=haberduzenle&sid=<?php echo $row['id']; ?>&sehir=<?php echo $_GET['sehir']; ?>&fkelime=<?php echo $_GET['fkelime']; ?>&firma=<?php echo $_GET['firma']; ?>&page=<?php echo $_GET['page']; ?>&sira=<?php echo $_GET['sira']; ?>"><img src="images/user_edit.png" alt="Düzenle" border="0" /></a></td>
             <td><a href="index2.php?pg=haber&islem=sil&page=<?php echo $_GET['page']; ?>&sid=<?php echo $row['id']; ?>&sehir=<?php echo $_GET['sehir']; ?>&fkelime=<?php echo $_GET['fkelime']; ?>&firma=<?php echo $_GET['firma']; ?>&sira=<?php echo $_GET['sira']; ?>" class="ask"><img src="images/delete.png" alt="Düzenle" border="0" /></a></td>
            
        </tr>
        
        
         
            
    
	<?
		}
	?>
   <tr><td colspan="9">Seçilenleri:
     <input type="hidden"  name="page" value="<?php echo $_GET['page']; ?>" />
     <input type="hidden"  name="pg" value="haber" />
     <input type="hidden"  name="fkelime" value="<?php echo $_GET['fkelime']; ?>" />
     <input type="hidden"  name="sehir" value="<?php echo $_GET['sehir']; ?>" />
     <input type="hidden"  name="firma" value="<?php echo $_GET['firma']; ?>" />
      <input type="submit" class="google" name="tumonay" value="Aktif Et" />
     <input type="submit" class="google" name="tumiptal" value="Pasif Et" />
     <input type="submit" class="google" style="color:#C36" onclick="return confirmSubmit();" name="tumsil" value="Sil" />
         </td></tr>
         </form>

 </tbody>
</table>
<?=$pagination?>  


 
<?php } //üye kontrol kapat?>