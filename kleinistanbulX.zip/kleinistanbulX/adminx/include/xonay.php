    <?php if ($f_say>0){ ?> 
 <h2>Onay Bekleyen Firmalar</h2> 
                                   
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	<th scope="col" class="rounded">Firma Adi</th>
         	<th scope="col" class="rounded-q4">Tarih</th>
			        </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="1" class="rounded-foot-left"><em>Onay Bekleyen Firmaları Görmek İçin <a href="index2.php?pg=fliste&sira=onay2"> Tıklayınız.</a> </em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
    	
      <?php 
	  $sql="SELECT adi, onay, bastarih from firma where onay=0 order by bastarih desc ";
	  $sorgu=mysql_query($sql) or die(mysql_error());
	  while($array=mysql_fetch_array($sorgu))
	  {
	  ?><tr>
	    	<td><?php echo $array['adi']; ?></td>
           <td><?php echo strftime("%d/%m/%Y", $array['bastarih']); ?></td>
			   </tr>
          
			
			<?php 
			}
			?>
         
    </tbody>
</table>
<?php }?>



 <?php if ($rek_say>0){ ?> 
<p>
 <h2>Onay Bekleyen Reklamlar</h2> </p>
                    
                    
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	<th scope="col" class="rounded">Reklam Url</th>
           <th scope="col" class="rounded-q4">Reklam Tipi</th>
         	
			        </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="1" class="rounded-foot-left"><em>Onay Bekleyen Reklamları Görmek İçin <a href="index2.php?pg=reklam&sira=onay2"> Tıklayınız.</a> </em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
    	
      <?php 
	  $sql="SELECT rek_url, rek_tip from reklam where rek_onay=0 order by rek_id desc";
	  $sorgu=mysql_query($sql) or die(mysql_error());
	  while($array=mysql_fetch_array($sorgu))
	  {
	  ?><tr>
	    	<td><?php echo $array['rek_url']; ?></td>
            <td><?php echo $array['rek_tip']; ?></td>
    
		   </tr>
          
			
			<?php 
			}
			?>
         
    </tbody>
</table>
<?php }?>