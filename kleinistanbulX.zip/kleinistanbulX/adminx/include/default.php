   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <h2>Yapılacaklar Listesi:</h2> 
    
    <form method="post" action="index2.php?islem=task">
    <dl style="height:130px"><dt>
    <label>Notlar</label></dt>
    <dd>
    <textarea style="width:615px; height:100px;" class="text" name="yap"></textarea></dd>
    
    </dl>
    
    <input type="submit"  class="google" value="Gönder" />
    </form>
<?php
if($_GET['islem']=='task')
{
 $yap=$_POST['yap'];
 $tar=time();
 $yap=mysql_query("INSERT INTO task (yap,tarih) VALUES ('$yap','$tar')");
}
 ?>
 
 
 <?php
if($_GET['islem']=='silyap')
{
 $id=mysql_real_escape_string($_GET['id']);
 $sil=mysql_query("DELETE from task where id='$id'");
}
 ?>
 

 <?php
$sorgu=mysql_query("SELECT yap,tarih,id from task order by id desc");
 while($cek=mysql_fetch_row($sorgu)) {?>
  <div style="background:#D9FDFF; color:#000; margin:5px; padding:10px; border:1px solid #C36" >
  <?php 	 echo $cek['0']; ?><br />
  <span  style="float:right; font-size:9px; font-weight:bold"><?php echo strftime("%d/%m/%Y   %H:%M", $cek['1']); ?></span>
  <span><a href="index2.php?islem=silyap&id=<?php echo $cek['2']; ?>"> <img src="images/delete.png" /></a></span>
  </div>
 <?php
	 }
  ?>
</head>
</html>