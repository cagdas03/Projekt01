<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT polls.pollQuestion, polls.pollStatus,pollAnswers.pollAnswerID,pollAnswers.pollAnswerValue from polls inner join pollAnswers on polls.pollID=pollAnswers.pollID where polls.pollID='$sid' group by polls.pollID limit 0,1");
$anket=mysql_fetch_assoc($sorgu);
$anketsay=mysql_num_rows($sorgu);
 ?>
    
    <script language="JavaScript">
function check_anketedit(){
	
			if (document.anketform.soru.value == ""){
		alert ("Lütfen anket adını yazınız.");
		document.anketform.soru.focus();
		return false;  
	}
	

		
	 }

</script>

<script type="text/javascript">
function addFormField() {
	
	var id = document.getElementById("id").value;
	$("#divTxt").append("<dl id='row" + id + "'><dt><label for='txt" + id + "'>Seçenek&nbsp;&nbsp;</dt><dd><input type='text' class='text' size='20' name='txt["+ 999999+id +"]' id='txt" + id + "'>&nbsp;&nbsp<a href='#' onClick='removeFormField(\"#row" + id + "\"); return false;'>Sil</a></dd><dl>");
	
	
	id = (id - 1) + 2;
	document.getElementById("id").value = id;
}

function removeFormField(id) {
	$(id).remove();
}
</script>

<div class="form">

<form method="post" action="index2.php?pg=anket&islem=anketduzenle&sid=<?php echo $sid;?>"  onSubmit="return check_anketedit()" id="form1" name="anketform" >
     <h2>Anket Düzenle</h2>

    
     
    <dl>
     <dt><label for="soru">Anket Sorusu:</label></dt>
     <dd><input type="text" value="<?php echo $anket['pollQuestion'];?>" class="text" name="soru" /></dd>
     </dl> 
 <p style="float:left">
 <a href="#" onClick="addFormField(); return false;" class="bt_green"><span class="bt_green_lft"></span><strong>Seçenek Ekle</strong><span class="bt_green_r"></span></a></p>
  <div style="clear:both;"></div>

<input type="hidden" id="id" value="1">
<div id="divTxt">
<dl><dt><label></label></dt><dd><input type="button"  class="text"  value="Seçenek Metni" size="20" "><input type="button" class="text"  value="Oy Sayısı" style="width:30px"  >                              
                                       </dd></dl>
<?php 
$sor=mysql_query("SELECT pollAnswerValue,pollAnswerID,pollAnswerID,pollAnswerPoints from pollAnswers where pollID='$sid'");
$in=999999;
while($cek=mysql_fetch_assoc($sor))
{

?>
<dl id="row<?php echo $in;?>"><dt><label for="txt<?php echo $in;?>">Seçenek</label></dt><dd>
<input type="text" class="text" value="<?php echo $cek['pollAnswerValue']; ?>" size="20" name="txt[<?php echo $cek['pollAnswerID']; ?>]" id="txt<?php echo $in;?>">
<input type="text" class="text" value="<?php echo $cek['pollAnswerPoints']; ?>"  style="width:30px" name="sonuc[<?php echo $cek['pollAnswerID']; ?>]"  id="sonuc<?php echo $in;?>">
 <a href="index2.php?pg=anket&islem=anketduzenle&do=secsil&secid=<?php echo $cek['pollAnswerID']; ?>&sid=<?php echo $sid; ?>" >Sil</a>
                                       </dd></dl>

<?php
$in++;
 }?>
</div>
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle" style="margin-left:170px" class="google"  value="Seçenekleri Düzenle" />
<input style="float:right; margin-right:65px;" type="submit" name="points" class="google"  value="Oyları Düzenle" />
</form>
</div>

<?php
if($_GET['do']=='secsil')
{
$secid=$_GET['secid'];
$sid=$_GET['sid'];
mysql_query("DELETE from pollAnswers where pollAnswerID='$secid'");
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=anket&islem=anketduzenle&sid=$sid'> ";

}

 ?>


<?php if(!empty($_POST['duzenle'])) {
	$sid=$_GET['sid'];
	$soru=$_POST['soru'];
	
	$guncel=mysql_query("UPDATE polls set pollQuestion='$soru' where pollID='$sid'");
		
	$secenek=$_POST['txt'];	
     foreach($secenek as $key => $value)
	 
	{
		if($key>999998)
		{ mysql_query("INSERT INTO pollAnswers (pollID,pollAnswerValue) VALUES ('$sid','$value') ");}
		else 
		{ mysql_query("UPDATE pollAnswers SET pollAnswerValue='$value' where pollAnswerID='$key' "); }
	}
			
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=anket&islem=anketduzenle&sid=$sid'> ";
	


	}
	?>
    
    
    <?php if(!empty($_POST['points'])) {
	$sid=$_GET['sid'];
	$soru=$_POST['soru'];
	$guncel=mysql_query("UPDATE polls set pollQuestion='$soru' where pollID='$sid'");
	$sonuc=$_POST['sonuc'];
	$answer=$_POST['answer'];
	
	foreach( $sonuc as $key => $value)
	{  mysql_query("UPDATE pollAnswers SET pollAnswerPoints='$value' where pollAnswerID='$key' "); }
			
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=anket&islem=anketduzenle&sid=$sid'> ";
	
	}
	?>


     
      
     