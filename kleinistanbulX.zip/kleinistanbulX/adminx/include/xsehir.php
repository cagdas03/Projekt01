 <?php 
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = '../index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
 	
    
    <script language="JavaScript">
function check_fekle(){
	
			if (document.sehirform.sehir_adi.value == ""){
		alert ("Lütfen şehir adını yazınız.");
		document.sehirform.sehir_adi.focus();
		return false;  
	}
	
	

	
	 }

</script>


  
    
    <?php
	
	
	//Kelime araması yapıldıysa aratılan kelime ile ilgilii sonuçları çıkaralım.
	

	
	// include your code to connect to DB.

	$tbl_name="sehir";		//your table name
	// How many adjacent pages should be shown on each side?
	$adjacents = 3;
	
	/* 
	   First get total number of rows in data table. 
	   If you have a WHERE clause in your query, make sure you mirror it here.
	*/
	$query = "SELECT COUNT(*) as num FROM $tbl_name";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages[num];
	
	/* Setup vars for query. */
	$targetpage = "index2.php?pg=sehir"; 	//your file name  (the name of this file)
	$limit = 50; 								//how many items to show per page
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	$sql = "SELECT id,ad from $tbl_name  order by ad asc LIMIT $start, $limit";
	$result = mysql_query($sql);
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage&page=$prev\">« Geri</a>";
		else
			$pagination.= "<span class=\"disabled\">« Geri</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage&page=$next\">İleri »</a>";
		else
			$pagination.= "<span class=\"disabled\">İleri »</span>";
		$pagination.= "</div>\n";		
	}
?>

  <?php
//İşlemleri aşağıda ypıp uyarı ya da valid değerlerini verelim
//Onaylama İşlemi
$islem=$_GET['islem'];
switch($islem){

case "sehirduzenle":
include("xsehirduzenle.php");
break;


case "sil":
$sid=$_GET['sid'];
$page=$_GET['page'];
$firmasay=mysql_num_rows(mysql_query("SELECT id from firma where sehir='$sid'"));
if($firmasay>0){echo "<div class='error_box'>Bu şehire bağlı $firmasay adet firma görünüyor; şehiri silmeden önce şehire bağlı firmaları silmelisiniz. ayrıca şehir silinirse ilçelerde silinecektir.</div>";}
else {
//Şehir dosyaları klasörden siliniyor
$sil=mysql_query("DELETE from sehir where id='$sid'");
$silce=mysql_query("DELETE from ilce where sehir='$sid'");
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sehir&page=$page'> ";
}
break;

case "ekle":
include("xsehirekle.php");
break;



default:

}


?>
 <a href="index2.php?pg=sehir&islem=ekle" class="bt_green"><span class="bt_green_lft"></span><strong>Yeni Şehir Ekle</strong><span class="bt_green_r"></span></a>
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	 <th scope="col" class="rounded-company">Şehir Adı</th>
              <th scope="col" class="rounded">İlçeler</th>
             <th scope="col" class="rounded" width="25">Düzen</th>
            <th scope="col" class="rounded-q4" width="25">Sil</th>
                    </tr>
    </thead>
        <tfoot>
    	<tr>
        	<td colspan="2" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>

        </tr>
    </tfoot>
    <tbody>
   
	<?php
		while($row = mysql_fetch_assoc($result))
		{?>
	    	<tr>
        	<td><?php echo $row['ad']; ?></td>
            <td><a href="index2.php?pg=ilce&islem=ilce&id=<?php echo $row['id']; ?>">İlçeleri Gör/ Düzenle / Ekle/ Sil</a> </td>
            <td><a href="index2.php?pg=sehir&islem=sehirduzenle&sid=<?php echo $row['id']; ?>"><img src="images/user_edit.png" alt="Düzenle" border="0" /></a></td>
             <td><a href="index2.php?pg=sehir&islem=sil&page=<?php echo $_GET['page']; ?>&sid=<?php echo $row['id']; ?>" class="ask"><img src="images/delete.png" alt="Düzenle" border="0" /></a></td>
            
        </tr>
            
    
	<?
		}
	?>
   

 </tbody>
</table>
<?=$pagination?>  


 
<?php } //üye kontrol kapat?>