  	<script language="JavaScript">
function check_reklamekle(){
	
      	if (document.kekleform.rek_tip.value == ""){
		alert ("Reklam pozisyonu seçiniz.");
		document.kekleform.rek_tip.focus();
		return false;  
	}
	
	
	      	if (document.kekleform.rek_kod.value == ""){
		alert ("Reklam kodunu yazınız.");
		document.kekleform.rek_kod.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=kodreklam&islem=ekle"  enctype="multipart/form-data" onSubmit="return check_reklamekle()" id="kekleform" name="kekleform" >
     <h2>Yeni Reklam Kodu Ekle</h2>
     
        
     
 
       
     
            <dl>
                        <dt><label for="rek_tip">Reklam Pozisyonu:</label></dt>
                        <dd>
						   <select name="rek_tip" class="text">
						<option value="300">Anasayfa Ve Firma Detay Sağ [300x250]</option>
                        <option value="468">Anasayfa Orta [468x60]</option>
                        
					
                        </select>
                        
                         </dd>
     </dl>
     
       
     <div style="clear:both"></div>  
     
 
 
 
        <dl>
       <font color="#CC0066">Google vb. Reklam kodunu aşağıya yapıştırınız.</font>
                               <dt><label for="rek_kod">Reklam kodu:</label></dt>
                        <textarea  name="rek_kod"  style="width:445px; height:150px; border:1px solid #ccc"></textarea>
     </dl>
     
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Google Reklam Ekle" />
</form>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	

	//Eğer böyle bir firma yoksa
	$rek_tip=$_POST['rek_tip'];
	$rek_kod=$_POST['rek_kod'];
			
	// ekleme yapılıyor
	$reklamekle=mysql_query("INSERT INTO reklam (rek_onay, rek_kod , rek_tip ,rek_hitlimit,rek_gosterlimit)
	                                 VALUES ('1', '$rek_kod', '$rek_tip', '1' ,'1' )") or die(mysql_error());
	if($reklamekle) { echo "<div class='valid_box'>Reklam eklendi.</div>";} else {echo "Reklam eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=kodreklam&islem=googleliste'> ";

    }// submite basılmışsa
	 ?>


      
      
     