<?php
// error_reporting(E_ALL);
// we first include the upload class, as we will need it here to deal with the uploaded file
include('class.upload.php');

// retrieve eventual CLI parameters
$cli = (isset($argc) && $argc > 1);
if ($cli) {
    if (isset($argv[1])) $_GET['file'] = $argv[1];
    if (isset($argv[2])) $_GET['dir'] = $argv[2];
    if (isset($argv[3])) $_GET['pics'] = $argv[3];
}

// set variables
$dir_dest = (isset($_GET['dir']) ? $_GET['dir'] : 'test');
$dir_pics = (isset($_GET['pics']) ? $_GET['pics'] : $dir_dest);

if (!$cli) {
?>

<?php
}



// we have three forms on the test page, so we redirect accordingly
if ((isset($_POST['actionmanset']) ? $_POST['actionmanset'] : (isset($_GET['actionmanset']) ? $_GET['actionmanset'] : '')) == 'manset') {
	
	
	
		
$uzanti = end(explode(".",$_FILES["resim"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=index2.php?act=logout'> ";
exit();
}
else   
{
	

    // ---------- IMAGE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['resim']);

    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {

        // yes, the file is on the server
        // below are some example settings which can be used if the uploaded file is an image.
        $handle->file_auto_rename = true; 
  		$handle->image_resize          = true;
        $handle->image_ratio_fill      = true;
        $handle->image_y               = 225;
        $handle->image_x               = 427;
        $handle->image_background_color = '#FFFFFF';
		$handle->no_script = false;
		
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/manset/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
             			 $mansetresmi=$handle->file_dst_name;
                     
        } else {
            // one error occured
           
           echo '' . $handle->error . '';
            
        }


    } 
}

}  








// we have three forms on the test page, so we redirect accordingly
if ((isset($_POST['actionlogo']) ? $_POST['actionlogo'] : (isset($_GET['actionlogo']) ? $_GET['actionlogo'] : '')) == 'logo') {
	
	
	$uzanti = end(explode(".",$_FILES["f_logo"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=index2.php?act=logout'> ";
exit();
}
else   
{
	

    // ---------- IMAGE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['f_logo']);

    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {

        // yes, the file is on the server
        // below are some example settings which can be used if the uploaded file is an image.
        $handle->file_auto_rename = true; 
  		$handle->image_resize          = true;
        $handle->image_ratio_fill      = true;
		$handle->file_max_size = '250000'; // 1KB
        $handle->image_y               = 195;
        $handle->image_x               = 280;
        $handle->image_background_color = '#FFFFFF';
		$handle->no_script = false;
		
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/logo/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
             			 $logoismi=$handle->file_dst_name;
                     
        } else {
            // one error occured
           
           echo '' . $handle->error . '';
            
        }


    } 
}

}  





if ((isset($_POST['actionmulti']) ? $_POST['actionmulti'] : (isset($_GET['actionmulti']) ? $_GET['actionmulti'] : '')) == 'multiple') {

    // ---------- MULTIPLE UPLOADS ----------

    // as it is multiple uploads, we will parse the $_FILES array to reorganize it into $files
    $files = array();
    foreach ($_FILES['my_field'] as $k => $l) {
        foreach ($l as $i => $v) {
            if (!array_key_exists($i, $files))
                $files[$i] = array();
            $files[$i][$k] = $v;
        }
    }

    // now we can loop through $files, and feed each element to the class
    foreach ($files as $file) {

        // we instanciate the class for each element of $file
        $handle = new Upload($file);

        // then we check if the file has been uploaded properly
        // in its *temporary* location in the server (often, it is /tmp)
        if ($handle->uploaded) {
			
			  if(($handle->image_src_x>730) || ($handle->image_src_y> 500)){  
		$handle->file_auto_rename = true; 
  		$handle->image_resize          = true;
        $handle->image_ratio_fill      = true;
		$handle->file_max_size = '250000'; // 1KB
        $handle->image_y               = 500;
        $handle->image_x               = 730;
        $handle->image_background_color = '#FFFFFF';
		$handle->image_watermark       = 'watermark.png';
		$handle->image_watermark_position = 'BL';
		$handle->no_script = false;
	      }
		else
		{   
				
			    $handle->file_auto_rename = true; 
                $handle->image_resize = false;
				$handle->image_watermark       = 'watermark.png';
		        $handle->image_watermark_position = 'BL';
				$handle->no_script = false;
		
		}
  
            // now, we start the upload 'process'. That is, to copy the uploaded file
            // from its temporary location to the wanted location
            // It could be something like $handle->Process('/home/www/my_uploads/');
            $handle->Process('../uploads/firmaresim/');

            // we check if everything went OK
            if ($handle->processed) {
                // everything was fine !
          
              @$resim.=$handle->file_dst_name."-";	  
               
            } else {
                // one error occured
                echo '<fieldset>';
                echo '  <legend>Firma resimleri istenilen klasöre yüklenemedi.</legend>';
                echo ' Hata: ' . $handle->error . '';
                echo '</fieldset>';
            }

        } else {
            // if we're here, the upload file failed for some reasons
            // i.e. the server didn't receive the file
					
            
			 echo '' . $handle->error . '';
            
        }
    }
	
	
} 




if ((isset($_POST['actionvideo']) ? $_POST['actionvideo'] : (isset($_GET['actionvideo']) ? $_GET['actionvideo'] : '')) == 'video') {

    // ---------- SIMPLE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['f_video']);

    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {
		$handle->file_auto_rename = true; 
		$handle->no_script = false;
		$handle->allowed = array('video/*');
		$handle->forbidden = array('application/*','text/*', 'image/*');
		

        // yes, the file is on the server
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/video/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
			@$videoadi= $handle->file_dst_name;
                   
        } else {
            // one error occured
            echo '<fieldset>';
            echo '  <legend>Video istenilen klasöre yüklenemedi.</legend>';
            echo '  Hata: ' . $handle->error . '';
            echo '</fieldset>';
        }

    

    } else {
        // if we're here, the upload file failed for some reasons
        // i.e. the server didn't receive the file
       
            echo '' . $handle->error . '';
           }

}






if ((isset($_POST['actionreklam']) ? $_POST['actionreklam'] : (isset($_GET['actionreklam']) ? $_GET['actionreklam'] : '')) == 'reklam') {
	
	
	
		
$uzanti = end(explode(".",$_FILES["r_resim"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=index2.php?act=logout'> ";
exit();
}
else   
{
	

    // ---------- SIMPLE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['r_resim']);
    
    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {
		$handle->file_auto_rename = true; 
		$handle->no_script = false;
		
		


        // yes, the file is on the server
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/reklam/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
			@$reklamadi= $handle->file_dst_name;
                   
        } else {
            // one error occured
            echo '<fieldset>';
            echo '  <legend>Reklam istenilen klasöre yüklenemedi.</legend>';
            echo '' . $handle->error . '';
            echo '</fieldset>';
        }

    

    } else {
        // if we're here, the upload file failed for some reasons
        // i.e. the server didn't receive the file
       
            echo '' . $handle->error . '';
           }

}
}




if ((isset($_POST['actionurun']) ? $_POST['actionurun'] : (isset($_GET['actionurun']) ? $_GET['actionurun'] : '')) == 'urun') {
	
	
$uzanti = end(explode(".",$_FILES["f_urun"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=index2.php?act=logout'> ";
exit();
}
else   
{
	


    // ---------- IMAGE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['f_urun']);

    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {

        // yes, the file is on the server
        // below are some example settings which can be used if the uploaded file is an image.
         if(($handle->image_src_x>800) || ($handle->image_src_y> 800)){  
		$handle->file_auto_rename = true; 
  		$handle->image_resize          = true;
        $handle->file_max_size = '250000'; // 1KB
		 $handle->image_ratio_fill      = true;
        $handle->image_x               = 800;
		$handle->image_y         = 552;
        $handle->image_background_color = '#FFFFFF';
		$handle->image_watermark       = 'watermark.png';
		$handle->image_watermark_position = 'BL';
		$handle->no_script = false;
	      }
		else
		{   
				
			    $handle->file_auto_rename = true; 
                $handle->image_resize = false;
				$handle->image_watermark       = 'watermark.png';
		        $handle->image_watermark_position = 'BL';
				$handle->no_script = false;
		
		}
	
		
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/urun/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
             		 $urunismi=$handle->file_dst_name;
                     
        } else {
            // one error occured
           
           echo '' . $handle->error . '';
		   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=urunekle'> ";   }
	


    } 

   }
} 




if ((isset($_POST['actionhaber']) ? $_POST['actionhaber'] : (isset($_GET['actionhaber']) ? $_GET['actionhaber'] : '')) == 'haber') {
	
	
$uzanti = end(explode(".",$_FILES["f_haber"]["name"]));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") )
{ 
echo "<meta http-equiv='refresh' content='0;URL=index2.php?act=logout'> ";
exit();
}
else   
{
	


    // ---------- IMAGE UPLOAD ----------

    // we create an instance of the class, giving as argument the PHP object
    // corresponding to the file field from the form
    // All the uploads are accessible from the PHP object $_FILES
    $handle = new Upload($_FILES['f_haber']);

    // then we check if the file has been uploaded properly
    // in its *temporary* location in the server (often, it is /tmp)
    if ($handle->uploaded) {

        // yes, the file is on the server
        // below are some example settings which can be used if the uploaded file is an image.
         if(($handle->image_src_x>800) || ($handle->image_src_y> 800)){  
		$handle->file_auto_rename = true; 
  		$handle->image_resize          = true;
        $handle->file_max_size = '250000'; // 1KB
		 $handle->image_ratio_fill      = true;
        $handle->image_x               = 800;
		$handle->image_y         = 552;
        $handle->image_background_color = '#FFFFFF';
		$handle->image_watermark       = 'watermark.png';
		$handle->image_watermark_position = 'BL';
		$handle->no_script = false;
	      }
		else
		{   
				
			    $handle->file_auto_rename = true; 
                $handle->image_resize = false;
				$handle->image_watermark       = 'watermark.png';
		        $handle->image_watermark_position = 'BL';
				$handle->no_script = false;
		
		}
	
		
        // now, we start the upload 'process'. That is, to copy the uploaded file
        // from its temporary location to the wanted location
        // It could be something like $handle->Process('/home/www/my_uploads/');
         $handle->Process('../uploads/haber/');

        // we check if everything went OK
        if ($handle->processed) {
            // everything was fine !
             		 $haberismi=$handle->file_dst_name;
                     
        } else {
            // one error occured
           
           echo '' . $handle->error . '';
		   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=haberekle'> ";   }
	


    } 

   }
}  

 