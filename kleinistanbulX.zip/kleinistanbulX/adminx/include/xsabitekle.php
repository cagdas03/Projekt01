    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.adi.value == ""){
		alert ("Lütfen ad yazınız.");
		document.ekleform.adi.focus();
		return false;  
	           }
			   
			if (document.ekleform.menu.value == ""){
		alert ("Lütfen menü seçiniz.");
		document.ekleform.menu.focus();
		return false;  
	           }			   
	
	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=sabitliste&islem=ekle" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2>Yeni Sayfa Ekle</h2>
                        <dl>
                        <dt><label for="menu">Menü Adı:</label></dt>
                        <dd>
                        <select name="menu">
                        <option value="">Menü Seç</option>
						<?php 
						$sorgum=mysql_query("SELECT madi, mpg from menu order by madi asc") or die(mysql_error());
						while($menu=mysql_fetch_assoc($sorgum))
						{
							?>
					  <option value="<?php echo $menu['mpg']; ?>" ><?php echo $menu['madi']; ?> </option>
							<?php
						}
						
						?>
                        </select>
                        </dd>
                        </dl>
                                             
                        <dl>
                        <dt><label for="adi">Sayfa Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="adi" /></dd>
                       </dl>
                         
                         
              <dl>
                        <dt><label for="sira">Sıra:</label></dt>
                        <dd><input type="text" value="" class="text" name="sira" /></dd>
             </dl>
                 
                             
                             
                    <b>Sayfa İçeriği:</b> [Sayfanın bir url ye yönlenmesini istiyorsanız bu alanı boş bırakınız] <br>  
					<br>
					<label for="detay"></label>
 					<textarea id="noise" name="detay" ></textarea>
                    <script type="text/javascript" src="../js/ckayar.js"></script>
 
 
                 
                                             
                        <dl>
                        <dt><label for="url">Url: </label></dt>
                        <dd><input type="text" value="" class="text" name="url" /><br />
                        [Url eklerseniz sayfa eklediğiniz url ye yönlenecektir, detay görünmeyecektir]
                        </dd>
                        </dl>
                                     
                                             
                                             
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Ekle" />
</form>
</div>

<?php if(!empty($_POST['hiddenekle'])) {
	$adi=$_POST['adi'];
	$menu=$_POST['menu'];
	$sira=$_POST['sira'];
	$url=$_POST['url'];
	$detay=addslashes($_POST['detay']);

		
	$sektorekle=mysql_query("INSERT INTO sayfa (adi, pg, sira, url, detay, onay ) VALUES ('$adi', '$menu' , '$sira' , '$url' ,'$detay' ,'1'  )") or die(mysql_error());
	if($sektorekle) { echo "<div class='valid_box'>Sektör eklendi.</div>";} else {echo "Sektör eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='2;URL=index2.php?pg=sabitliste'> ";
	
	 }?>


      
      
     