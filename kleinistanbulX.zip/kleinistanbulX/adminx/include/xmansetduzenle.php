
    <script language="JavaScript">
function check_hedit(){
	
				if (document.duzenform.resim.value == ""){
		alert ("Lütfen manset için resim ekleyiniz.");
		document.duzenform.resim.focus();
		return false;  
	}
	

		
	 }

</script>
<?php
$xid=intval($_GET['xid']);
$sql="SELECT * from manset where id='$xid' limit 0,1";
$sorgu3=mysql_query($sql) or die(mysql_error());
while($manset=mysql_fetch_assoc($sorgu3)){
 ?>
 
<div class="form">

<form method="post" action="index2.php?pg=manset&islem=mansetduzenle&xid=<?php echo $xid;?>" enctype="multipart/form-data" onSubmit="return check_hedit()" id="duzenform" name="duzenform" >
     <h2>Haber Düzenle</h2>
     

    
     
     
     <dl>
                        <dt><label for="tip">Haber Kategorisi</label></dt>
                        <dd> 
                        <select style="width:305px" name="tip" >
						    <option value="" >Kategori Seç</option> <?php
						    $sql="SELECT mansetkat.mid, mansetkat.mkatadi from mansetkat  order by mansetkat.mkatadi asc";
						    $sorgu=mysql_query($sql) or die(mysql_error());
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['mid']; ?>" <?php if($manset['kat']==$sehircek['mid']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['mkatadi']; ?></option><?php }?>
                                                   </select></dd>
              </dl>
              
              
     
     <dl>
                        <dt><label for="baslik">Haber Başlığı:</label></dt>
                        <dd><input type="text" value="<?php echo $manset['manset_baslik']; ?>" class="text" name="baslik" /></dd>
    </dl>
    
    
    <p>
    <label for="ozet">Haber Özeti:(90 karakter maksimum)</label><br />
                       <textarea style="width:600px; height:80px" maxlength="90"  name="ozet"><?php echo $manset['manset_ozet']; ?></textarea>
     
     
     </p>
    
      <label for="detay">Haber Detayı:</label>
                       <textarea id="noise" name="detay" ><?php echo stripslashes($manset['manset_detay']); ?></textarea>
                          <script type="text/javascript" src="../js/ckayar.js"></script>
                       
                       
                       <dl>
                        <dt><label for="tarih">Eklenme Tarihi: </label></dt>
                        <dd><?php echo tt_tarih($manset['bastarih']);?></dd>
    </dl>
    
                  
    
                      <dl><dt><label>Haber Resmi:<br /> Uygun boyut: 427x225px<br /> Dosya Türü: Jpg, png , gif ]</label></dt><dd   style="height:118px;">
						   <?php if(!empty($manset['mansetresim'])) {?>   <img src="../uploads/manset/<?php echo $manset['mansetresim'];?>" width="270" border="0"><a title="Resmi Sil" href="index2.php?pg=manset&islem=mansetduzenle&do=mansetresimsil&xid=<?php echo $xid; ?>" style="margin:5px" class="ask"><img src="images/delete.png" alt="Sil" /></a></dd>  <?php } else {?>
                           <input type="file"  name="resim" value="" /> </dd>
                       <?php }?>
                      </dl>
                      
                           <dl><b>Eğer Url varsa resim direk bu url ye yönlenecektir.</b> Url yoksa manşetteki resme tıklayınca site içinde bir sayfa açılacak ve aşağıda yazılacak Haber başlığı ve detayları bu sayfada gösterilecektir.</dl>
     <dl>
                        <dt><label for="url">Haber Url: </label></dt>
                        <dd><input type="text" value="<?php echo $manset['manset_url']; ?>" class="text" name="url" /></dd>
    </dl>
    
      
    

<input type="hidden" name="actionmanset" value="manset" />    
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle" class="google"  value="Haberi Düzenle" />
</form>
</div>

<?php }?>

<?php if(!empty($_POST['hiddenduzen'])) {
	$xid=$_GET['xid'];
	include("include/upload.php");
	$baslik=temizle($_POST['baslik']);
	$detay=addslashes($_POST['detay']);
	$url=area($_POST['url']);
	$ozet=area($_POST['ozet']);
	$tip=temizle($_POST['tip']);
    $sorgu=mysql_query("SELECT mansetresim from manset where id='$xid' limit 0,1");
	$sec=mysql_fetch_row($sorgu);
			  	
				if($_FILES['resim']['name']==''){ $resim=$sec['0'];} else { $resim=$mansetresmi;}
								
	
	$mansetupdate=mysql_query("UPDATE manset SET  manset_baslik='$baslik',manset_detay='$detay',mansetresim='$resim', manset_url='$url' , kat='$tip',manset_ozet='$ozet' where id='$xid'") or die(mysql_error());
	if($mansetupdate) { echo "<div class='valid_box'>Manset düzenlendi.</div>";} else {echo "Manset düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=manset&islem=mansetduzenle&xid=$xid'> ";
	
	 }?>


<?php 
if ($_GET['do']=='mansetresimsil') {
$xid=intval($_GET['xid']);
$mansetyol=mysql_query("SELECT mansetresim FROM manset where id='$xid' ");
while($unmanset=mysql_fetch_assoc($mansetyol)){$yol=$unmanset['mansetresim']; @unlink("../uploads/manset/$yol"); }
$sil=mysql_query("UPDATE manset set mansetresim='' where id='$xid'");
echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=manset&islem=mansetduzenle&xid=$xid'> ";
}


?>

      
      
     