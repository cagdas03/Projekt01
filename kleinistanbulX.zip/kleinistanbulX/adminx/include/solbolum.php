    	 <form method="get" action="index2.php">
         <div class="sidebar_search"><input type="text" name="fkelime" class="search_input" value="<?php echo $_GET['fkelime'];?>" onclick="this.value=''">
 <input type="image" name="fara" class="search_submit" src="images/search.png">   </div> 
            <input type="hidden" name="pg" value="fliste" />
            </form>
    
            <div class="sidebarmenu">
            
                <a class="menuitem submenuheader" href="">Firmalar</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=fekle">Firma Ekle</a></li>
                    <li><a href="index2.php?pg=fliste">Firma Listele/Düzenle/Sil</a></li>
                                       </ul>
                </div>
                
                
                            <a class="menuitem submenuheader" href="">Ücretli Üyelik Yönetimi</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=ucretli&paket=2">Gümüş Firmalar</a></li>
                    <li><a href="index2.php?pg=ucretli&paket=3">Altın Firmalar</a></li>
                                       </ul>
                </div>
                
                
                 <a class="menuitem submenuheader" href="" >Sabit Sayfalar</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=sabitliste&islem=ekle">Sayfa Ekle</a></li>
                    <li><a href="index2.php?pg=sabitliste">Sayfa Listele,Düzenle,Sil</a></li>
                    </ul>
                </div>
                
                   <a class="menuitem submenuheader" href="" >Sektörler</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=sektor&islem=ekle">Yeni Sektör Ekle</a></li>
                    <li><a href="index2.php?pg=sektor">Sektör Listele,Düzenle,Sil</a></li>
                  
                    </ul>
                </div>
                
                          <a class="menuitem submenuheader" href="" >Şehir / İlçe </a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=sehir&islem=ekle">Şehir Ekle</a></li>
                  <li><a href="index2.php?pg=sehir">Şehir ve İlçe Yönetimi</a></li>
                    </ul>
                </div>
                
                
                <a class="menuitem submenuheader" href="">Genel Haber Kategoriler</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=mansetkat&islem=ekle">Gen. Haber Kategorisi Ekle</a></li>
                   <li><a href="index2.php?pg=mansetkat">Kategori Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
                
                
                       <a class="menuitem submenuheader" href="">Genel Haber</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=manset&islem=ekle">Genel Haber Ekle</a></li>
                   <li><a href="index2.php?pg=manset">Genel Haber Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
                
                                      
                
                  <a class="menuitem submenuheader" href="">Anketler</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=anket&islem=ekle">Anket Ekle</a></li>
                    <li><a href="index2.php?pg=anket">Anket Listele,Düzenle, Sil</a></li>
                                </ul>
                </div>
                
                
                             
                       <a class="menuitem submenuheader" href="">Ürünler</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=urunekle">Ürün Ekle</a></li>
                   <li><a href="index2.php?pg=urun">Ürün Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
                
                
                                       <a class="menuitem submenuheader" href="">İlan Tipleri</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=ilankatekle">İlan Tipi Ekle</a></li>
                   <li><a href="index2.php?pg=ilankat">İlan Tipi Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
                
                             
                       <a class="menuitem submenuheader" href="">İlanlar</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=ilanekle">İlan Ekle</a></li>
                   <li><a href="index2.php?pg=ilan">İlan Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
         
         
                              <a class="menuitem submenuheader" href="">Firma Haberleri</a>
                <div class="submenu">
                    <ul>
                     <li><a href="index2.php?pg=haber&islem=ekle">Firma Haberi Ekle</a></li>
                   <li><a href="index2.php?pg=haber">Firma Haberi Listele,Düzenle,Sil</a></li>
                   </ul>
                </div>
                
        
                
                        <a class="menuitem submenuheader" href="">Reklamlar</a>
                <div class="submenu">
                    <ul>
                    <li><a href="index2.php?pg=reklam&islem=ekle">Reklam Ekle</a></li>
                    <li><a href="index2.php?pg=reklam">Reklam Listele, Düzenle, Sil</a></li>
                
                               </ul>
                </div>
                
                <a class="menuitem" href="index2.php?pg=modul">Modül Yönetimi</a>
                  <a class="menuitem" href="index2.php?pg=email">Tüm Emailler</a>
                              
                    
                <a class="menuitem" href="index2.php?pg=ayar">Genel Ayarlar</a>
                <a class="menuitem" href="index2.php?pg=sifre">Şifre Değiştir</a>
                            
                    
            </div>
            
            
            <div class="sidebar_box">
                <div class="sidebar_box_top"></div>
                <div class="sidebar_box_content">
                <h3>Onay Bekleyenler</h3>
                <img src="images/info.png" alt="" title="" class="sidebar_icon_right" />
                <p>
 

<ul>
<li>Firma Sayısı: <b><?php echo $f_say; ?></b> </li>
</ul>
                </p>                
                </div>
                <div class="sidebar_box_bottom"></div>
            </div>
            
                    
                        
                        
    
