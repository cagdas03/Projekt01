    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.ilce_adi.value == ""){
		alert ("Lütfen ilçe adını yazınız.");
		document.ekleform.ilce_adi.focus();
		return false;  
	}
	
	 }

</script>
<div class="form">

<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT  sehir.ad from sehir  where id='$sid' limit 0,1");
$sabit=mysql_fetch_assoc($sorgu);
 ?>
 

<form method="post" action="index2.php?pg=ilce&islem=ekle&sid=<?php echo $_GET['sid']; ?>"  enctype="multipart/form-data" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2><?php echo $sabit['ad']; ?> İline Yeni İlçe Ekle</h2>
     
     <dl>
                        <dt><label for="ilce_adi">İlçe Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="ilce_adi" /></dd>
     </dl>
     
         
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Yeni İlçe Ekle" />
</form>
</div>

			   
<?php if(!empty($_POST['hiddenekle'])) {
	
	$ilce_adi=$_POST['ilce_adi'];
	
	$sid=$_GET['sid'];
	
	
	$ilceekle=mysql_query("INSERT INTO ilce (ilce_adi, sehir) VALUES ('$ilce_adi' , '$sid' )") or die(mysql_error());
	if($ilceekle) { echo "<div class='valid_box'>İlçe eklendi.</div>";} else {echo "İlçe eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilce&id=$sid'> ";
	
	 }?>


      
      
     