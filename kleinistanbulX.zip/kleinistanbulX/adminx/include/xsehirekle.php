    <script language="JavaScript">
function check_sekle(){
	
			if (document.ekleform.sehir_adi.value == ""){
		alert ("Lütfen şehir adını yazınız.");
		document.ekleform.sehir_adi.focus();
		return false;  
	}
	
	 }

</script>
<div class="form">

<form method="post" action="index2.php?pg=sehir&islem=ekle"  enctype="multipart/form-data" onSubmit="return check_sekle()" id="ekleform" name="ekleform" >
     <h2>Yeni Şehir Ekle</h2>
     
     <dl>
                        <dt><label for="sehir_adi">Şehir Adı:</label></dt>
                        <dd><input type="text" value="" class="text" name="sehir_adi" /></dd>
     </dl>
     
         
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Yeni Şehir Ekle" />
</form>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	
	$sehir_adi=$_POST['sehir_adi'];
	
	
	$sehirekle=mysql_query("INSERT INTO sehir (ad) VALUES ('$sehir_adi')") or die(mysql_error());
	if($sehirekle) { echo "<div class='valid_box'>Şehir eklendi.</div>";} else {echo "Şehir eklenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=sehir'> ";
	
	 }?>


      
      
     