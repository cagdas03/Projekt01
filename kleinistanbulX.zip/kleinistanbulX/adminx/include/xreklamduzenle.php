<link rel="stylesheet" href="css/jquery.ui.all.css">
	<script src="js/jquery.ui.core.js"></script>
	<script src="js/jquery.ui.datepicker.js"></script>
	<script src="js/jquery.ui.datepicker-tr.js"></script>
<script>
	$(function() {
		$( "#datepicker" ).datepicker();
	$.datepicker.regional['tr'];
	}
	
	);
	
	</script>
	<script>
	$(function() {
		$( "#datepicker2" ).datepicker();
	$.datepicker.regional['tr'];
	}
	
	);
	
	</script>
  	<script language="JavaScript">
function check_reklamekle(){
	
			if (document.kekleform.tip.value == ""){
		alert ("Lütfen bir reklam tipi seçiniz.");
		document.kekleform.tip.focus();
		return false;  
	}
	
      	if (document.kekleform.konum.value == ""){
		alert ("Reklam konumu seçiniz.");
		document.kekleform.konum.focus();
		return false;  
	}
	
	
	  if (document.kekleform.adi.value == ""){
		alert ("Reklam adı yazınız.");
		document.kekleform.adi.focus();
		return false;  
	}
	

	
		  if (document.kekleform.bas.value == ""){
		alert ("Başlama tarihi seçiniz.");
		document.kekleform.bas.focus();
		return false;  
	}
	
	

	
		  if (document.kekleform.bit.value == ""){
		alert ("Bitiş tarihi seçiniz..");
		document.kekleform.bit.focus();
		return false;  
	}
	

	
	 }

</script>
<div class="form">


<?php 
$id=$_GET['id'];
$sorgu=mysql_query("SELECT * from reklam where id='$id' limit 0,1 ");
while($reklam=mysql_fetch_assoc($sorgu))
{
?>
<form method="post" action="index2.php?pg=reklam&islem=reklamduzenle&id=<?php echo $id; ?>"  enctype="multipart/form-data" onSubmit="return check_reklamekle()" id="kekleform" name="kekleform" >
                        <h2>Reklam Düzenle</h2>
     
                        <dl>
                        <dt><label for="tip">Reklam Tipiniz:</label></dt>
                        <dd> 
                        <select disabled="disabled" style="width:305px" name="tip"  onchange="this.form.submit();">
						    <option value="" >Tip Seç</option> <?php
						    $sql="SELECT id, tip_adi from reklam_tip  order by id asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{?>
                            <option value="<?php echo $sehircek['id']; ?>" <?php if($reklam['tip']==$sehircek['id']) { echo "selected='selected'";} ?>>
							<?php echo $sehircek['tip_adi']; ?></option><?php }?>
                                                   </select></dd>
                        </dl>

          
     
                        <dl>
                        <dt><label for="konum">Reklam Konumu Seçiniz:</label></dt>
                        <dd> 
                        <select style="width:305px" name="konum"  >
						    <option value="" >Konum Seç</option> <?php
						    $sql="SELECT reklam_konum.id, reklam_konum.konum_adi, reklam_konum.konum from reklam_konum  order by reklam_konum.id asc";
						    $sorgu=mysql_query($sql);
						    while($sehircek=mysql_fetch_assoc($sorgu))
							{
							$dene=mysql_query("SELECT id from reklam where konum='$sehircek[konum]' and onay=1 ");
							$say=mysql_num_rows($dene);
							if($say>0) { $stil="style='text-decoration:line-through'"; } else { $stil="";}	
							?>
                            <option style="font-weight:bold"  value="<?php echo $sehircek['konum']; ?>" <?php if($reklam['konum']==$sehircek['konum']) 
							{ echo "selected='selected'" ;} ?>>
							<?php echo $sehircek['konum_adi']; ?></option><?php }?>
                                                   </select></dd>
                         </dl>
                       
              
                         <dl>
                         <dt><label for="adi">Reklam Adı:</label></dt>
                         <dd><input type="text" value="<?php echo $reklam['radi']; ?>" class="text" name="adi" /> </dd>
                         </dl>
      
     
                       <?php if($reklam['tip']==1) { ?>
     
                        <dl>
                        <dt><label for="url">Reklam Url:</label></dt>
                        <dd><input type="text" value="<?php echo $reklam['url']; ?>" class="text" name="url" /> // Örn: http://www...</dd>
                        </dl>
                        
                        <?php }?>
     
                          <?php if($_POST['tip']==3 || $reklam['tip']==3) { ?>
        				<label for="detay">Script [Adsense v.b kod]</label>
                        <pre><textarea name="detay" style="width:500px; height:200px"><?php echo stripslashes($reklam['script']); ?></textarea> </pre>
                        <div style="clear:both"></div> 
                         <?php }?>
     
                       <?php if( $_POST['tip']==1 || $_POST['tip']==2 || $reklam['tip']==1 ||  $reklam['tip']==2 ) { ?>
                       <dl><dt><label>Dosya:</label></dt>
              <dd   style="height:50px;">
			 <?php if(!empty($reklam['dosya'])) {
				$dosyauz = strtolower(end(explode(".",$reklam['dosya'])));
				
				if($dosyauz=='swf')
				{			
				 ?>
                 
                 <?php }?> 
             
               <img src="../uploads/reklam/<?php echo $reklam['dosya'];?>" width="80" height="50" border="0"><a href="index2.php?pg=reklam&islem=reklamduzenle&do=resimsil&rid=<?php echo $id; ?>" style="margin:5px" class="ask"><img src="images/delete.png" alt="Sil" /></a></dd>  <?php } else {?>
                           <input type="file"  name="r_resim" value="" /> 
                            <input type="hidden" name="actionreklam" value="reklam" /></dd>
                       <?php }?>
                      </dl>
                       
                      <?php }?>
                      
                      
                      <dl>
        				<dt><label for="bas">Başlama Tarihi:</label></dt>
                        <dd> <input type="text" name="bas" value="<?php  tt_tarih($reklam['bas_tarih']) ?>"
                        id="datepicker" /> </dd>
                        </dl>
                        
                        
                          <dl>
        				<dt><label for="bit">Bitiş Tarihi:</label></dt>
                        <dd> <input type="text" name="bit" id="datepicker2" value="<?php tt_tarih($reklam['bit_tarih']) ?>" /> </dd>
                        </dl>
                        
                       
                        
     
                    
     
<input type="hidden" name="hiddenekle" value="ok" />
<input type="submit" class="google" name="duzenle"  value="Reklamı Düzenle" />
</form>
<?php } ?>
</div>

			   
<?php if(!empty($_POST['duzenle'])) {
	
		 
$uzanti = strtolower(end(explode(".",$_FILES["r_resim"]["name"])));
if ( ($uzanti=="php") ||  ($uzanti=="asp")  ||  ($uzanti=="php2") ||  ($uzanti=="php3") ||  ($uzanti=="php4") ||  ($uzanti=="exe") ||  ($uzanti=="html") )
{ 
echo "Hatalı Dosya";
echo "<meta http-equiv='refresh' content='2;URL=index2.php?act=logout'> ";
exit();
}
else
{
	
	include("include/upload.php");
	
	$url=$_POST['url'];
	$adi=$_POST['adi'];
	$konum=$_POST['konum'];
	$detay=addslashes($_POST['detay']);
		
	list($day, $month, $year) = explode('.', $_POST['bas']);
	$bas = mktime(0, 0, 0, $month, $day, $year);
	
	list($day, $month, $year) = explode('.', $_POST['bit']);
	$bit = mktime(0, 0, 0, $month, $day, $year);
	
	
		
	 $sorgu=mysql_query("SELECT dosya from reklam where id='$id' limit 0,1");
	 $sec=mysql_fetch_row($sorgu);
	 if($_FILES['r_resim']['name']==''){ $r_resim=$sec['0'];} else { $r_resim=$reklamadi;}
			  
		
	// ekleme yapılıyor
	$reklamekle=mysql_query("UPDATE reklam SET   radi='$adi', url='$url', konum='$konum' ,  
	dosya='$r_resim',  script='$detay' ,bas_tarih='$bas', bit_tarih='$bit' where id='$id' ") or die(mysql_error());
	if($reklamekle) { echo "<div class='valid_box'>Reklam düzenlendi.</div>";} else {echo "Reklam düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=reklam'> ";
}
   
    }// submite basılmışsa
	 
	 if($_GET['do']=="resimsil")
{  

$rid=$_GET['rid'];
$resimyol=mysql_fetch_row(mysql_query("SELECT dosya,id from reklam where id='$rid' limit 0,1"));
$ryol=$resimyol['0'];
@unlink("../uploads/reklam/$ryol");
$resimsil=mysql_query("UPDATE reklam SET dosya=''  where id='$rid'");
   echo "<div class='valid_box'>Dosya Silindi.</div>";
   echo " <meta http-equiv='refresh' content='0;URL=index2.php?pg=reklam&islem=reklamduzenle&id=$resimyol[1]'> ";
 break;

}

	 ?>


      
      
     