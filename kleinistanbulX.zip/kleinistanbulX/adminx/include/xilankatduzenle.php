<?php
$sid=$_GET['sid'];
$sorgu=mysql_query("SELECT itip_adi from ilantip where id='$sid' limit 0,1");
$sabitsayfa=mysql_fetch_assoc($sorgu);
 ?>

<div class="form">

<form method="post" action="index2.php?pg=ilankat&islem=ilankatduzenle&sid=<?php echo $sid;?>" onSubmit="return check_fekle()" id="sabitform" name="sabitform" >
     <h2>İlan Kategorisi Düzenle</h2>
     <dl>
                        <dt><label for="itip_adi">İlan Kategorisi Adı:</label></dt>
                        <dd><input type="text" value="<?php echo $sabitsayfa['itip_adi']; ?>" class="text" name="itip_adi" /></dd>
                                            </dl>
                                            
                                 
                                            
                                                
<input type="hidden" name="hiddenduzen" value="ok" />
<input type="submit" name="duzenle"  class="google" value="gönder" />
</form>
</div>

<?php if(!empty($_POST['hiddenduzen'])) {
	$sid=$_GET['sid'];
		$itip_adi=$_POST['itip_adi'];
	
	$ilankatupdate=mysql_query("UPDATE ilantip SET  itip_adi='$itip_adi' where id='$sid'");
	if($ilankatupdate) { echo "<div class='valid_box'>İlan Kategorisi düzenledi.</div>";} else {echo "İlan Kategorisi düzenlenemedi"; } 
	echo "<meta http-equiv='refresh' content='0;URL=index2.php?pg=ilankat'> ";
	
	 }?>


      
      
     