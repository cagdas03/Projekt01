    <div class="footer">
    <div class="left_footer"> Kodlayan <a href="http://www.kleinistanbul.com">Kleinistanbul - TTYAZILIM</a></div>
    </div>