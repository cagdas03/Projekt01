 $(document).ready(function() {
 $("#s8").dropdownchecklist( { emptyText: "Lütfen Seçiniz...", width: 295 } );        
 });



//username check
pic1 = new Image(16, 16); 
pic1.src = "images/loader.gif";
$(document).ready(function(){
$("#username2").change(function() { 
var usr = $("#username2").val();
if(usr.length >= 3)
{
$("#status").html('<img src="../images/loader.gif" align="absmiddle">Kontrol ediliyor...');

    $.ajax({  
    type: "POST",  
    url: "check.php",  
    data: "username2="+ usr,  
    success: function(msg){  
   
   $("#status").ajaxComplete(function(event, request, settings){ 

	if(msg == 'Kullanıcı Adı Müsait')
	{ 
        $("#username2").removeClass('object_error'); // if necessary
		$("#username2").addClass("object_ok");
		$(this).html('<img src="../images/accepted.png" align="absmiddle"> <font color="Green"> Uygun </font>  ');
	}  
	else  
	{  
		$("#username2").removeClass('object_ok'); // if necessary
		$("#username2").addClass("object_error");
		$(this).html(msg);
	}  
   
   });

 } 
   
  }); 

}
else
	{
	$("#status").html('<font color="red">Kullanıcı adı en az <strong>3</strong> karakter olmalıdır.</font>');
	$("#username2").removeClass('object_ok'); // if necessary
	$("#username2").addClass("object_error");
	}

});

});


         

function check_fekle(){
	
	
	
 	
	if (document.paket.paket.value == ""){
		alert ("Lütfen Üyelik Tipi Seçiniz.");
		document.paket.paket.focus();
		return false;  
	}
	
	
				if (document.fekleform.username2.value == ""){
		alert ("Kullanıcı adı yazınız.");
		document.fekleform.username2.focus();
		return false;  
	}
	
	
		if (document.fekleform.password.value == ""){
		alert ("Şifre yazınız.");
		document.fekleform.password.focus();
		return false;  
	}
	
	
		
		if (document.fekleform.confirm_password.value == ""){
		alert ("Şifreyi tekrar yazınız.");
		document.fekleform.confirm_password.focus();
		return false;  
	}
	
	
				if (document.fekleform.password.value != document.fekleform.confirm_password.value){
		alert ("Şifre ile Şifre tekrarı uyuşmuyor.");
		document.fekleform.password.focus();
		return false;
	}
	
	
	
	if (document.fekleform.f_adi.value == ""){
		alert ("Lütfen Firma Adını Yazınız.");
		document.fekleform.f_adi.focus();
		return false;  
	}
	
	if (document.fekleform.f_adi.value.length<3 || document.fekleform.f_adi.value.length>200){
		alert ("Firma adınız 3 karakterden az, 200 karakterden fazla olmamalıdır.");
		document.fekleform.f_adi.focus();
		return false; 	
	}
	
	if (document.fekleform.sehir.value == ""){
		alert ("Lütfen Bir Şehir Seçiniz.");
		document.fekleform.sehir.focus();
		return false;
	}
	
		if (document.fekleform.ilce.value == ""){
		alert ("Lütfen Bir İlçe Seçiniz.");
		document.fekleform.ilce.focus();
		return false;
	}
	
	
	
	  if (document.fekleform["fsektor[]"].value == "")
    {
    alert ('Lütfen en az bir sektör seçiniz.') ;
	document.fekleform.s8.focus();
	 return false; 
	}
	
	


	
	
	 }

