<?php include("kontrol.php");
if($_SESSION[adminx]!=1){echo "<script>window.top.location.href = 'index.html';</script>";echo "Lütfen Üye Girişi Yapınız"; exit; } else {?>
<?php include("include/fonksiyon.php");?>
<?php include("include/header.php"); ?>
<body>
<div id="main_container">
<?php include("include/onizle.php"); ?>
<div class="main_content">
<?php include("include/ustmenu.php"); ?>
<div class="center_content"> 
<div class="left_content"> <?php include("include/solbolum.php"); ?> </div>
    
   
<div class="right_content"> 
<?php
$pg=$_GET['pg'];
switch($pg)
{
case "fekle":
include("include/xfekle.php"); 
break;
case "fliste":
include("include/xfliste.php"); 
break;
case "fduzenle":
include("include/xfduzenle.php"); 
break;
case "sabitliste":
include("include/xsabitliste.php"); 
break;

case "sektor":
include("include/xsektor.php"); 
break;

case "sehir":
include("include/xsehir.php"); 
break;

case "haber":
include("include/xhaber.php"); 
break;

case "anket":
include("include/xanket.php"); 
break;

case "ontel":
include("include/xontel.php"); 
break;

case "urun":
include("include/xurun.php"); 
break;

case "urunekle":
include("include/xurunekle.php"); 
break;

case "urunduzenle":
include("include/xurunduzenle.php"); 
break;

case "haber":
include("include/xhaber.php"); 
break;

case "haberekle":
include("include/xhaberekle.php"); 
break;

case "haberduzenle":
include("include/xhaberduzenle.php"); 
break;


case "ilan":
include("include/xilan.php"); 
break;

case "ilanekle":
include("include/xilanekle.php"); 
break;

case "ilanduzenle":
include("include/xilanduzenle.php"); 
break;


case "ilankat":
include("include/xilankat.php"); 
break;

case "ilankatekle":
include("include/xilankatekle.php"); 
break;

case "ilankatduzenle":
include("include/xilankatduzenle.php"); 
break;


case "kupon":
include("include/xkupon.php"); 
break;

case "yorum":
include("include/xyorum.php"); 
break;

case "sube":
include("include/xsube.php"); 
break;

case "uyelik":
include("include/xuyelik.php"); 
break;

case "reklam":
include("include/xreklam.php"); 
break;

case "reklamuye":
include("include/xreklamuye.php"); 
break;

case "yetkili":
include("include/xyetkili.php"); 
break;

case "email":
include("include/xemail.php"); 
break;

case "yedek":
include("include/xyedek.php"); 
break;

case "ayar":
include("include/xayar.php"); 
break;


case "onay":
include("include/xonay.php"); 
break;

case "kodreklam":
include("include/xkodreklam.php"); 
break;

case "stats":
include("include/xstats.php"); 
break;


case "ilce":
include("include/xilce.php"); 
break;


case "manset":
include("include/xmanset.php"); 
break;



case "mansetkat":
include("include/xmansetkat.php"); 
break;

case "mansetkatekle":
include("include/xmansetkatekle.php"); 
break;

case "mansetkatduzenle":
include("include/xmansetkatduzenle.php"); 
break;


case "modul":
include("include/xmodul.php"); 
break;


case "sifre":
include("include/xsifre.php"); 
break;


case "ucretli":
include("include/xucretli.php"); 
break;

case "ucretlikontrol":
include("include/xucretlikontrol.php"); 
break;

default:
include("include/default.php");  
}
?>


</div>
<!-- orta sayfa bitişi-->
  
              
</div>   <!--içerik bitişi -->   
<div class="clear"></div></div> <!--end of main content-->
<?php include("include/footer.php"); ?>  
</div>	 <!--end of main container-->
</body>
</html>
<?php } //Üye Girişi Yapılmadıysa Bitiş?>