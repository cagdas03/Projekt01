	 <script type="text/javascript">
	   
var geocoder = new google.maps.Geocoder();

            function geocodePosition(pos) {
                geocoder.geocode({
                    latLng: pos
                }, function(responses) {
                    if (responses && responses.length > 0) {
                        updateMarkerAddress(responses[0].formatted_address);
                    } else {
                        updateMarkerAddress('Adres tanımlanamadı.');
                    }
                });
            }

           

            function updateMarkerPosition(latLng) {
				
				
                document.getElementById('koordinat').value = [
                    latLng.lat(),
                    latLng.lng()
                ].join(', ');
            }

            function updateMarkerAddress(str) {
                document.getElementById('address').innerHTML = str;
            }
			
		
			

            function initialize() {
                var latLng = new google.maps.LatLng(<?php if ( empty($duzen['koordinat']) ) { echo $rowtt['tt_koordinat']; } else { echo $duzen['koordinat']; } ?>);
                var map = new google.maps.Map(document.getElementById('mapCanvas'), {
                    zoom: <?php if ( empty($duzen['zoom']) ) { echo $rowtt['tt_zoom'];; } else { echo $duzen['zoom']; } ?>,
                    center: latLng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });
                var marker = new google.maps.Marker({
                    position: latLng,
                    title: 'Point A',
                    map: map,
                    draggable: true
                });

                // Update current position info.
                updateMarkerPosition(latLng);
				geocodePosition(latLng);
			


                // Add dragging event listeners.
			
			    google.maps.event.addListener(marker, 'dblclick', function() {
				zoom = map.getZoom()+1;
				if (zoom == 20) { zoom = 8;} 
				if (zoom == 0) { zoom = 8;}   
				 
				document.getElementById("zoom").value = zoom; 
				map.setZoom(zoom);
				 });
			  
			  
                google.maps.event.addListener(marker, 'dragstart', function() {
                    updateMarkerAddress('Taşınıyor...');
                });

                google.maps.event.addListener(marker, 'drag', function() {
                                     updateMarkerPosition(marker.getPosition());
                });

                google.maps.event.addListener(marker, 'dragend', function() {
                                    geocodePosition(marker.getPosition());
                });
            
			  google.maps.event.addListener(map, 'zoom_changed', function() {
  	           zoom = map.getZoom();
	         document.getElementById("zoom").value = zoom;
              });

			}
            // Onload handler to fire off the app.
            google.maps.event.addDomListener(window, 'load', initialize);
	 </script>
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
      
       <div id="mapCanvas"></div>
        <div id="infoPanel">Aşağıdaki adres Google Map Tahmini Adresi olup kaydedilmeyecektir, bilgi amaçlıdır. <div id="address" style="font-weight:bold; padding:5px; width:590px; border:1px solid #E0E0E0; margin-bottom:10px"></div>
    </div>
 
        

          <div style="display:none">
          <input type="text" id="zoom" name="zoom" readonly="readonly" value="<?php echo $duzen['zoom']; ?>" >
          <input type="text" id="koordinat" name="koordinat" readonly="readonly" value="<?php echo $duzen['koordinat']; ?>" >
          </div>


