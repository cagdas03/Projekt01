<?php include("kontrol.php"); ?>
  <?php
if($oturum[adminx]==0)
{
echo "<script type=\"text/javascript\">window.location=\"index.html\"</script>";
exit;
  }
  elseif($oturum[adminx]==1)
   {
 echo "<script type=\"text/javascript\">window.location=\"index2.php\"</script>";
  }  